/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { ConfigulationService as ɵb } from './lib/common/configuration.service';
export { StaticBag as ɵd } from './lib/common/static';
export { SidebarComponent as ɵa } from './lib/components/layout/sidebar/sidebar.component';
export { OrganizeInfoService as ɵc } from './lib/models/organize-info.service';
