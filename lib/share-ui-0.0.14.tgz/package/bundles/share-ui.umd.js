(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@angular/router'), require('angular-oauth2-oidc'), require('@angular/common/http'), require('devextreme/localization'), require('object-assign'), require('devextreme/localization/date'), require('devextreme/core/version'), require('devextreme/core/utils/version'), require('devextreme/ui/dialog'), require('rxjs'), require('luxon'), require('devextreme-angular'), require('rxjs/operators')) :
  typeof define === 'function' && define.amd ? define('share-ui', ['exports', '@angular/core', '@angular/common', '@angular/router', 'angular-oauth2-oidc', '@angular/common/http', 'devextreme/localization', 'object-assign', 'devextreme/localization/date', 'devextreme/core/version', 'devextreme/core/utils/version', 'devextreme/ui/dialog', 'rxjs', 'luxon', 'devextreme-angular', 'rxjs/operators'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["share-ui"] = {}, global.ng.core, global.ng.common, global.ng.router, global["angular-oauth2-oidc"], global.ng.common.http, global.localization, global.objectAssign, global.dateLocalization, global.dxVersion, global.compareVersions, global.dialog, global.rxjs, global.luxon, global["devextreme-angular"], global.rxjs.operators));
})(this, (function (exports, i0, common, router, i1, http, localization, objectAssign, dateLocalization, dxVersion, compareVersions, dialog, rxjs, luxon, devextremeAngular, operators) { 'use strict';

  function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = Object.create(null);
    if (e) {
      Object.keys(e).forEach(function (k) {
        if (k !== 'default') {
          var d = Object.getOwnPropertyDescriptor(e, k);
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      });
    }
    n["default"] = e;
    return Object.freeze(n);
  }

  var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
  var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
  var objectAssign__default = /*#__PURE__*/_interopDefaultLegacy(objectAssign);
  var dateLocalization__default = /*#__PURE__*/_interopDefaultLegacy(dateLocalization);
  var dxVersion__namespace = /*#__PURE__*/_interopNamespace(dxVersion);
  var compareVersions__namespace = /*#__PURE__*/_interopNamespace(compareVersions);

  var ShareUiComponent = /** @class */ (function () {
      function ShareUiComponent() {
      }
      ShareUiComponent.prototype.ngOnInit = function () {
      };
      return ShareUiComponent;
  }());
  ShareUiComponent.decorators = [
      { type: i0.Component, args: [{
                  selector: 'share-share-ui',
                  template: "\n    <p>\n      share-ui works!\n    </p>\n  "
              },] }
  ];
  ShareUiComponent.ctorParameters = function () { return []; };

  var ConfigulationService = /** @class */ (function () {
      function ConfigulationService(environment, oAuthModuleConfig) {
          this.environment = environment;
          this.oAuthModuleConfig = oAuthModuleConfig;
          this._config = {};
          this.Init();
          this.InitAuth();
          // this.oAuthModuleConfig = {
          //     resourceServer: {
          //         allowedUrls: [this._config.apiUrl],
          //         sendAccessToken: true
          //     }
          // };
      }
      ConfigulationService.prototype.InitAuth = function () {
          var authUrl = 'https://bne01.demotoday.net/auth';
          var clientId = "demo-app";
          var redirectUri = this._config.originUrl + "/home";
          this._config.authConfig = {
              autoLogin: true,
              revokeTokenOnLogout: false,
              issuer: authUrl + "/realms/demo",
              clientId: clientId,
              redirectUri: redirectUri,
              silentRefreshRedirectUri: this._config.originUrl + "/silent-refresh.html",
              postLogoutRedirectUri: this._config.originUrl + "/home",
              skipIssuerCheck: true,
              strictDiscoveryDocumentValidation: false,
              responseType: 'code',
              disablePKCE: false,
              // scope: 'openid profile email offline_access api',
              silentRefreshTimeout: 50000,
              timeoutFactor: 0.75,
              sessionChecksEnabled: true,
              showDebugInformation: true,
              clearHashAfterLogin: false
          };
      };
      ConfigulationService.prototype.Init = function () {
          this._config.originUrl = window.location.origin;
          // Init apiUrl
          if (this.environment.production) {
              this._config.apiUrl = "https://wfhapi.demotoday.net/api";
          }
          else if (this.environment.staging) {
              this._config.apiUrl = "http://localhost:44307/api";
              // this._config.apiUrl = "https://sarabun.demotoday.net/covid/api";
          }
          else {
              this._config.apiUrl = "http://localhost:44307/api";
          }
          // Init assetUrl
          if (this.environment.production) {
              this._config.resourceUrl = "https://wfh.demotoday.net/resource/wfh";
          }
          else {
              this._config.resourceUrl = "http://sarabun.demotoday.net/resource/wfh";
          }
          // Init reportUrl
          this._config.reportUrl = 'https://wfh.demotoday.net/rpt';
      };
      Object.defineProperty(ConfigulationService.prototype, "Config", {
          get: function () {
              return this._config;
          },
          enumerable: false,
          configurable: true
      });
      return ConfigulationService;
  }());
  ConfigulationService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ConfigulationService_Factory() { return new ConfigulationService(i0__namespace.ɵɵinject("env"), i0__namespace.ɵɵinject(i1__namespace.OAuthModuleConfig, 8)); }, token: ConfigulationService, providedIn: "root" });
  ConfigulationService.decorators = [
      { type: i0.Injectable, args: [{
                  providedIn: 'root'
              },] }
  ];
  ConfigulationService.ctorParameters = function () { return [
      { type: undefined, decorators: [{ type: i0.Inject, args: ['env',] }] },
      { type: i1.OAuthModuleConfig, decorators: [{ type: i0.Optional }] }
  ]; };

  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */
  /* global Reflect, Promise */
  var extendStatics = function (d, b) {
      extendStatics = Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
          function (d, b) { for (var p in b)
              if (Object.prototype.hasOwnProperty.call(b, p))
                  d[p] = b[p]; };
      return extendStatics(d, b);
  };
  function __extends(d, b) {
      if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
      extendStatics(d, b);
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  var __assign = function () {
      __assign = Object.assign || function __assign(t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
              s = arguments[i];
              for (var p in s)
                  if (Object.prototype.hasOwnProperty.call(s, p))
                      t[p] = s[p];
          }
          return t;
      };
      return __assign.apply(this, arguments);
  };
  function __rest(s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  }
  function __decorate(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
          r = Reflect.decorate(decorators, target, key, desc);
      else
          for (var i = decorators.length - 1; i >= 0; i--)
              if (d = decorators[i])
                  r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
  }
  function __param(paramIndex, decorator) {
      return function (target, key) { decorator(target, key, paramIndex); };
  }
  function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
          return Reflect.metadata(metadataKey, metadataValue);
  }
  function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
      return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) { try {
              step(generator.next(value));
          }
          catch (e) {
              reject(e);
          } }
          function rejected(value) { try {
              step(generator["throw"](value));
          }
          catch (e) {
              reject(e);
          } }
          function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
  }
  function __generator(thisArg, body) {
      var _ = { label: 0, sent: function () { if (t[0] & 1)
              throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
      function verb(n) { return function (v) { return step([n, v]); }; }
      function step(op) {
          if (f)
              throw new TypeError("Generator is already executing.");
          while (_)
              try {
                  if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                      return t;
                  if (y = 0, t)
                      op = [op[0] & 2, t.value];
                  switch (op[0]) {
                      case 0:
                      case 1:
                          t = op;
                          break;
                      case 4:
                          _.label++;
                          return { value: op[1], done: false };
                      case 5:
                          _.label++;
                          y = op[1];
                          op = [0];
                          continue;
                      case 7:
                          op = _.ops.pop();
                          _.trys.pop();
                          continue;
                      default:
                          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                              _ = 0;
                              continue;
                          }
                          if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                              _.label = op[1];
                              break;
                          }
                          if (op[0] === 6 && _.label < t[1]) {
                              _.label = t[1];
                              t = op;
                              break;
                          }
                          if (t && _.label < t[2]) {
                              _.label = t[2];
                              _.ops.push(op);
                              break;
                          }
                          if (t[2])
                              _.ops.pop();
                          _.trys.pop();
                          continue;
                  }
                  op = body.call(thisArg, _);
              }
              catch (e) {
                  op = [6, e];
                  y = 0;
              }
              finally {
                  f = t = 0;
              }
          if (op[0] & 5)
              throw op[1];
          return { value: op[0] ? op[1] : void 0, done: true };
      }
  }
  var __createBinding = Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  });
  function __exportStar(m, o) {
      for (var p in m)
          if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
              __createBinding(o, m, p);
  }
  function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
      if (m)
          return m.call(o);
      if (o && typeof o.length === "number")
          return {
              next: function () {
                  if (o && i >= o.length)
                      o = void 0;
                  return { value: o && o[i++], done: !o };
              }
          };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m)
          return o;
      var i = m.call(o), r, ar = [], e;
      try {
          while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
              ar.push(r.value);
      }
      catch (error) {
          e = { error: error };
      }
      finally {
          try {
              if (r && !r.done && (m = i["return"]))
                  m.call(i);
          }
          finally {
              if (e)
                  throw e.error;
          }
      }
      return ar;
  }
  /** @deprecated */
  function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++)
          ar = ar.concat(__read(arguments[i]));
      return ar;
  }
  /** @deprecated */
  function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++)
          s += arguments[i].length;
      for (var r = Array(s), k = 0, i = 0; i < il; i++)
          for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
              r[k] = a[j];
      return r;
  }
  function __spreadArray(to, from, pack) {
      if (pack || arguments.length === 2)
          for (var i = 0, l = from.length, ar; i < l; i++) {
              if (ar || !(i in from)) {
                  if (!ar)
                      ar = Array.prototype.slice.call(from, 0, i);
                  ar[i] = from[i];
              }
          }
      return to.concat(ar || Array.prototype.slice.call(from));
  }
  function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
  }
  function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator)
          throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []), i, q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
      function verb(n) { if (g[n])
          i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
      function resume(n, v) { try {
          step(g[n](v));
      }
      catch (e) {
          settle(q[0][3], e);
      } }
      function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
      function fulfill(value) { resume("next", value); }
      function reject(value) { resume("throw", value); }
      function settle(f, v) { if (f(v), q.shift(), q.length)
          resume(q[0][0], q[0][1]); }
  }
  function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
      function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
  }
  function __asyncValues(o) {
      if (!Symbol.asyncIterator)
          throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator], i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
      function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
      function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
  }
  function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
          Object.defineProperty(cooked, "raw", { value: raw });
      }
      else {
          cooked.raw = raw;
      }
      return cooked;
  }
  ;
  var __setModuleDefault = Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  };
  function __importStar(mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k in mod)
              if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                  __createBinding(result, mod, k);
      __setModuleDefault(result, mod);
      return result;
  }
  function __importDefault(mod) {
      return (mod && mod.__esModule) ? mod : { default: mod };
  }
  function __classPrivateFieldGet(receiver, state, kind, f) {
      if (kind === "a" && !f)
          throw new TypeError("Private accessor was defined without a getter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
          throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f) {
      if (kind === "m")
          throw new TypeError("Private method is not writable");
      if (kind === "a" && !f)
          throw new TypeError("Private accessor was defined without a setter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
          throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
  }

  var StaticBag = {
      InjectorInstance: undefined
  };

  var SHARE_UI_CONFIG = new i0.InjectionToken('config');

  var BetimesHttpRequest = /** @class */ (function () {
      function BetimesHttpRequest(http) {
          this.http = http;
          this._responseType = "json";
          this._reportProgress = false;
          this._criticalErrorDialog = true;
          this._errorDialog = true;
          // this._header = new HttpHeaders({ 'Content-Type': 'application/json' });
      }
      BetimesHttpRequest.prototype.host = function (h) {
          this._host = h;
          return this;
      };
      BetimesHttpRequest.prototype.raw = function () {
          this._raw = true;
          return this;
      };
      BetimesHttpRequest.prototype.api = function (url) {
          this._url = url;
          return this;
      };
      BetimesHttpRequest.prototype.body = function (body) {
          this._body = body;
          return this;
      };
      BetimesHttpRequest.prototype.queryString = function (param) {
          this._param = param;
          return this;
      };
      BetimesHttpRequest.prototype.header = function (head) {
          if (!(head instanceof http.HttpHeaders)) {
              this._header = new http.HttpHeaders(head);
          }
          else {
              this._header = head;
          }
          return this;
      };
      BetimesHttpRequest.prototype.responseType = function (r) {
          this._responseType = r;
          return this;
      };
      BetimesHttpRequest.prototype.result = function () {
          return this;
      };
      BetimesHttpRequest.prototype.useSystemResult = function () {
          this._useSystemReulst = true;
          return this;
      };
      BetimesHttpRequest.prototype.reportProgress = function () {
          this._reportProgress = true;
          this._useSystemReulst = true;
          return this;
      };
      BetimesHttpRequest.prototype.disableCriticalDialogError = function () {
          this._criticalErrorDialog = false;
          return this;
      };
      BetimesHttpRequest.prototype.disableDialogError = function () {
          this._errorDialog = false;
          return this;
      };
      BetimesHttpRequest.prototype.cache = function () {
          this._useCache = true;
          return this;
      };
      BetimesHttpRequest.prototype.invalidate = function () {
          this._useCacheInvalidate = true;
          return this;
      };
      BetimesHttpRequest.prototype.post = function () {
          return this.send("POST");
      };
      BetimesHttpRequest.prototype.get = function () {
          return this.send("GET");
      };
      BetimesHttpRequest.prototype.patch = function () {
          return this.send("PATCH");
      };
      BetimesHttpRequest.prototype.put = function () {
          return this.send("PUT");
      };
      BetimesHttpRequest.prototype.delete = function () {
          return this.send("DELETE");
      };
      BetimesHttpRequest.prototype.send = function (method) {
          var urlWithbase = this._host + "/" + this._url;
          var header = this._header;
          if (!header) {
              var contentType = new http.HttpRequest("POST", "", this._body).detectContentTypeHeader();
              if (contentType) {
                  header = new http.HttpHeaders({ 'Content-Type': contentType });
              }
          }
          var request = new BetimesRequest(method, urlWithbase, this._body, {
              headers: header,
              responseType: this._responseType,
              reportProgress: this._reportProgress,
              params: this._param ? new http.HttpParams({ fromObject: this._param }) : undefined
          });
          request.displayError = this._errorDialog;
          request.useOnlyValue = (this._useCache || !this._useSystemReulst) && !this._raw;
          request.displayCriticalError = this._criticalErrorDialog;
          request.useCacheInvalidate = this._useCacheInvalidate;
          request.useCache = this._useCache;
          request.raw = this._raw;
          return this.http.request(request);
      };
      return BetimesHttpRequest;
  }());
  var BetimesRequest = /** @class */ (function (_super) {
      __extends(BetimesRequest, _super);
      function BetimesRequest() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      BetimesRequest.prototype.clone = function (update) {
          var method = update.method || this.method;
          var url = update.url || this.url;
          var responseType = update.responseType || this.responseType;
          var body = (update.body !== undefined) ? update.body : this.body;
          var withCredentials = (update.withCredentials !== undefined) ? update.withCredentials : this.withCredentials;
          var reportProgress = (update.reportProgress !== undefined) ? update.reportProgress : this.reportProgress;
          var headers = update.headers || this.headers;
          var params = update.params || this.params;
          if (update.setHeaders !== undefined) {
              headers =
                  Object.keys(update.setHeaders)
                      // tslint:disable-next-line: no-shadowed-variable
                      .reduce(function (headers, name) { return headers.set(name, update.setHeaders[name]); }, headers);
          }
          if (update.setParams) {
              params = Object.keys(update.setParams)
                  // tslint:disable-next-line: no-shadowed-variable
                  .reduce(function (params, param) { return params.set(param, update.setParams[param]); }, params);
          }
          var request = new BetimesRequest(method, url, body, {
              params: params, headers: headers, reportProgress: reportProgress, responseType: responseType, withCredentials: withCredentials,
          });
          request.displayCriticalError = this.displayCriticalError;
          request.displayError = this.displayError;
          request.useOnlyValue = this.useOnlyValue;
          request.useCache = this.useCache;
          request.useCacheInvalidate = this.useCacheInvalidate;
          return request;
      };
      return BetimesRequest;
  }(http.HttpRequest));
  var BetimesHttpResultError = /** @class */ (function (_super) {
      __extends(BetimesHttpResultError, _super);
      function BetimesHttpResultError(err) {
          var _newTarget = this.constructor;
          var _this = _super.call(this, err.Message) || this;
          _this.err = err;
          var actualProto = _newTarget.prototype;
          if (Object.setPrototypeOf) {
              Object.setPrototypeOf(_this, actualProto);
          }
          else {
              _this.__proto__ = actualProto;
          }
          return _this;
      }
      Object.defineProperty(BetimesHttpResultError.prototype, "HttpResult", {
          get: function () {
              return this.err;
          },
          enumerable: false,
          configurable: true
      });
      return BetimesHttpResultError;
  }(Error));
  function req(api) {
      return new BetimesHttpRequest(StaticBag.InjectorInstance.get(http.HttpClient))
          .host(StaticBag.InjectorInstance.get(SHARE_UI_CONFIG).apiUrl)
          .api(api)
          .result();
  }

  // @dynamic
  var User = /** @class */ (function () {
      function User() {
      }
      Object.defineProperty(User, "Current", {
          get: function () {
              // if (!User._userInfo) {
              //     const profile = Cookies.getJSON("profile");
              //     User._userInfo = profile || undefined;
              // }
              return undefined;
          },
          enumerable: false,
          configurable: true
      });
      User.SetUser = function (userinfo) {
          // User._userInfo = userinfo;
          // Cookies.set("profile", JSON.stringify(userinfo));
      };
      User.Save = function () {
          // Cookies.set("profile", JSON.stringify(User._userInfo));
      };
      User.SwitchRole = function (role) {
          // const profile: UserProfile = User._userInfo;
          // profile.Role = role;
          // Cookies.set("profile", JSON.stringify(profile));
      };
      User.Clear = function () {
          // Cookies.remove("profile");
          // User._userInfo = undefined;
      };
      return User;
  }());

  var OrganizeInfoService = /** @class */ (function () {
      function OrganizeInfoService() {
      }
      OrganizeInfoService.prototype.GetOrganize = function (role, includeStatus) {
          if (includeStatus === void 0) { includeStatus = true; }
          return req('CmsOrganize')
              .queryString({ roleId: role, RecordStatus: includeStatus })
              .get();
      };
      OrganizeInfoService.prototype.GetByOrganizeId = function (id) {
          return req("CmsOrganize/" + id)
              .cache()
              .get();
      };
      OrganizeInfoService.prototype.GetApps = function (roleId) {
          return req('CmsOrganize/app')
              .queryString({ roleId: roleId })
              .get();
      };
      OrganizeInfoService.prototype.InsertOrganizeInfo = function (param) {
          return req("CmsOrganize")
              .body(param)
              .post();
      };
      OrganizeInfoService.prototype.GetsOrganizePki = function (id) {
          return req("CmsOrganize/" + id + '/pki')
              .get();
      };
      OrganizeInfoService.prototype.UpdateOrganizeInfo = function (id, param) {
          return req('CmsOrganize/' + id)
              .body(param)
              .put();
      };
      OrganizeInfoService.prototype.SearchOrganizeName = function (name, offset, length) {
          return req("CmsOrganize/search")
              .body({
              Condition: {
                  ORGANIZE_NAME_THA: name
              }, Offset: offset, Length: length
          })
              .post();
      };
      OrganizeInfoService.prototype.SearchOrganize = function (searchObj, offset, length) {
          return req("CmsOrganize/search")
              .body({ Condition: searchObj, Offset: offset, Length: length })
              .queryString({ roleId: User.Current.Role.RoleId })
              .post();
      };
      return OrganizeInfoService;
  }());
  OrganizeInfoService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function OrganizeInfoService_Factory() { return new OrganizeInfoService(); }, token: OrganizeInfoService, providedIn: "root" });
  OrganizeInfoService.decorators = [
      { type: i0.Injectable, args: [{
                  providedIn: 'root'
              },] }
  ];
  OrganizeInfoService.ctorParameters = function () { return []; };

  var SidebarComponent = /** @class */ (function () {
      function SidebarComponent(router, config, orgService) {
          this.router = router;
          this.config = config;
          this.orgService = orgService;
      }
      return SidebarComponent;
  }());
  SidebarComponent.decorators = [
      { type: i0.Component, args: [{
                  selector: 'share-sidebar',
                  template: "<!-- <div>\r\n    <div class=\"sidebar-wrapper\" style=\"margin-top: 45px;\">\r\n        <div class=\"recomment p-2\">\r\n            <i class=\"fas fa-shield-alt mb-2\"></i>\r\n            <div class=\"dx-field\" style=\"margin-top: 0px;\">\r\n                <div class=\"dx-field-label\" style=\"color: white!important; padding-left: 20px; width: 30%;\">\r\n                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\u0E1A\u0E17\u0E1A\u0E32\u0E17</div>\r\n                <div class=\"dx-field-value\" style=\"width: 70%;\">\r\n                    <dx-select-box #roleBox [(value)]=\"curRoleId\" valueExpr=\"RoleId\" [items]=\"roleList\"\r\n                        style=\"width: 90%;\" displayExpr=\"RoleName\" placeholder=\"\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1A\u0E17\u0E1A\u0E32\u0E17\" [width]=\"143\"\r\n                        (onValueChanged)=\"OnRoleSelected($event)\">\r\n                    </dx-select-box>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <dx-tree-view [dataSource]=\"_menuList\" [hoverStateEnabled]=\"false\" [focusStateEnabled]=\"false\"\r\n            [selectNodesRecursive]=\"true\" noDataText=\"\" dataStructure=\"plain\" keyExpr=\"MODULE_ID\"\r\n            displayExpr=\"MODULE_NAME\" parentIdExpr=\"MODULE_PARENT_ID\" itemTemplate=\"_menuList\"\r\n            (onItemClick)=\"MenuClicked($event)\">\r\n\r\n            <div *dxTemplate=\"let item of '_menuList'\">\r\n\r\n                <div class=\"recomment p-2\" style=\"background-color: #c4cfd402 !important\">\r\n                    <i class='fas {{item.MODULE_ICON}}' style=\"color : #000000\"></i>\r\n                    <div class=\"dx-field\">\r\n                        <a class=\"nav-link\" routerLinkActive=\"active\">\r\n                            <div class='fas {{item.MODULE_ICON}}' style=\"font-size: 23px;\"></div>\r\n                            <div class=\"dx-field-value\" style=\"font-size: 12px;\r\n                            margin-right: 34px !important;\r\n                            margin-top: 0px; width: 100%;\r\n    margin-left: 10px;\">\r\n                                {{item.MODULE_NAME}}\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n\r\n        </dx-tree-view>\r\n    </div>\r\n</div> -->\r\n",
                  styles: [":host .nav-link{display:flex;margin:0;border-radius:3px;color:#000;padding-left:10px;padding-right:10px;text-transform:capitalize;font-size:13px}:host ::ng-deep li:hover .nav-link{color:#000}:host ::ng-deep .dx-field:last-of-type{width:120%;margin-left:-30px;margin-top:-15px;height:50px;padding-left:30px;padding-top:6px}:host ::ng-deep .dx-treeview-node-container-opened>.dx-treeview-node>.dx-treeview-node-is-leaf:hover>.dx-treeview-item .dx-field,:host ::ng-deep .dx-treeview-node-container>.dx-treeview-node:hover>.dx-treeview-item .dx-field{background:#fcf0c5!important;width:120%;margin-left:-30px;margin-top:-15px;height:50px;padding-left:30px;padding-top:6px}:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .dx-treeview-item{background:transparent}:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .dx-field{background:#fcf0c5!important;width:120%;margin-left:-30px;margin-top:-15px;height:50px;padding-left:30px;padding-top:6px}:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .nav-link>i,:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .nav-link>p{color:#0b314f}:host ::ng-deep .dx-treeview-node{padding:0}:host ::ng-deep .dx-treeview-node-container-opened .dx-treeview-node{padding-left:15px}:host ::ng-deep .nav-link i{font-size:24px;float:left;margin-right:15px;line-height:30px;width:30px;text-align:center;color:#000}:host ::ng-deep .dx-treeview-node-container-opened .dx-treeview-node .nav-link i{font-size:17px}:host ::ng-deep .nav-link p{margin:0;line-height:30px;font-size:14px;position:relative;display:block;height:auto}:host ::ng-deep .dx-treeview-toggle-item-visibility{top:13px;left:210px;color:#000}::ng-deep .sidebar .sidebar-wrapper{overflow:hidden;padding-bottom:60px;margin-top:-12px}::ng-deep .sidebar .logo:after{content:\"\";position:absolute;bottom:0;right:15px;height:1px;width:calc(100% - 30px);background-color:hsla(0,0%,70.6%,.01)}::ng-deep .dx-treeview-toggle-item-visibility:before{top:70%!important}::ng-deep .dx-treeview-toggle-item-visibility.dx-treeview-toggle-item-visibility-opened:before{content:\"\\f001\";margin-top:-22px;left:50%;margin-left:-11px}::ng-deep .dx-treeview-toggle-item-visibility:before{content:\"\\f04e\";margin-top:-22px;left:50%;margin-left:-11px}::ng-deep .dx-treeview-item{padding:5px 6px;min-height:32px;height:50px}::ng-deep .sidebar:before{top:0;left:0;height:100%;width:100%;position:absolute;background-color:#fff;display:block;content:\"\";z-index:1}"]
              },] }
  ];
  SidebarComponent.ctorParameters = function () { return [
      { type: router.Router },
      { type: ConfigulationService },
      { type: OrganizeInfoService }
  ]; };

  /* eslint-disable no-var */
  var SYMBOLS_TO_REMOVE_REGEX = /[\u200E\u200F]/g;
  var getIntlFormatter = function (format) {
      return function (date) {
          // Intl in some browsers formates dates with timezone offset which was at the moment for this date.
          // But the method "new Date" creates date using current offset. So, we decided to format dates in the UTC timezone.
          if (!format.timeZoneName) {
              var utcDate = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
              var utcFormat = objectAssign__default["default"]({ timeZone: 'UTC' }, format);
              return formatDateTime(utcDate, utcFormat);
          }
          return formatDateTime(date, format);
      };
  };
  var ɵ0 = getIntlFormatter;
  var formatDateTime = function (date, format) {
      return (new Intl.DateTimeFormat(localization.locale(), format)).format(date).replace(SYMBOLS_TO_REMOVE_REGEX, '');
  };
  var ɵ1 = formatDateTime;
  var formatCustomDateTime = function (date, format) {
      var dateString = date.toLocaleString(localization.locale(), format);
      // dateString = dateString.split(" ").join(" ");
      return dateString;
  };
  var ɵ2 = formatCustomDateTime;
  var formatNumber = function (number) {
      return (new Intl.NumberFormat(localization.locale())).format(number);
  };
  var ɵ3 = formatNumber;
  var ɵ4 = function () {
      var numeralsMapCache = {};
      return function (locale) {
          if (!(locale in numeralsMapCache)) {
              if (formatNumber(0) === '0') {
                  numeralsMapCache[locale] = false;
                  return false;
              }
              numeralsMapCache[locale] = {};
              for (var i = 0; i < 10; ++i) {
                  numeralsMapCache[locale][formatNumber(i)] = i;
              }
          }
          return numeralsMapCache[locale];
      };
  };
  var getAlternativeNumeralsMap = (ɵ4());
  var normalizeNumerals = function (dateString) {
      var alternativeNumeralsMap = getAlternativeNumeralsMap(localization.locale());
      if (!alternativeNumeralsMap) {
          return dateString;
      }
      return dateString.split('').map(function (sign) {
          return sign in alternativeNumeralsMap ? String(alternativeNumeralsMap[sign]) : sign;
      }).join('');
  };
  var ɵ5 = normalizeNumerals;
  var removeLeadingZeroes = function (str) {
      return str.replace(/(\D)0+(\d)/g, '$1$2');
  };
  var ɵ6 = removeLeadingZeroes;
  var dateStringEquals = function (actual, expected) {
      return removeLeadingZeroes(actual) === removeLeadingZeroes(expected);
  };
  var ɵ7 = dateStringEquals;
  var normalizeMonth = function (text) {
      return text.replace('d\u2019', 'de '); // NOTE: For 'ca' locale
  };
  var ɵ8 = normalizeMonth;
  var intlFormats = {
      day: { day: 'numeric' },
      dayofweek: { weekday: 'long' },
      longdate: { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' },
      longdatelongtime: { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' },
      longtime: { hour: 'numeric', minute: 'numeric', second: 'numeric' },
      month: { month: 'long' },
      monthandday: { month: 'long', day: 'numeric' },
      monthandyear: { year: 'numeric', month: 'long' },
      shortdate: {},
      shorttime: { hour: 'numeric', minute: 'numeric' },
      shortyear: { year: '2-digit' },
      year: { year: 'numeric' },
      yyyy: { year: 'numeric' }
  };
  var customFormats = {
      datethai: { year: "numeric", month: "short", day: "numeric" },
      dateshorttimethai: { year: "numeric", month: "short", day: "numeric", hour: 'numeric', minute: 'numeric' }
  };
  Object.defineProperty(intlFormats, 'shortdateshorttime', {
      get: function () {
          var defaultOptions = Intl.DateTimeFormat(localization.locale()).resolvedOptions();
          return { year: defaultOptions.year, month: defaultOptions.month, day: defaultOptions.day, hour: 'numeric', minute: 'numeric' };
      }
  });
  var getIntlFormat = function (format) {
      return typeof format === 'string' && intlFormats[format.toLowerCase()];
  };
  var ɵ9 = getIntlFormat;
  var getCustomIntlFormat = function (format) {
      return typeof format === 'string' && customFormats[format.toLowerCase()];
  };
  var ɵ10 = getCustomIntlFormat;
  var monthNameStrategies = {
      standalone: function (monthIndex, monthFormat) {
          var date = new Date(1999, monthIndex, 13, 1);
          var dateString = getIntlFormatter({ month: monthFormat })(date);
          return dateString;
      },
      format: function (monthIndex, monthFormat) {
          var date = new Date(0, monthIndex, 13, 1);
          var dateString = normalizeMonth(getIntlFormatter({ day: 'numeric', month: monthFormat })(date));
          var parts = dateString.split(' ').filter(function (part) {
              return part.indexOf('13') < 0;
          });
          if (parts.length === 1) {
              return parts[0];
          }
          else if (parts.length === 2) {
              return parts[0].length > parts[1].length ? parts[0] : parts[1]; // NOTE: For 'lt' locale
          }
          return monthNameStrategies.standalone(monthIndex, monthFormat);
      }
  };
  dateLocalization__default["default"].resetInjection();
  dateLocalization__default["default"].inject({
      getMonthNames: function (format, type) {
          var intlFormats = {
              wide: 'long',
              abbreviated: 'short',
              narrow: 'narrow'
          };
          var monthFormat = intlFormats[format || 'wide'];
          type = type || 'standalone';
          return Array.apply(null, new Array(12)).map(function (_, monthIndex) {
              return monthNameStrategies[type](monthIndex, monthFormat);
          });
      },
      getDayNames: function (format) {
          var intlFormats = {
              wide: 'long',
              abbreviated: 'short',
              short: 'narrow',
              narrow: 'narrow'
          };
          var getIntlDayNames = function (format) {
              return Array.apply(null, new Array(7)).map(function (_, dayIndex) {
                  return getIntlFormatter({ weekday: format })(new Date(0, 0, dayIndex));
              });
          };
          var result = getIntlDayNames(intlFormats[format || 'wide']);
          return result;
      },
      getPeriodNames: function () {
          var hour12Formatter = getIntlFormatter({ hour: 'numeric', hour12: true });
          return [1, 13].map(function (hours) {
              var hourNumberText = formatNumber(1); // NOTE: For 'bn' locale
              var timeParts = hour12Formatter(new Date(0, 0, 1, hours)).split(hourNumberText);
              if (timeParts.length !== 2) {
                  return '';
              }
              var biggerPart = timeParts[0].length > timeParts[1].length ? timeParts[0] : timeParts[1];
              return biggerPart.trim();
          });
      },
      format: function (date, format) {
          if (!date) {
              return;
          }
          if (!format) {
              return date;
          }
          format = format.type || format;
          var intlFormat = getIntlFormat(format);
          if (intlFormat) {
              return getIntlFormatter(intlFormat)(date);
          }
          var formatType = typeof format;
          if (format.formatter || formatType === 'function' || formatType === 'string') {
              intlFormat = getCustomIntlFormat(format);
              if (intlFormat) {
                  return formatCustomDateTime(date, intlFormat);
              }
              return this.callBase.apply(this, arguments);
          }
          return getIntlFormatter(format)(date);
      },
      parse: function (dateString, format) {
          var SIMPLE_FORMATS = ['shortdate', 'shorttime', 'shortdateshorttime', 'longtime'];
          if (compareVersions__namespace(dxVersion__namespace, '17.2.4') === -1 && dateString && typeof format === 'string' && SIMPLE_FORMATS.indexOf(format.toLowerCase()) > -1) {
              return this._parseDateBySimpleFormat(dateString, format.toLowerCase());
          }
          var formatter;
          if (compareVersions__namespace(dxVersion__namespace, '17.2.4') >= 0 && format && !format.parser && typeof dateString === 'string') {
              dateString = normalizeMonth(dateString);
              formatter = function (date) {
                  return normalizeMonth(dateLocalization__default["default"].format(date, format));
              };
          }
          return this.callBase(dateString, formatter || format);
      },
      _parseDateBySimpleFormat: function (dateString, format) {
          dateString = normalizeNumerals(dateString);
          var formatParts = this.getFormatParts(format);
          var dateParts = dateString
              .split(/\D+/)
              .filter(function (part) { return part.length > 0; });
          if (formatParts.length !== dateParts.length) {
              return;
          }
          var dateArgs = this._generateDateArgs(formatParts, dateParts);
          var constructDate = function (dateArgs, ampmShift) {
              var hoursShift = ampmShift ? 12 : 0;
              return new Date(dateArgs.year, dateArgs.month, dateArgs.day, (dateArgs.hours + hoursShift) % 24, dateArgs.minutes, dateArgs.seconds);
          };
          var constructValidDate = function (ampmShift) {
              var parsedDate = constructDate(dateArgs, ampmShift);
              if (dateStringEquals(normalizeNumerals(this.format(parsedDate, format)), dateString)) {
                  return parsedDate;
              }
          }.bind(this);
          return constructValidDate(false) || constructValidDate(true);
      },
      _generateDateArgs: function (formatParts, dateParts) {
          var currentDate = new Date();
          var dateArgs = {
              year: currentDate.getFullYear(),
              month: currentDate.getMonth(),
              day: currentDate.getDate(),
              hours: 0,
              minutes: 0,
              seconds: 0
          };
          formatParts.forEach(function (formatPart, index) {
              var datePart = dateParts[index];
              var parsed = parseInt(datePart, 10);
              if (formatPart === 'month') {
                  parsed = parsed - 1;
              }
              dateArgs[formatPart] = parsed;
          });
          return dateArgs;
      },
      formatUsesMonthName: function (format) {
          if (typeof format === 'object' && !(format.type || format.format)) {
              return format.month === 'long';
          }
          return this.callBase.apply(this, arguments);
      },
      formatUsesDayName: function (format) {
          if (typeof format === 'object' && !(format.type || format.format)) {
              return format.weekday === 'long';
          }
          return this.callBase.apply(this, arguments);
      },
      getFormatParts: function (format) {
          var intlFormat = objectAssign__default["default"]({}, intlFormats[format.toLowerCase()]);
          var date = new Date(2001, 2, 4, 5, 6, 7);
          var formattedDate = getIntlFormatter(intlFormat)(date);
          formattedDate = normalizeNumerals(formattedDate);
          var formatParts = [
              { name: 'year', value: 1 },
              { name: 'month', value: 3 },
              { name: 'day', value: 4 },
              { name: 'hours', value: 5 },
              { name: 'minutes', value: 6 },
              { name: 'seconds', value: 7 }
          ];
          return formatParts
              .map(function (part) {
              return {
                  name: part.name,
                  index: formattedDate.indexOf(part.value)
              };
          })
              .filter(function (part) { return part.index > -1; })
              .sort(function (a, b) { return a.index - b.index; })
              .map(function (part) { return part.name; });
      }
  });

  var TabItemComponent = /** @class */ (function () {
      function TabItemComponent() {
          this._state = { visible: false, init: false };
      }
      Object.defineProperty(TabItemComponent.prototype, "visible", {
          get: function () {
              return this._state.visible;
          },
          set: function (v) {
              this._state.visible = v;
          },
          enumerable: false,
          configurable: true
      });
      TabItemComponent.prototype.activate = function () {
          this._state.init = true;
          this._state.visible = true;
      };
      TabItemComponent.prototype.ngOnInit = function () {
      };
      return TabItemComponent;
  }());
  TabItemComponent.decorators = [
      { type: i0.Component, args: [{
                  selector: 'share-tab-item',
                  template: "<div class=\"tab-pane fade\" [ngClass]=\"{'active show': _state.visible, 'd-none': !_state.visible}\">\r\n    <ng-container *ngIf=\"recreateOnActive ? _state.visible : _state.init\" [ngTemplateOutlet]=\"tempItemTemp\"></ng-container>\r\n</div>\r\n<ng-template #tempItemTemp>\r\n    <ng-template [ngTemplateOutlet]=\"_template\"></ng-template>\r\n    <ng-content></ng-content>\r\n</ng-template>\r\n",
                  styles: [""]
              },] }
  ];
  TabItemComponent.ctorParameters = function () { return []; };
  TabItemComponent.propDecorators = {
      recreateOnActive: [{ type: i0.Input }],
      _template: [{ type: i0.ContentChild, args: [i0.TemplateRef,] }],
      visible: [{ type: i0.Input }]
  };

  var TabPanelComponent = /** @class */ (function () {
      function TabPanelComponent() {
          this.selectIndex = 0;
          this.onTabSelectChanged = new i0.EventEmitter();
      }
      TabPanelComponent.prototype.ngAfterContentInit = function () {
          this._tabItems = this._queryTapItems.toArray();
      };
      TabPanelComponent.prototype.ngAfterViewInit = function () {
          var children = this.tabPanel.nativeElement.children;
          if (children.length > 0) {
              this._selectTab(children.item(this.selectIndex).getElementsByTagName("a").item(0));
          }
          children.item(this.selectIndex).getElementsByTagName("a").item(0);
      };
      TabPanelComponent.prototype.ngOnInit = function () {
      };
      TabPanelComponent.prototype._onSelectIndexChanged = function (e) {
          var ele = e.target;
          if (ele.tagName.toLowerCase() !== "a") {
              return;
          }
          if (ele.hasAttribute("active")) {
              return;
          }
          this._selectTab(ele);
      };
      TabPanelComponent.prototype._selectTab = function (element) {
          var _this = this;
          var tabItem = this._tabItems[this.selectIndex];
          if (this._lastLinkSelect) {
              this._lastLinkSelect.classList.remove("active");
              tabItem.visible = false;
          }
          var li = element.parentElement;
          this.selectIndex = Array.from(li.parentElement.children).indexOf(li);
          tabItem = this._tabItems[this.selectIndex];
          this._lastLinkSelect = element;
          this._lastLinkSelect.classList.add("active");
          setTimeout(function () {
              tabItem.activate();
              _this.onTabSelectChanged.emit(_this.selectIndex);
          });
      };
      return TabPanelComponent;
  }());
  TabPanelComponent.decorators = [
      { type: i0.Component, args: [{
                  selector: 'share-tab-panel',
                  template: "<ul (click)=\"_onSelectIndexChanged($event)\" #tabPanel class=\"nav nav-pills mb-3\">\r\n    <ng-container *ngFor=\"let title of tabsTitle; let i = index\">\r\n        <li class=\"nav-item\">\r\n            <a class=\"nav-link\">\r\n                {{title}}\r\n            </a>\r\n        </li>\r\n    </ng-container>\r\n</ul>\r\n<div class=\"tab-content\">\r\n    <ng-content></ng-content>\r\n</div>\r\n",
                  styles: [".nav-item>a{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer}.nav-item>.nav-link{font-size:14px}"]
              },] }
  ];
  TabPanelComponent.ctorParameters = function () { return []; };
  TabPanelComponent.propDecorators = {
      _queryTapItems: [{ type: i0.ContentChildren, args: [TabItemComponent,] }],
      tabPanel: [{ type: i0.ViewChild, args: ["tabPanel",] }],
      tabsTitle: [{ type: i0.Input }],
      selectIndex: [{ type: i0.Input }],
      onTabSelectChanged: [{ type: i0.Output }]
  };

  var Dialog = /** @class */ (function () {
      function Dialog() {
      }
      return Dialog;
  }());

  var DevExtreamDialog = /** @class */ (function (_super) {
      __extends(DevExtreamDialog, _super);
      function DevExtreamDialog() {
          var _this = _super.call(this) || this;
          _this._isCreateStack = false;
          _this._dialogQueue = [];
          return _this;
      }
      DevExtreamDialog.prototype.info = function (title, message, btnText) {
          return this._runDialog({
              title: title,
              message: message,
              type: DialogType.Info,
              buttons: [
                  {
                      text: btnText || "ตกลง"
                  }
              ]
          });
      };
      DevExtreamDialog.prototype.error = function (title, message, btnText) {
          console.error(message);
          return this._runDialog({
              title: title,
              message: message,
              type: DialogType.Error,
              buttons: [
                  {
                      text: btnText || "ตกลง"
                  }
              ]
          });
      };
      DevExtreamDialog.prototype.warning = function (title, message, btnText) {
          return this._runDialog({
              title: title,
              message: message,
              type: DialogType.Warning,
              buttons: [
                  {
                      text: btnText || "ตกลง"
                  }
              ]
          });
      };
      DevExtreamDialog.prototype.confirm = function (title, message, okText, cancelText) {
          return new Promise(function (r) {
              dialog.custom({
                  title: title,
                  messageHtml: "<div class=\"text-center\"></div><br><h4>" + message + "</h4>",
                  buttons: [
                      {
                          icon: "check", text: okText || "ใช่", type: "success", focusStateEnabled: false,
                          onClick: function () { return r(true); }
                      },
                      {
                          icon: "close", text: cancelText || "ไม่", type: "danger",
                          onClick: function () { return r(false); }
                      }
                  ]
              }).show();
          });
      };
      DevExtreamDialog.prototype._runDialog = function (structure) {
          var dialog;
          var resolver = new rxjs.Subject();
          if (this._dialogQueue.length > 0) {
              this._dialogQueue.push({
                  structure: structure,
                  resolver: resolver
              });
              this._stackDialog();
          }
          else {
              dialog = this._createDialog(structure);
              dialog.show();
              this._dialogQueue.push({
                  structure: structure,
                  intenralDialog: dialog,
                  resolver: resolver
              });
          }
          this._updateStack();
          return resolver.toPromise();
      };
      DevExtreamDialog.prototype._createDialog = function (structure) {
          var _this = this;
          var dialog$1;
          var button = __spread(structure.buttons);
          button[0].onClick = function () {
              var dialogQueue = _this._dialogQueue[0];
              dialogQueue.resolver.complete();
              _this._dialogQueue.shift();
              if (_this._dialogQueue.length > 1) {
                  dialogQueue = _this._dialogQueue[0];
                  dialogQueue.intenralDialog = _this._createDialog(dialogQueue.structure);
                  dialogQueue.intenralDialog.show();
              }
              else {
                  _this._unstackDialog();
              }
          };
          if (this._isCreateStack) {
              button.push({
                  text: "\u0E1B\u0E34\u0E14 (" + (this._dialogQueue.length - 1) + ")",
                  onClick: function () {
                      _this._dialogQueue.forEach(function (d) { return d.resolver.complete(); });
                      _this._dialogQueue.length = 0;
                      _this._isCreateStack = false;
                  },
                  elementAttr: { id: "stackBtn" }
              });
          }
          dialog$1 = dialog.custom({
              title: structure.title,
              messageHtml: structure.message,
              buttons: button
          });
          return dialog$1;
      };
      DevExtreamDialog.prototype._stackDialog = function () {
          var _this = this;
          if (this._dialogQueue.length === 0 || this._isCreateStack) {
              return;
          }
          var openDialog = this._dialogQueue[0];
          openDialog.intenralDialog.hide();
          this._isCreateStack = true;
          setTimeout(function () {
              openDialog.intenralDialog = _this._createDialog(openDialog.structure);
              openDialog.intenralDialog.show();
          });
      };
      DevExtreamDialog.prototype._updateStack = function () {
          if (!this._isCreateStack) {
              return;
          }
          var stackBtn = document.querySelectorAll("#stackBtn .dx-button-text").item(0);
          if (stackBtn) {
              stackBtn.textContent = "\u0E1B\u0E34\u0E14 (" + (this._dialogQueue.length - 1) + ")";
          }
      };
      DevExtreamDialog.prototype._unstackDialog = function () {
          if (this._dialogQueue.length <= 0 || !this._isCreateStack) {
              return;
          }
          var openDialog = this._dialogQueue[0];
          this._isCreateStack = false;
          openDialog.intenralDialog = this._createDialog(openDialog.structure);
          openDialog.intenralDialog.show();
      };
      return DevExtreamDialog;
  }(Dialog));
  DevExtreamDialog.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function DevExtreamDialog_Factory() { return new DevExtreamDialog(); }, token: DevExtreamDialog, providedIn: "root" });
  DevExtreamDialog.decorators = [
      { type: i0.Injectable, args: [{
                  providedIn: 'root'
              },] }
  ];
  DevExtreamDialog.ctorParameters = function () { return []; };
  var DialogType;
  (function (DialogType) {
      DialogType[DialogType["Info"] = 0] = "Info";
      DialogType[DialogType["Warning"] = 1] = "Warning";
      DialogType[DialogType["Error"] = 2] = "Error";
  })(DialogType || (DialogType = {}));

  var DxButtonImproveComponent = /** @class */ (function () {
      function DxButtonImproveComponent(cd) {
          this.cd = cd;
          this.visible = true;
          this.waitIcon = "fas fa-circle-notch fa-spin";
          this.disableOnWait = false;
          this.onClick = new i0.EventEmitter();
          this._isWait = false;
      }
      DxButtonImproveComponent.prototype.OnInitialized = function (e) {
          this._widget = e.component;
      };
      DxButtonImproveComponent.prototype.OnClicked = function (e) {
          var _this = this;
          if (this._isWait) {
              return;
          }
          this.onClick.emit({
              event: e,
              startWait: function () { return _this.StartWait(); },
              stopWait: function () { return _this.StopWait(); }
          });
      };
      DxButtonImproveComponent.prototype.Click = function () {
          this._widget.element().click();
      };
      DxButtonImproveComponent.prototype.StartWait = function () {
          this._isWait = true;
          this._oldIcon = this.icon;
          this.icon = this.waitIcon;
          if (this.waitText) {
              this._oldIcon = this.text;
              this.text = this.waitText;
          }
          this.disabled = this.disableOnWait;
      };
      DxButtonImproveComponent.prototype.StopWait = function () {
          this._isWait = false;
          this.icon = this._oldIcon;
          this.disabled = false;
          if (this.waitText) {
              this.text = this._oldIcon;
          }
          this.cd.markForCheck();
      };
      return DxButtonImproveComponent;
  }());
  DxButtonImproveComponent.decorators = [
      { type: i0.Component, args: [{
                  // tslint:disable-next-line: component-selector
                  selector: 'dx-button-improve',
                  template: "<dx-button\r\n    [class]=\"widgetClass\"\r\n    [type]=\"type\"\r\n    [text]=\"text\"\r\n    [icon]=\"icon\"\r\n    [height]=\"height\"\r\n    [width]=\"width\"\r\n    [disabled]=\"disabled\"\r\n    [visible]=\"visible\"\r\n    [hint]=\"hint\"\r\n    (onClick)=\"OnClicked($event)\"\r\n    (onInitialized)=\"OnInitialized($event)\"\r\n>\r\n</dx-button>\r\n"
              },] }
  ];
  DxButtonImproveComponent.ctorParameters = function () { return [
      { type: i0.ChangeDetectorRef }
  ]; };
  DxButtonImproveComponent.propDecorators = {
      widgetClass: [{ type: i0.Input }],
      text: [{ type: i0.Input }],
      type: [{ type: i0.Input }],
      icon: [{ type: i0.Input }],
      height: [{ type: i0.Input }],
      hint: [{ type: i0.Input }],
      width: [{ type: i0.Input }],
      disabled: [{ type: i0.Input }],
      visible: [{ type: i0.Input }],
      waitIcon: [{ type: i0.Input }],
      waitText: [{ type: i0.Input }],
      disableOnWait: [{ type: i0.Input }],
      onClick: [{ type: i0.Output }]
  };

  var DxDatePipe = /** @class */ (function () {
      function DxDatePipe() {
      }
      DxDatePipe.prototype.transform = function (date, format) {
          if (format === void 0) { format = "dateThai"; }
          if (typeof date === "string") {
              return localization.formatDate(luxon.DateTime.fromFormat(date, "YYYY-MM-DD").toJSDate(), format);
          }
          return localization.formatDate(date, format);
      };
      return DxDatePipe;
  }());
  DxDatePipe.decorators = [
      { type: i0.Pipe, args: [{ name: 'dxDate' },] }
  ];

  var FileSizePipe = /** @class */ (function () {
      function FileSizePipe() {
          this.units = [
              'B',
              'KB',
              'MB',
              'GB',
              'TB',
              'PB'
          ];
      }
      FileSizePipe.prototype.transform = function (bytes, precision) {
          if (bytes === void 0) { bytes = 0; }
          if (precision === void 0) { precision = 2; }
          if (isNaN(parseFloat(String(bytes))) || !isFinite(bytes)) {
              return '?';
          }
          else if (bytes === 0) {
              return "0 B";
          }
          var i = Math.floor(Math.log(bytes) / Math.log(1024));
          return (bytes / Math.pow(1024, i)).toFixed(precision) + ' ' + this.units[i];
      };
      return FileSizePipe;
  }());
  FileSizePipe.decorators = [
      { type: i0.Pipe, args: [{ name: 'fileSize' },] }
  ];

  var ControlModule = /** @class */ (function () {
      function ControlModule() {
      }
      return ControlModule;
  }());
  ControlModule.decorators = [
      { type: i0.NgModule, args: [{
                  declarations: [DxButtonImproveComponent, DxDatePipe, FileSizePipe],
                  imports: [
                      common.CommonModule,
                      devextremeAngular.DxButtonModule
                  ],
                  exports: [DxButtonImproveComponent,
                      DxDatePipe,
                      FileSizePipe],
                  schemas: [i0.CUSTOM_ELEMENTS_SCHEMA]
              },] }
  ];

  function storageFactory() {
      return localStorage;
  }
  var ShareUiModule = /** @class */ (function () {
      function ShareUiModule(injecttor) {
          this.injecttor = injecttor;
          localization.locale("th-TH");
          StaticBag.InjectorInstance = injecttor;
      }
      ShareUiModule.forRoot = function (config) {
          return {
              ngModule: ShareUiModule,
              providers: [
                  { provide: SHARE_UI_CONFIG, useValue: config },
                  { provide: Dialog, useExisting: DevExtreamDialog },
              ]
          };
      };
      return ShareUiModule;
  }());
  ShareUiModule.decorators = [
      { type: i0.NgModule, args: [{
                  declarations: [
                      ShareUiComponent,
                      SidebarComponent,
                      TabPanelComponent,
                      TabItemComponent
                  ],
                  imports: [
                      //
                      common.CommonModule,
                      http.HttpClientModule,
                      ControlModule
                      // OAuthModule.forRoot()
                  ],
                  exports: [TabPanelComponent, TabItemComponent]
              },] }
  ];
  ShareUiModule.ctorParameters = function () { return [
      { type: i0.Injector }
  ]; };
  // function initializeKeycloak(keycloak: KeycloakService) {
  //     return () =>
  //         keycloak.init({
  //             config: {
  //                 url: 'http://localhost:8080/auth',
  //                 realm: 'Ky-App',
  //                 clientId: 'MyClient',
  //             },
  //             initOptions: {
  //                 enableLogging: true,
  //                 onLoad: 'login-required',
  //                 silentCheckSsoRedirectUri:
  //                     window.location.origin + '/assets/silent-check-sso.html',
  //             },
  //         });
  // }

  var BetimesOauthService = /** @class */ (function () {
      function BetimesOauthService(config, authServ) {
          var _this = this;
          this.config = config;
          this.authServ = authServ;
          this.authServ.configure(this.config.authConfig);
          this.authServ.events.subscribe(function (e) {
              switch (e.type) {
                  case "token_received":
                      _this.authServ.loadUserProfile();
                      break;
                  case "session_terminated":
                  case "session_error":
                      _this.login("");
                      break;
                  default:
                      break;
              }
          });
          this.authServ.setupAutomaticSilentRefresh();
      }
      Object.defineProperty(BetimesOauthService.prototype, "identityClaims", {
          get: function () { return this.authServ.getIdentityClaims(); },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(BetimesOauthService.prototype, "accessToken", {
          get: function () { return this.authServ.getAccessToken(); },
          enumerable: false,
          configurable: true
      });
      BetimesOauthService.prototype.hasTokenValid = function () {
          return this.authServ.hasValidAccessToken() &&
              this.authServ.hasValidIdToken();
      };
      Object.defineProperty(BetimesOauthService.prototype, "oauth2", {
          get: function () { return this.authServ; },
          enumerable: false,
          configurable: true
      });
      BetimesOauthService.prototype.initOauth = function () {
          var _this = this;
          return this.authServ
              .loadDiscoveryDocument()
              .then(function () {
              return _this.authServ.tryLogin();
          })
              .then(function () {
              if (_this.authServ.hasValidAccessToken()) {
                  if (_this.authServ.sessionChecksEnabled) {
                      _this.authServ.sessionCheckIFrameUrl += "?client_id=" + _this.authServ.clientId + "&redirect_uri=" + _this.authServ.redirectUri;
                      _this.authServ.restartSessionChecksIfStillLoggedIn();
                  }
                  return Promise.resolve(true);
              }
              if (_this.config.authConfig.autoLogin) {
                  _this.login();
              }
              return Promise.resolve(false);
              // return this.refresh().then(() => Promise.resolve())
              //     .catch(err => {
              //         if (this.checkUserInteractionRequiredOnRefreshFailure(err)) {
              //             if (this.config.authConfig.autoLogin) {
              //                 this.login();
              //             }
              //         }
              //         return Promise.reject(err);
              //     });
          })
              .catch(function (err) {
              console.error(err);
              return Promise.resolve(false);
          });
      };
      BetimesOauthService.prototype.refresh = function () {
          return this.authServ.responseType === "code" ?
              this.authServ.refreshToken() :
              this.authServ.silentRefresh();
      };
      BetimesOauthService.prototype.login = function (targetUrl) {
          this.authServ.initLoginFlow(targetUrl);
      };
      BetimesOauthService.prototype.logout = function () {
          if (this.config.authConfig.revokeTokenOnLogout) {
              this.authServ.revokeTokenAndLogout();
          }
          else {
              this.authServ.logOut();
          }
      };
      BetimesOauthService.prototype.checkUserInteractionRequiredOnRefreshFailure = function (errorObj) {
          var errorCodes = [
              'invalid_grant',
              'interaction_required',
              'login_required',
              'account_selection_required',
              'consent_required'
          ];
          var k = this.authServ.responseType === 'code' ? 'error' : 'reason';
          return errorObj
              && errorObj[k]
              && errorCodes.indexOf(errorObj[k].error) >= 0;
      };
      return BetimesOauthService;
  }());
  BetimesOauthService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function BetimesOauthService_Factory() { return new BetimesOauthService(i0__namespace.ɵɵinject(SHARE_UI_CONFIG), i0__namespace.ɵɵinject(i1__namespace.OAuthService)); }, token: BetimesOauthService, providedIn: "root" });
  BetimesOauthService.decorators = [
      { type: i0.Injectable, args: [{
                  providedIn: 'root'
              },] }
  ];
  BetimesOauthService.ctorParameters = function () { return [
      { type: undefined, decorators: [{ type: i0.Inject, args: [SHARE_UI_CONFIG,] }] },
      { type: i1.OAuthService }
  ]; };

  var InternalCache = /** @class */ (function () {
      function InternalCache() {
      }
      InternalCache.Set = function (key, value) {
          localStorage.setItem(key, value);
      };
      InternalCache.Get = function (key) {
          var cache = localStorage.getItem(key);
          if (!cache) {
              return undefined;
          }
          var parse = cache;
          try {
              parse = JSON.parse(cache);
          }
          catch (error) {
          }
          return parse;
      };
      InternalCache.Delete = function (key) {
          localStorage.removeItem(key);
      };
      InternalCache.DeleteAll = function () {
          localStorage.clear();
      };
      return InternalCache;
  }());

  function IsHttpResultValue(obj) {
      return obj && IsHttpResult(obj) && "Value" in obj;
  }
  function IsHttpResult(obj) {
      return obj && "IsSuccess" in obj;
  }
  function IsHttpProgressEvent(obj) {
      return obj && "loaded" in obj && "total" in obj;
  }

  var BetimesHttpInterceptor = /** @class */ (function () {
      function BetimesHttpInterceptor(_dialog) {
          this._dialog = _dialog;
      }
      BetimesHttpInterceptor.prototype.intercept = function (req, next) {
          var _this = this;
          if (!(req instanceof BetimesRequest)) {
              return next.handle(req);
          }
          var cacheName = "req:" + req.urlWithParams;
          if (req.useCacheInvalidate) {
              InternalCache.Delete(cacheName);
          }
          else if (req.useCache) {
              var cache = InternalCache.Get(cacheName);
              if (cache) {
                  return rxjs.of(cache);
              }
          }
          return next.handle(req).pipe(operators.filter(function (event) { return event.type === 1 || event.type === 4; }), operators.map(function (_) {
              if (_.type === 1) {
                  return _;
              }
              var respone = _;
              switch (req.responseType) {
                  case "blob":
                      if (respone.body !== null && !(respone.body instanceof Blob)) {
                          if (req.displayCriticalError) {
                              _this._dialog.error("เกิดข้อผิดพลาด", "ผลลัพธ์ไม่ได้อยู่ในรูปแบบ Blob");
                          }
                          throw new Error('ผลลัพธ์ไม่ได้อยู่ในรูปแบบ Blob');
                      }
                      /*
                          กรณีนี้จะเกิดขึ้นเมื่อ api ได้การตรวจสอบแล้วพบว่ามีข้อผิดพลาดเกิดขึ้น
                          จึงได้ส่งค่ากลับมาเป็นในรูปแบบ StatusResult
                      */
                      if (respone.body.type === "application/json") {
                          _this.readJsonAsync(respone.body).then(function (r) {
                              if (IsHttpResult(r) && req.displayError) {
                                  _this._dialog.error("เกิดข้อผิดพลาด", r.Message);
                              }
                          });
                          throw new Error('ผลลัพธ์ไม่ได้อยู่ในรูปแบบที่ประมวลผลเป็น binary');
                      }
                      return respone.body;
                  case "json":
                      _this.checkError(respone.body, req);
                      var body = respone.body;
                      if (body.IsSuccess && req.useOnlyValue) {
                          if (req.method.toLowerCase() === "get" && req.useCache) {
                              InternalCache.Set(cacheName, JSON.stringify(body.Value));
                          }
                          return body.Value;
                      }
                      return body;
              }
              return respone;
          }), operators.catchError(function (error) { return __awaiter(_this, void 0, void 0, function () {
              var errorMessage, _a, readReult;
              return __generator(this, function (_b) {
                  switch (_b.label) {
                      case 0:
                          if (!(error instanceof http.HttpErrorResponse && req.displayCriticalError && error.status !== 401)) return [3 /*break*/, 8];
                          errorMessage = "เกิดปัญหาทางเซิฟเวอร์ไม่สามารถดำเนินการต่อได้";
                          _a = error.status;
                          switch (_a) {
                              case 400: return [3 /*break*/, 1];
                              case 404: return [3 /*break*/, 2];
                              case 500: return [3 /*break*/, 3];
                          }
                          return [3 /*break*/, 7];
                      case 1:
                          errorMessage = "การส่งข้อมูลผิดรูปแบบ";
                          return [3 /*break*/, 7];
                      case 2:
                          errorMessage = "ไม่พบ URL ที่ร้องขอ";
                          return [3 /*break*/, 7];
                      case 3:
                          if (!IsHttpResult(error.error)) return [3 /*break*/, 4];
                          errorMessage = error.error.Message;
                          return [3 /*break*/, 6];
                      case 4:
                          if (!(error.error instanceof Blob && error.error.type === "application/json")) return [3 /*break*/, 6];
                          return [4 /*yield*/, this.readJsonAsync(error.error)];
                      case 5:
                          readReult = _b.sent();
                          if (IsHttpResult(readReult)) {
                              errorMessage = readReult.Message;
                          }
                          _b.label = 6;
                      case 6: return [3 /*break*/, 7];
                      case 7:
                          this._dialog.error("เกิดข้อผิดพลาด", errorMessage);
                          _b.label = 8;
                      case 8:
                          InternalCache.Delete(cacheName);
                          throw error;
                  }
              });
          }); }));
      };
      BetimesHttpInterceptor.prototype.checkError = function (httpResult, req) {
          if (req.useOnlyValue) {
              if (!IsHttpResult(httpResult)) {
                  if (req.displayCriticalError) {
                      this._dialog.error("เกิดข้อผิดพลาด", "ผลลัพธ์ไม่ได้อยู่ในรูปแบบ StatusResult");
                  }
                  throw new Error("ผลลัพธ์ไม่ได้อยู่ในรูปแบบ StatusResult");
              }
              if (!httpResult.IsSuccess) {
                  if (req.displayError) {
                      this._dialog.error("\u0E40\u0E01\u0E34\u0E14\u0E02\u0E49\u0E2D\u0E1C\u0E34\u0E14\u0E1E\u0E25\u0E32\u0E14: " + httpResult.StatusCode, httpResult.Message);
                  }
                  throw new BetimesHttpResultError(httpResult);
              }
          }
      };
      BetimesHttpInterceptor.prototype.readJsonAsync = function (blob) {
          return rxjs.Observable.create(function (obs) {
              var blobReader = new FileReader();
              blobReader.readAsText(blob);
              blobReader.onload = function () {
                  obs.next(JSON.parse(blobReader.result));
                  obs.complete();
              };
          }).toPromise();
      };
      return BetimesHttpInterceptor;
  }());
  BetimesHttpInterceptor.decorators = [
      { type: i0.Injectable }
  ];
  BetimesHttpInterceptor.ctorParameters = function () { return [
      { type: Dialog }
  ]; };

  var AuthGuard = /** @class */ (function () {
      function AuthGuard(oauthServ) {
          this.oauthServ = oauthServ;
      }
      AuthGuard.prototype.canActivate = function (route, state) {
          if (this.oauthServ.hasTokenValid()) {
              return true;
          }
          // this.oauthServ.login("");
          return false;
      };
      return AuthGuard;
  }());
  AuthGuard.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function AuthGuard_Factory() { return new AuthGuard(i0__namespace.ɵɵinject(BetimesOauthService)); }, token: AuthGuard, providedIn: "root" });
  AuthGuard.decorators = [
      { type: i0.Injectable, args: [{
                  providedIn: 'root'
              },] }
  ];
  AuthGuard.ctorParameters = function () { return [
      { type: BetimesOauthService }
  ]; };

  var FileServer = /** @class */ (function () {
      function FileServer(_http, _baseApiUrl) {
          this._http = _http;
          this._baseApiUrl = _baseApiUrl;
          this._skipProgressing = true;
          this._uploadParamName = "file";
      }
      FileServer.connect = function (host) {
          if (!host) {
              host = StaticBag.InjectorInstance.get(SHARE_UI_CONFIG).apiUrl;
          }
          return new FileServer(StaticBag.InjectorInstance.get(http.HttpClient), host);
      };
      FileServer.prototype.file = function (endpoint) {
          if (endpoint === void 0) { endpoint = "file"; }
          this._endpoint = endpoint;
          return this;
      };
      FileServer.prototype.identity = function (id) {
          this._fileId = id;
          return this;
      };
      FileServer.prototype.withVerb = function (httpVerb) {
          this._fileActionVerb = httpVerb;
          return undefined;
      };
      FileServer.prototype.view = function () {
          var url = this._baseApiUrl + "/" + this._endpoint;
          var request = req(url)
              .useSystemResult()
              .responseType("blob");
          switch (this._fileActionVerb) {
              case "POST":
                  return request.body(this._param).post();
              default:
                  return request.queryString(this._param).get();
          }
      };
      FileServer.prototype.delete = function () {
          var verb = this._fileActionVerb || "DELETE";
          return undefined;
      };
      FileServer.prototype.upload = function (endpoint) {
          if (endpoint === void 0) { endpoint = "file/upload"; }
          this._endpoint = endpoint;
          return this;
      };
      FileServer.prototype.isReportProgressing = function () {
          this._skipProgressing = false;
          return this;
      };
      FileServer.prototype.withUploadParamName = function (uploadName) {
          this._uploadParamName = uploadName;
          return this;
      };
      FileServer.prototype.withParam = function (p) {
          this._param = p;
          return this;
      };
      FileServer.prototype.fromFile = function (files) {
          var _this = this;
          var uploadObser = new UploadObserver();
          if (!files) {
              throw new Error("not found file upload");
          }
          files.forEach(function (file) {
              var formData = new FormData();
              formData.append(_this._uploadParamName, file);
              for (var param in _this._param) {
                  formData.append(param, _this._param[param]);
              }
              _this._startUpload(formData, uploadObser);
          });
          return uploadObser;
      };
      FileServer.prototype.fromFormData = function (formData) {
          if (!formData) {
              throw new Error("not found file upload");
          }
          var uploadObser = new UploadObserver();
          this._startUpload(formData, uploadObser);
          return uploadObser;
      };
      FileServer.prototype._startUpload = function (formData, observ) {
          var url = this._baseApiUrl + "/" + this._endpoint;
          var httpReq = new http.HttpRequest("POST", url, formData, { reportProgress: !this._skipProgressing });
          var progress = new rxjs.Subject();
          var progressObj = {
              FileName: undefined, FileSize: undefined,
              PercentToComplete: 0, Status: exports.UploadStatus.Ready, ErrorMessage: undefined
          };
          var fileInfo = formData.get(this._uploadParamName);
          if (fileInfo instanceof File) {
              progressObj.FileName = fileInfo.name;
              progressObj.FileSize = fileInfo.size;
          }
          this._http.request(httpReq).subscribe(function (event) {
              if (event.type === http.HttpEventType.UploadProgress) {
                  var percentDone = Math.round(100 * event.loaded / event.total);
                  progressObj.PercentToComplete = percentDone;
                  progressObj.Status = exports.UploadStatus.Uploading;
                  progress.next(progressObj);
              }
              else if (event.type === http.HttpEventType.Response) {
                  progressObj.Status = exports.UploadStatus.Success;
                  progress.complete();
              }
          }, function (_) {
              if (_ instanceof http.HttpErrorResponse) {
                  progressObj.ErrorMessage = _.error.Message || _.message;
              }
              else {
                  progressObj.ErrorMessage = _;
              }
              progressObj.Status = exports.UploadStatus.Failure;
              progress.next(progressObj);
          });
          observ.AddObserver(progress.asObservable());
      };
      return FileServer;
  }());
  var UploadObserver = /** @class */ (function () {
      function UploadObserver() {
          this._observer = [];
      }
      UploadObserver.prototype.AddObserver = function (obser) {
          this._observer.push(obser);
      };
      UploadObserver.prototype.Subscribe = function (next, complete) {
          var subscribe = rxjs.from(this._observer).pipe(operators.mergeAll())
              .subscribe({
              next: next,
              complete: function () {
                  subscribe.unsubscribe();
                  complete();
              }
          });
      };
      return UploadObserver;
  }());
  exports.UploadStatus = void 0;
  (function (UploadStatus) {
      UploadStatus[UploadStatus["Ready"] = 0] = "Ready";
      UploadStatus[UploadStatus["Uploading"] = 1] = "Uploading";
      UploadStatus[UploadStatus["Failure"] = 2] = "Failure";
      UploadStatus[UploadStatus["Success"] = 3] = "Success";
  })(exports.UploadStatus || (exports.UploadStatus = {}));

  /*
   * Public API Surface of share-ui
   */

  /**
   * Generated bundle index. Do not edit.
   */

  exports.AuthGuard = AuthGuard;
  exports.BetimesHttpInterceptor = BetimesHttpInterceptor;
  exports.BetimesHttpRequest = BetimesHttpRequest;
  exports.BetimesHttpResultError = BetimesHttpResultError;
  exports.BetimesOauthService = BetimesOauthService;
  exports.BetimesRequest = BetimesRequest;
  exports.ControlModule = ControlModule;
  exports.DevExtreamDialog = DevExtreamDialog;
  exports.Dialog = Dialog;
  exports.DxButtonImproveComponent = DxButtonImproveComponent;
  exports.DxDatePipe = DxDatePipe;
  exports.FileServer = FileServer;
  exports.FileSizePipe = FileSizePipe;
  exports.InternalCache = InternalCache;
  exports.SHARE_UI_CONFIG = SHARE_UI_CONFIG;
  exports.ShareUiComponent = ShareUiComponent;
  exports.ShareUiModule = ShareUiModule;
  exports.TabItemComponent = TabItemComponent;
  exports.TabPanelComponent = TabPanelComponent;
  exports.req = req;
  exports.storageFactory = storageFactory;
  exports["ɵa"] = SidebarComponent;
  exports["ɵb"] = ConfigulationService;
  exports["ɵc"] = OrganizeInfoService;
  exports["ɵd"] = StaticBag;

  Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=share-ui.umd.js.map
