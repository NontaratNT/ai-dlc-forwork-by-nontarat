import * as i0 from '@angular/core';
import { Component, Injectable, Inject, Optional, InjectionToken, Input, ContentChild, TemplateRef, EventEmitter, ContentChildren, ViewChild, Output, ChangeDetectorRef, Pipe, NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import * as i1 from 'angular-oauth2-oidc';
import { OAuthModuleConfig, OAuthService } from 'angular-oauth2-oidc';
import { HttpHeaders, HttpRequest, HttpParams, HttpClient, HttpClientModule, HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { locale, formatDate } from 'devextreme/localization';
import objectAssign from 'object-assign';
import dateLocalization from 'devextreme/localization/date';
import * as dxVersion from 'devextreme/core/version';
import * as compareVersions from 'devextreme/core/utils/version';
import { custom } from 'devextreme/ui/dialog';
import { Subject, of, Observable, from } from 'rxjs';
import { DateTime } from 'luxon';
import { DxButtonModule } from 'devextreme-angular';
import { __awaiter } from 'tslib';
import { filter, map, catchError, mergeAll } from 'rxjs/operators';

class ShareUiComponent {
    constructor() { }
    ngOnInit() {
    }
}
ShareUiComponent.decorators = [
    { type: Component, args: [{
                selector: 'share-share-ui',
                template: `
    <p>
      share-ui works!
    </p>
  `
            },] }
];
ShareUiComponent.ctorParameters = () => [];

class ConfigulationService {
    constructor(environment, oAuthModuleConfig) {
        this.environment = environment;
        this.oAuthModuleConfig = oAuthModuleConfig;
        this._config = {};
        this.Init();
        this.InitAuth();
        // this.oAuthModuleConfig = {
        //     resourceServer: {
        //         allowedUrls: [this._config.apiUrl],
        //         sendAccessToken: true
        //     }
        // };
    }
    InitAuth() {
        const authUrl = 'https://bne01.demotoday.net/auth';
        const clientId = "demo-app";
        const redirectUri = `${this._config.originUrl}/home`;
        this._config.authConfig = {
            autoLogin: true,
            revokeTokenOnLogout: false,
            issuer: `${authUrl}/realms/demo`,
            clientId,
            redirectUri,
            silentRefreshRedirectUri: `${this._config.originUrl}/silent-refresh.html`,
            postLogoutRedirectUri: `${this._config.originUrl}/home`,
            skipIssuerCheck: true,
            strictDiscoveryDocumentValidation: false,
            responseType: 'code',
            disablePKCE: false,
            // scope: 'openid profile email offline_access api',
            silentRefreshTimeout: 50000,
            timeoutFactor: 0.75,
            sessionChecksEnabled: true,
            showDebugInformation: true,
            clearHashAfterLogin: false
        };
    }
    Init() {
        this._config.originUrl = window.location.origin;
        // Init apiUrl
        if (this.environment.production) {
            this._config.apiUrl = "https://wfhapi.demotoday.net/api";
        }
        else if (this.environment.staging) {
            this._config.apiUrl = "http://localhost:44307/api";
            // this._config.apiUrl = "https://sarabun.demotoday.net/covid/api";
        }
        else {
            this._config.apiUrl = "http://localhost:44307/api";
        }
        // Init assetUrl
        if (this.environment.production) {
            this._config.resourceUrl = "https://wfh.demotoday.net/resource/wfh";
        }
        else {
            this._config.resourceUrl = "http://sarabun.demotoday.net/resource/wfh";
        }
        // Init reportUrl
        this._config.reportUrl = 'https://wfh.demotoday.net/rpt';
    }
    get Config() {
        return this._config;
    }
}
ConfigulationService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ConfigulationService_Factory() { return new ConfigulationService(i0.ɵɵinject("env"), i0.ɵɵinject(i1.OAuthModuleConfig, 8)); }, token: ConfigulationService, providedIn: "root" });
ConfigulationService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ConfigulationService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: ['env',] }] },
    { type: OAuthModuleConfig, decorators: [{ type: Optional }] }
];

const StaticBag = {
    InjectorInstance: undefined
};

const SHARE_UI_CONFIG = new InjectionToken('config');

class BetimesHttpRequest {
    constructor(http) {
        this.http = http;
        this._responseType = "json";
        this._reportProgress = false;
        this._criticalErrorDialog = true;
        this._errorDialog = true;
        // this._header = new HttpHeaders({ 'Content-Type': 'application/json' });
    }
    host(h) {
        this._host = h;
        return this;
    }
    raw() {
        this._raw = true;
        return this;
    }
    api(url) {
        this._url = url;
        return this;
    }
    body(body) {
        this._body = body;
        return this;
    }
    queryString(param) {
        this._param = param;
        return this;
    }
    header(head) {
        if (!(head instanceof HttpHeaders)) {
            this._header = new HttpHeaders(head);
        }
        else {
            this._header = head;
        }
        return this;
    }
    responseType(r) {
        this._responseType = r;
        return this;
    }
    result() {
        return this;
    }
    useSystemResult() {
        this._useSystemReulst = true;
        return this;
    }
    reportProgress() {
        this._reportProgress = true;
        this._useSystemReulst = true;
        return this;
    }
    disableCriticalDialogError() {
        this._criticalErrorDialog = false;
        return this;
    }
    disableDialogError() {
        this._errorDialog = false;
        return this;
    }
    cache() {
        this._useCache = true;
        return this;
    }
    invalidate() {
        this._useCacheInvalidate = true;
        return this;
    }
    post() {
        return this.send("POST");
    }
    get() {
        return this.send("GET");
    }
    patch() {
        return this.send("PATCH");
    }
    put() {
        return this.send("PUT");
    }
    delete() {
        return this.send("DELETE");
    }
    send(method) {
        const urlWithbase = this._host + "/" + this._url;
        let header = this._header;
        if (!header) {
            const contentType = new HttpRequest("POST", "", this._body).detectContentTypeHeader();
            if (contentType) {
                header = new HttpHeaders({ 'Content-Type': contentType });
            }
        }
        const request = new BetimesRequest(method, urlWithbase, this._body, {
            headers: header,
            responseType: this._responseType,
            reportProgress: this._reportProgress,
            params: this._param ? new HttpParams({ fromObject: this._param }) : undefined
        });
        request.displayError = this._errorDialog;
        request.useOnlyValue = (this._useCache || !this._useSystemReulst) && !this._raw;
        request.displayCriticalError = this._criticalErrorDialog;
        request.useCacheInvalidate = this._useCacheInvalidate;
        request.useCache = this._useCache;
        request.raw = this._raw;
        return this.http.request(request);
    }
}
class BetimesRequest extends HttpRequest {
    clone(update) {
        const method = update.method || this.method;
        const url = update.url || this.url;
        const responseType = update.responseType || this.responseType;
        const body = (update.body !== undefined) ? update.body : this.body;
        const withCredentials = (update.withCredentials !== undefined) ? update.withCredentials : this.withCredentials;
        const reportProgress = (update.reportProgress !== undefined) ? update.reportProgress : this.reportProgress;
        let headers = update.headers || this.headers;
        let params = update.params || this.params;
        if (update.setHeaders !== undefined) {
            headers =
                Object.keys(update.setHeaders)
                    // tslint:disable-next-line: no-shadowed-variable
                    .reduce((headers, name) => headers.set(name, update.setHeaders[name]), headers);
        }
        if (update.setParams) {
            params = Object.keys(update.setParams)
                // tslint:disable-next-line: no-shadowed-variable
                .reduce((params, param) => params.set(param, update.setParams[param]), params);
        }
        const request = new BetimesRequest(method, url, body, {
            params, headers, reportProgress, responseType, withCredentials,
        });
        request.displayCriticalError = this.displayCriticalError;
        request.displayError = this.displayError;
        request.useOnlyValue = this.useOnlyValue;
        request.useCache = this.useCache;
        request.useCacheInvalidate = this.useCacheInvalidate;
        return request;
    }
}
class BetimesHttpResultError extends Error {
    constructor(err) {
        super(err.Message);
        this.err = err;
        const actualProto = new.target.prototype;
        if (Object.setPrototypeOf) {
            Object.setPrototypeOf(this, actualProto);
        }
        else {
            this.__proto__ = actualProto;
        }
    }
    get HttpResult() {
        return this.err;
    }
}
function req(api) {
    return new BetimesHttpRequest(StaticBag.InjectorInstance.get(HttpClient))
        .host(StaticBag.InjectorInstance.get(SHARE_UI_CONFIG).apiUrl)
        .api(api)
        .result();
}

// @dynamic
class User {
    static get Current() {
        // if (!User._userInfo) {
        //     const profile = Cookies.getJSON("profile");
        //     User._userInfo = profile || undefined;
        // }
        return undefined;
    }
    static SetUser(userinfo) {
        // User._userInfo = userinfo;
        // Cookies.set("profile", JSON.stringify(userinfo));
    }
    static Save() {
        // Cookies.set("profile", JSON.stringify(User._userInfo));
    }
    static SwitchRole(role) {
        // const profile: UserProfile = User._userInfo;
        // profile.Role = role;
        // Cookies.set("profile", JSON.stringify(profile));
    }
    static Clear() {
        // Cookies.remove("profile");
        // User._userInfo = undefined;
    }
}

class OrganizeInfoService {
    constructor() { }
    GetOrganize(role, includeStatus = true) {
        return req('CmsOrganize')
            .queryString({ roleId: role, RecordStatus: includeStatus })
            .get();
    }
    GetByOrganizeId(id) {
        return req("CmsOrganize/" + id)
            .cache()
            .get();
    }
    GetApps(roleId) {
        return req('CmsOrganize/app')
            .queryString({ roleId: roleId })
            .get();
    }
    InsertOrganizeInfo(param) {
        return req("CmsOrganize")
            .body(param)
            .post();
    }
    GetsOrganizePki(id) {
        return req("CmsOrganize/" + id + '/pki')
            .get();
    }
    UpdateOrganizeInfo(id, param) {
        return req('CmsOrganize/' + id)
            .body(param)
            .put();
    }
    SearchOrganizeName(name, offset, length) {
        return req("CmsOrganize/search")
            .body({
            Condition: {
                ORGANIZE_NAME_THA: name
            }, Offset: offset, Length: length
        })
            .post();
    }
    SearchOrganize(searchObj, offset, length) {
        return req("CmsOrganize/search")
            .body({ Condition: searchObj, Offset: offset, Length: length })
            .queryString({ roleId: User.Current.Role.RoleId })
            .post();
    }
}
OrganizeInfoService.ɵprov = i0.ɵɵdefineInjectable({ factory: function OrganizeInfoService_Factory() { return new OrganizeInfoService(); }, token: OrganizeInfoService, providedIn: "root" });
OrganizeInfoService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
OrganizeInfoService.ctorParameters = () => [];

class SidebarComponent {
    constructor(router, config, orgService) {
        this.router = router;
        this.config = config;
        this.orgService = orgService;
    }
}
SidebarComponent.decorators = [
    { type: Component, args: [{
                selector: 'share-sidebar',
                template: "<!-- <div>\r\n    <div class=\"sidebar-wrapper\" style=\"margin-top: 45px;\">\r\n        <div class=\"recomment p-2\">\r\n            <i class=\"fas fa-shield-alt mb-2\"></i>\r\n            <div class=\"dx-field\" style=\"margin-top: 0px;\">\r\n                <div class=\"dx-field-label\" style=\"color: white!important; padding-left: 20px; width: 30%;\">\r\n                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\u0E1A\u0E17\u0E1A\u0E32\u0E17</div>\r\n                <div class=\"dx-field-value\" style=\"width: 70%;\">\r\n                    <dx-select-box #roleBox [(value)]=\"curRoleId\" valueExpr=\"RoleId\" [items]=\"roleList\"\r\n                        style=\"width: 90%;\" displayExpr=\"RoleName\" placeholder=\"\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1A\u0E17\u0E1A\u0E32\u0E17\" [width]=\"143\"\r\n                        (onValueChanged)=\"OnRoleSelected($event)\">\r\n                    </dx-select-box>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <dx-tree-view [dataSource]=\"_menuList\" [hoverStateEnabled]=\"false\" [focusStateEnabled]=\"false\"\r\n            [selectNodesRecursive]=\"true\" noDataText=\"\" dataStructure=\"plain\" keyExpr=\"MODULE_ID\"\r\n            displayExpr=\"MODULE_NAME\" parentIdExpr=\"MODULE_PARENT_ID\" itemTemplate=\"_menuList\"\r\n            (onItemClick)=\"MenuClicked($event)\">\r\n\r\n            <div *dxTemplate=\"let item of '_menuList'\">\r\n\r\n                <div class=\"recomment p-2\" style=\"background-color: #c4cfd402 !important\">\r\n                    <i class='fas {{item.MODULE_ICON}}' style=\"color : #000000\"></i>\r\n                    <div class=\"dx-field\">\r\n                        <a class=\"nav-link\" routerLinkActive=\"active\">\r\n                            <div class='fas {{item.MODULE_ICON}}' style=\"font-size: 23px;\"></div>\r\n                            <div class=\"dx-field-value\" style=\"font-size: 12px;\r\n                            margin-right: 34px !important;\r\n                            margin-top: 0px; width: 100%;\r\n    margin-left: 10px;\">\r\n                                {{item.MODULE_NAME}}\r\n                            </div>\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n\r\n        </dx-tree-view>\r\n    </div>\r\n</div> -->\r\n",
                styles: [":host .nav-link{display:flex;margin:0;border-radius:3px;color:#000;padding-left:10px;padding-right:10px;text-transform:capitalize;font-size:13px}:host ::ng-deep li:hover .nav-link{color:#000}:host ::ng-deep .dx-field:last-of-type{width:120%;margin-left:-30px;margin-top:-15px;height:50px;padding-left:30px;padding-top:6px}:host ::ng-deep .dx-treeview-node-container-opened>.dx-treeview-node>.dx-treeview-node-is-leaf:hover>.dx-treeview-item .dx-field,:host ::ng-deep .dx-treeview-node-container>.dx-treeview-node:hover>.dx-treeview-item .dx-field{background:#fcf0c5!important;width:120%;margin-left:-30px;margin-top:-15px;height:50px;padding-left:30px;padding-top:6px}:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .dx-treeview-item{background:transparent}:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .dx-field{background:#fcf0c5!important;width:120%;margin-left:-30px;margin-top:-15px;height:50px;padding-left:30px;padding-top:6px}:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .nav-link>i,:host ::ng-deep .dx-treeview-node-is-leaf.dx-state-selected .nav-link>p{color:#0b314f}:host ::ng-deep .dx-treeview-node{padding:0}:host ::ng-deep .dx-treeview-node-container-opened .dx-treeview-node{padding-left:15px}:host ::ng-deep .nav-link i{font-size:24px;float:left;margin-right:15px;line-height:30px;width:30px;text-align:center;color:#000}:host ::ng-deep .dx-treeview-node-container-opened .dx-treeview-node .nav-link i{font-size:17px}:host ::ng-deep .nav-link p{margin:0;line-height:30px;font-size:14px;position:relative;display:block;height:auto}:host ::ng-deep .dx-treeview-toggle-item-visibility{top:13px;left:210px;color:#000}::ng-deep .sidebar .sidebar-wrapper{overflow:hidden;padding-bottom:60px;margin-top:-12px}::ng-deep .sidebar .logo:after{content:\"\";position:absolute;bottom:0;right:15px;height:1px;width:calc(100% - 30px);background-color:hsla(0,0%,70.6%,.01)}::ng-deep .dx-treeview-toggle-item-visibility:before{top:70%!important}::ng-deep .dx-treeview-toggle-item-visibility.dx-treeview-toggle-item-visibility-opened:before{content:\"\\f001\";margin-top:-22px;left:50%;margin-left:-11px}::ng-deep .dx-treeview-toggle-item-visibility:before{content:\"\\f04e\";margin-top:-22px;left:50%;margin-left:-11px}::ng-deep .dx-treeview-item{padding:5px 6px;min-height:32px;height:50px}::ng-deep .sidebar:before{top:0;left:0;height:100%;width:100%;position:absolute;background-color:#fff;display:block;content:\"\";z-index:1}"]
            },] }
];
SidebarComponent.ctorParameters = () => [
    { type: Router },
    { type: ConfigulationService },
    { type: OrganizeInfoService }
];

/* eslint-disable no-var */
const SYMBOLS_TO_REMOVE_REGEX = /[\u200E\u200F]/g;
const getIntlFormatter = function (format) {
    return function (date) {
        // Intl in some browsers formates dates with timezone offset which was at the moment for this date.
        // But the method "new Date" creates date using current offset. So, we decided to format dates in the UTC timezone.
        if (!format.timeZoneName) {
            const utcDate = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
            const utcFormat = objectAssign({ timeZone: 'UTC' }, format);
            return formatDateTime(utcDate, utcFormat);
        }
        return formatDateTime(date, format);
    };
};
const ɵ0 = getIntlFormatter;
var formatDateTime = function (date, format) {
    return (new Intl.DateTimeFormat(locale(), format)).format(date).replace(SYMBOLS_TO_REMOVE_REGEX, '');
};
const ɵ1 = formatDateTime;
const formatCustomDateTime = function (date, format) {
    const dateString = date.toLocaleString(locale(), format);
    // dateString = dateString.split(" ").join(" ");
    return dateString;
};
const ɵ2 = formatCustomDateTime;
const formatNumber = function (number) {
    return (new Intl.NumberFormat(locale())).format(number);
};
const ɵ3 = formatNumber;
const ɵ4 = function () {
    const numeralsMapCache = {};
    return function (locale) {
        if (!(locale in numeralsMapCache)) {
            if (formatNumber(0) === '0') {
                numeralsMapCache[locale] = false;
                return false;
            }
            numeralsMapCache[locale] = {};
            for (let i = 0; i < 10; ++i) {
                numeralsMapCache[locale][formatNumber(i)] = i;
            }
        }
        return numeralsMapCache[locale];
    };
};
const getAlternativeNumeralsMap = (ɵ4());
const normalizeNumerals = function (dateString) {
    const alternativeNumeralsMap = getAlternativeNumeralsMap(locale());
    if (!alternativeNumeralsMap) {
        return dateString;
    }
    return dateString.split('').map(function (sign) {
        return sign in alternativeNumeralsMap ? String(alternativeNumeralsMap[sign]) : sign;
    }).join('');
};
const ɵ5 = normalizeNumerals;
const removeLeadingZeroes = function (str) {
    return str.replace(/(\D)0+(\d)/g, '$1$2');
};
const ɵ6 = removeLeadingZeroes;
const dateStringEquals = function (actual, expected) {
    return removeLeadingZeroes(actual) === removeLeadingZeroes(expected);
};
const ɵ7 = dateStringEquals;
const normalizeMonth = function (text) {
    return text.replace('d\u2019', 'de '); // NOTE: For 'ca' locale
};
const ɵ8 = normalizeMonth;
const intlFormats = {
    day: { day: 'numeric' },
    dayofweek: { weekday: 'long' },
    longdate: { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' },
    longdatelongtime: { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' },
    longtime: { hour: 'numeric', minute: 'numeric', second: 'numeric' },
    month: { month: 'long' },
    monthandday: { month: 'long', day: 'numeric' },
    monthandyear: { year: 'numeric', month: 'long' },
    shortdate: {},
    shorttime: { hour: 'numeric', minute: 'numeric' },
    shortyear: { year: '2-digit' },
    year: { year: 'numeric' },
    yyyy: { year: 'numeric' }
};
const customFormats = {
    datethai: { year: "numeric", month: "short", day: "numeric" },
    dateshorttimethai: { year: "numeric", month: "short", day: "numeric", hour: 'numeric', minute: 'numeric' }
};
Object.defineProperty(intlFormats, 'shortdateshorttime', {
    get() {
        const defaultOptions = Intl.DateTimeFormat(locale()).resolvedOptions();
        return { year: defaultOptions.year, month: defaultOptions.month, day: defaultOptions.day, hour: 'numeric', minute: 'numeric' };
    }
});
const getIntlFormat = function (format) {
    return typeof format === 'string' && intlFormats[format.toLowerCase()];
};
const ɵ9 = getIntlFormat;
const getCustomIntlFormat = function (format) {
    return typeof format === 'string' && customFormats[format.toLowerCase()];
};
const ɵ10 = getCustomIntlFormat;
var monthNameStrategies = {
    standalone(monthIndex, monthFormat) {
        const date = new Date(1999, monthIndex, 13, 1);
        const dateString = getIntlFormatter({ month: monthFormat })(date);
        return dateString;
    },
    format(monthIndex, monthFormat) {
        const date = new Date(0, monthIndex, 13, 1);
        const dateString = normalizeMonth(getIntlFormatter({ day: 'numeric', month: monthFormat })(date));
        const parts = dateString.split(' ').filter(function (part) {
            return part.indexOf('13') < 0;
        });
        if (parts.length === 1) {
            return parts[0];
        }
        else if (parts.length === 2) {
            return parts[0].length > parts[1].length ? parts[0] : parts[1]; // NOTE: For 'lt' locale
        }
        return monthNameStrategies.standalone(monthIndex, monthFormat);
    }
};
dateLocalization.resetInjection();
dateLocalization.inject({
    getMonthNames(format, type) {
        const intlFormats = {
            wide: 'long',
            abbreviated: 'short',
            narrow: 'narrow'
        };
        const monthFormat = intlFormats[format || 'wide'];
        type = type || 'standalone';
        return Array.apply(null, new Array(12)).map(function (_, monthIndex) {
            return monthNameStrategies[type](monthIndex, monthFormat);
        });
    },
    getDayNames(format) {
        const intlFormats = {
            wide: 'long',
            abbreviated: 'short',
            short: 'narrow',
            narrow: 'narrow'
        };
        const getIntlDayNames = function (format) {
            return Array.apply(null, new Array(7)).map(function (_, dayIndex) {
                return getIntlFormatter({ weekday: format })(new Date(0, 0, dayIndex));
            });
        };
        const result = getIntlDayNames(intlFormats[format || 'wide']);
        return result;
    },
    getPeriodNames() {
        const hour12Formatter = getIntlFormatter({ hour: 'numeric', hour12: true });
        return [1, 13].map(function (hours) {
            const hourNumberText = formatNumber(1); // NOTE: For 'bn' locale
            const timeParts = hour12Formatter(new Date(0, 0, 1, hours)).split(hourNumberText);
            if (timeParts.length !== 2) {
                return '';
            }
            const biggerPart = timeParts[0].length > timeParts[1].length ? timeParts[0] : timeParts[1];
            return biggerPart.trim();
        });
    },
    format(date, format) {
        if (!date) {
            return;
        }
        if (!format) {
            return date;
        }
        format = format.type || format;
        let intlFormat = getIntlFormat(format);
        if (intlFormat) {
            return getIntlFormatter(intlFormat)(date);
        }
        const formatType = typeof format;
        if (format.formatter || formatType === 'function' || formatType === 'string') {
            intlFormat = getCustomIntlFormat(format);
            if (intlFormat) {
                return formatCustomDateTime(date, intlFormat);
            }
            return this.callBase.apply(this, arguments);
        }
        return getIntlFormatter(format)(date);
    },
    parse(dateString, format) {
        const SIMPLE_FORMATS = ['shortdate', 'shorttime', 'shortdateshorttime', 'longtime'];
        if (compareVersions(dxVersion, '17.2.4') === -1 && dateString && typeof format === 'string' && SIMPLE_FORMATS.indexOf(format.toLowerCase()) > -1) {
            return this._parseDateBySimpleFormat(dateString, format.toLowerCase());
        }
        let formatter;
        if (compareVersions(dxVersion, '17.2.4') >= 0 && format && !format.parser && typeof dateString === 'string') {
            dateString = normalizeMonth(dateString);
            formatter = function (date) {
                return normalizeMonth(dateLocalization.format(date, format));
            };
        }
        return this.callBase(dateString, formatter || format);
    },
    _parseDateBySimpleFormat(dateString, format) {
        dateString = normalizeNumerals(dateString);
        const formatParts = this.getFormatParts(format);
        const dateParts = dateString
            .split(/\D+/)
            .filter(function (part) { return part.length > 0; });
        if (formatParts.length !== dateParts.length) {
            return;
        }
        const dateArgs = this._generateDateArgs(formatParts, dateParts);
        const constructDate = function (dateArgs, ampmShift) {
            const hoursShift = ampmShift ? 12 : 0;
            return new Date(dateArgs.year, dateArgs.month, dateArgs.day, (dateArgs.hours + hoursShift) % 24, dateArgs.minutes, dateArgs.seconds);
        };
        const constructValidDate = function (ampmShift) {
            const parsedDate = constructDate(dateArgs, ampmShift);
            if (dateStringEquals(normalizeNumerals(this.format(parsedDate, format)), dateString)) {
                return parsedDate;
            }
        }.bind(this);
        return constructValidDate(false) || constructValidDate(true);
    },
    _generateDateArgs(formatParts, dateParts) {
        const currentDate = new Date();
        const dateArgs = {
            year: currentDate.getFullYear(),
            month: currentDate.getMonth(),
            day: currentDate.getDate(),
            hours: 0,
            minutes: 0,
            seconds: 0
        };
        formatParts.forEach(function (formatPart, index) {
            const datePart = dateParts[index];
            let parsed = parseInt(datePart, 10);
            if (formatPart === 'month') {
                parsed = parsed - 1;
            }
            dateArgs[formatPart] = parsed;
        });
        return dateArgs;
    },
    formatUsesMonthName(format) {
        if (typeof format === 'object' && !(format.type || format.format)) {
            return format.month === 'long';
        }
        return this.callBase.apply(this, arguments);
    },
    formatUsesDayName(format) {
        if (typeof format === 'object' && !(format.type || format.format)) {
            return format.weekday === 'long';
        }
        return this.callBase.apply(this, arguments);
    },
    getFormatParts(format) {
        const intlFormat = objectAssign({}, intlFormats[format.toLowerCase()]);
        const date = new Date(2001, 2, 4, 5, 6, 7);
        let formattedDate = getIntlFormatter(intlFormat)(date);
        formattedDate = normalizeNumerals(formattedDate);
        const formatParts = [
            { name: 'year', value: 1 },
            { name: 'month', value: 3 },
            { name: 'day', value: 4 },
            { name: 'hours', value: 5 },
            { name: 'minutes', value: 6 },
            { name: 'seconds', value: 7 }
        ];
        return formatParts
            .map(function (part) {
            return {
                name: part.name,
                index: formattedDate.indexOf(part.value)
            };
        })
            .filter(function (part) { return part.index > -1; })
            .sort(function (a, b) { return a.index - b.index; })
            .map(function (part) { return part.name; });
    }
});

class TabItemComponent {
    constructor() {
        this._state = { visible: false, init: false };
    }
    set visible(v) {
        this._state.visible = v;
    }
    get visible() {
        return this._state.visible;
    }
    activate() {
        this._state.init = true;
        this._state.visible = true;
    }
    ngOnInit() {
    }
}
TabItemComponent.decorators = [
    { type: Component, args: [{
                selector: 'share-tab-item',
                template: "<div class=\"tab-pane fade\" [ngClass]=\"{'active show': _state.visible, 'd-none': !_state.visible}\">\r\n    <ng-container *ngIf=\"recreateOnActive ? _state.visible : _state.init\" [ngTemplateOutlet]=\"tempItemTemp\"></ng-container>\r\n</div>\r\n<ng-template #tempItemTemp>\r\n    <ng-template [ngTemplateOutlet]=\"_template\"></ng-template>\r\n    <ng-content></ng-content>\r\n</ng-template>\r\n",
                styles: [""]
            },] }
];
TabItemComponent.ctorParameters = () => [];
TabItemComponent.propDecorators = {
    recreateOnActive: [{ type: Input }],
    _template: [{ type: ContentChild, args: [TemplateRef,] }],
    visible: [{ type: Input }]
};

class TabPanelComponent {
    constructor() {
        this.selectIndex = 0;
        this.onTabSelectChanged = new EventEmitter();
    }
    ngAfterContentInit() {
        this._tabItems = this._queryTapItems.toArray();
    }
    ngAfterViewInit() {
        const children = this.tabPanel.nativeElement.children;
        if (children.length > 0) {
            this._selectTab(children.item(this.selectIndex).getElementsByTagName("a").item(0));
        }
        children.item(this.selectIndex).getElementsByTagName("a").item(0);
    }
    ngOnInit() {
    }
    _onSelectIndexChanged(e) {
        const ele = e.target;
        if (ele.tagName.toLowerCase() !== "a") {
            return;
        }
        if (ele.hasAttribute("active")) {
            return;
        }
        this._selectTab(ele);
    }
    _selectTab(element) {
        let tabItem = this._tabItems[this.selectIndex];
        if (this._lastLinkSelect) {
            this._lastLinkSelect.classList.remove("active");
            tabItem.visible = false;
        }
        const li = element.parentElement;
        this.selectIndex = Array.from(li.parentElement.children).indexOf(li);
        tabItem = this._tabItems[this.selectIndex];
        this._lastLinkSelect = element;
        this._lastLinkSelect.classList.add("active");
        setTimeout(() => {
            tabItem.activate();
            this.onTabSelectChanged.emit(this.selectIndex);
        });
    }
}
TabPanelComponent.decorators = [
    { type: Component, args: [{
                selector: 'share-tab-panel',
                template: "<ul (click)=\"_onSelectIndexChanged($event)\" #tabPanel class=\"nav nav-pills mb-3\">\r\n    <ng-container *ngFor=\"let title of tabsTitle; let i = index\">\r\n        <li class=\"nav-item\">\r\n            <a class=\"nav-link\">\r\n                {{title}}\r\n            </a>\r\n        </li>\r\n    </ng-container>\r\n</ul>\r\n<div class=\"tab-content\">\r\n    <ng-content></ng-content>\r\n</div>\r\n",
                styles: [".nav-item>a{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer}.nav-item>.nav-link{font-size:14px}"]
            },] }
];
TabPanelComponent.ctorParameters = () => [];
TabPanelComponent.propDecorators = {
    _queryTapItems: [{ type: ContentChildren, args: [TabItemComponent,] }],
    tabPanel: [{ type: ViewChild, args: ["tabPanel",] }],
    tabsTitle: [{ type: Input }],
    selectIndex: [{ type: Input }],
    onTabSelectChanged: [{ type: Output }]
};

class Dialog {
}

class DevExtreamDialog extends Dialog {
    constructor() {
        super();
        this._isCreateStack = false;
        this._dialogQueue = [];
    }
    info(title, message, btnText) {
        return this._runDialog({
            title,
            message,
            type: DialogType.Info,
            buttons: [
                {
                    text: btnText || "ตกลง"
                }
            ]
        });
    }
    error(title, message, btnText) {
        console.error(message);
        return this._runDialog({
            title,
            message,
            type: DialogType.Error,
            buttons: [
                {
                    text: btnText || "ตกลง"
                }
            ]
        });
    }
    warning(title, message, btnText) {
        return this._runDialog({
            title,
            message,
            type: DialogType.Warning,
            buttons: [
                {
                    text: btnText || "ตกลง"
                }
            ]
        });
    }
    confirm(title, message, okText, cancelText) {
        return new Promise(r => {
            custom({
                title,
                messageHtml: `<div class="text-center"></div><br><h4>${message}</h4>`,
                buttons: [
                    {
                        icon: "check", text: okText || "ใช่", type: "success", focusStateEnabled: false,
                        onClick: () => r(true)
                    },
                    {
                        icon: "close", text: cancelText || "ไม่", type: "danger",
                        onClick: () => r(false)
                    }
                ]
            }).show();
        });
    }
    _runDialog(structure) {
        let dialog;
        const resolver = new Subject();
        if (this._dialogQueue.length > 0) {
            this._dialogQueue.push({
                structure,
                resolver
            });
            this._stackDialog();
        }
        else {
            dialog = this._createDialog(structure);
            dialog.show();
            this._dialogQueue.push({
                structure,
                intenralDialog: dialog,
                resolver
            });
        }
        this._updateStack();
        return resolver.toPromise();
    }
    _createDialog(structure) {
        let dialog;
        const button = [...structure.buttons];
        button[0].onClick = () => {
            let dialogQueue = this._dialogQueue[0];
            dialogQueue.resolver.complete();
            this._dialogQueue.shift();
            if (this._dialogQueue.length > 1) {
                dialogQueue = this._dialogQueue[0];
                dialogQueue.intenralDialog = this._createDialog(dialogQueue.structure);
                dialogQueue.intenralDialog.show();
            }
            else {
                this._unstackDialog();
            }
        };
        if (this._isCreateStack) {
            button.push({
                text: `ปิด (${this._dialogQueue.length - 1})`,
                onClick: () => {
                    this._dialogQueue.forEach(d => d.resolver.complete());
                    this._dialogQueue.length = 0;
                    this._isCreateStack = false;
                },
                elementAttr: { id: "stackBtn" }
            });
        }
        dialog = custom({
            title: structure.title,
            messageHtml: structure.message,
            buttons: button
        });
        return dialog;
    }
    _stackDialog() {
        if (this._dialogQueue.length === 0 || this._isCreateStack) {
            return;
        }
        const openDialog = this._dialogQueue[0];
        openDialog.intenralDialog.hide();
        this._isCreateStack = true;
        setTimeout(() => {
            openDialog.intenralDialog = this._createDialog(openDialog.structure);
            openDialog.intenralDialog.show();
        });
    }
    _updateStack() {
        if (!this._isCreateStack) {
            return;
        }
        const stackBtn = document.querySelectorAll("#stackBtn .dx-button-text").item(0);
        if (stackBtn) {
            stackBtn.textContent = `ปิด (${this._dialogQueue.length - 1})`;
        }
    }
    _unstackDialog() {
        if (this._dialogQueue.length <= 0 || !this._isCreateStack) {
            return;
        }
        const openDialog = this._dialogQueue[0];
        this._isCreateStack = false;
        openDialog.intenralDialog = this._createDialog(openDialog.structure);
        openDialog.intenralDialog.show();
    }
}
DevExtreamDialog.ɵprov = i0.ɵɵdefineInjectable({ factory: function DevExtreamDialog_Factory() { return new DevExtreamDialog(); }, token: DevExtreamDialog, providedIn: "root" });
DevExtreamDialog.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
DevExtreamDialog.ctorParameters = () => [];
var DialogType;
(function (DialogType) {
    DialogType[DialogType["Info"] = 0] = "Info";
    DialogType[DialogType["Warning"] = 1] = "Warning";
    DialogType[DialogType["Error"] = 2] = "Error";
})(DialogType || (DialogType = {}));

class DxButtonImproveComponent {
    constructor(cd) {
        this.cd = cd;
        this.visible = true;
        this.waitIcon = "fas fa-circle-notch fa-spin";
        this.disableOnWait = false;
        this.onClick = new EventEmitter();
        this._isWait = false;
    }
    OnInitialized(e) {
        this._widget = e.component;
    }
    OnClicked(e) {
        if (this._isWait) {
            return;
        }
        this.onClick.emit({
            event: e,
            startWait: () => this.StartWait(),
            stopWait: () => this.StopWait()
        });
    }
    Click() {
        this._widget.element().click();
    }
    StartWait() {
        this._isWait = true;
        this._oldIcon = this.icon;
        this.icon = this.waitIcon;
        if (this.waitText) {
            this._oldIcon = this.text;
            this.text = this.waitText;
        }
        this.disabled = this.disableOnWait;
    }
    StopWait() {
        this._isWait = false;
        this.icon = this._oldIcon;
        this.disabled = false;
        if (this.waitText) {
            this.text = this._oldIcon;
        }
        this.cd.markForCheck();
    }
}
DxButtonImproveComponent.decorators = [
    { type: Component, args: [{
                // tslint:disable-next-line: component-selector
                selector: 'dx-button-improve',
                template: "<dx-button\r\n    [class]=\"widgetClass\"\r\n    [type]=\"type\"\r\n    [text]=\"text\"\r\n    [icon]=\"icon\"\r\n    [height]=\"height\"\r\n    [width]=\"width\"\r\n    [disabled]=\"disabled\"\r\n    [visible]=\"visible\"\r\n    [hint]=\"hint\"\r\n    (onClick)=\"OnClicked($event)\"\r\n    (onInitialized)=\"OnInitialized($event)\"\r\n>\r\n</dx-button>\r\n"
            },] }
];
DxButtonImproveComponent.ctorParameters = () => [
    { type: ChangeDetectorRef }
];
DxButtonImproveComponent.propDecorators = {
    widgetClass: [{ type: Input }],
    text: [{ type: Input }],
    type: [{ type: Input }],
    icon: [{ type: Input }],
    height: [{ type: Input }],
    hint: [{ type: Input }],
    width: [{ type: Input }],
    disabled: [{ type: Input }],
    visible: [{ type: Input }],
    waitIcon: [{ type: Input }],
    waitText: [{ type: Input }],
    disableOnWait: [{ type: Input }],
    onClick: [{ type: Output }]
};

class DxDatePipe {
    transform(date, format = "dateThai") {
        if (typeof date === "string") {
            return formatDate(DateTime.fromFormat(date, "YYYY-MM-DD").toJSDate(), format);
        }
        return formatDate(date, format);
    }
}
DxDatePipe.decorators = [
    { type: Pipe, args: [{ name: 'dxDate' },] }
];

class FileSizePipe {
    constructor() {
        this.units = [
            'B',
            'KB',
            'MB',
            'GB',
            'TB',
            'PB'
        ];
    }
    transform(bytes = 0, precision = 2) {
        if (isNaN(parseFloat(String(bytes))) || !isFinite(bytes)) {
            return '?';
        }
        else if (bytes === 0) {
            return "0 B";
        }
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return (bytes / Math.pow(1024, i)).toFixed(precision) + ' ' + this.units[i];
    }
}
FileSizePipe.decorators = [
    { type: Pipe, args: [{ name: 'fileSize' },] }
];

class ControlModule {
}
ControlModule.decorators = [
    { type: NgModule, args: [{
                declarations: [DxButtonImproveComponent, DxDatePipe, FileSizePipe],
                imports: [
                    CommonModule,
                    DxButtonModule
                ],
                exports: [DxButtonImproveComponent,
                    DxDatePipe,
                    FileSizePipe],
                schemas: [CUSTOM_ELEMENTS_SCHEMA]
            },] }
];

function storageFactory() {
    return localStorage;
}
class ShareUiModule {
    constructor(injecttor) {
        this.injecttor = injecttor;
        locale("th-TH");
        StaticBag.InjectorInstance = injecttor;
    }
    static forRoot(config) {
        return {
            ngModule: ShareUiModule,
            providers: [
                { provide: SHARE_UI_CONFIG, useValue: config },
                { provide: Dialog, useExisting: DevExtreamDialog },
            ]
        };
    }
}
ShareUiModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ShareUiComponent,
                    SidebarComponent,
                    TabPanelComponent,
                    TabItemComponent
                ],
                imports: [
                    //
                    CommonModule,
                    HttpClientModule,
                    ControlModule
                    // OAuthModule.forRoot()
                ],
                exports: [TabPanelComponent, TabItemComponent]
            },] }
];
ShareUiModule.ctorParameters = () => [
    { type: Injector }
];
// function initializeKeycloak(keycloak: KeycloakService) {
//     return () =>
//         keycloak.init({
//             config: {
//                 url: 'http://localhost:8080/auth',
//                 realm: 'Ky-App',
//                 clientId: 'MyClient',
//             },
//             initOptions: {
//                 enableLogging: true,
//                 onLoad: 'login-required',
//                 silentCheckSsoRedirectUri:
//                     window.location.origin + '/assets/silent-check-sso.html',
//             },
//         });
// }

class BetimesOauthService {
    constructor(config, authServ) {
        this.config = config;
        this.authServ = authServ;
        this.authServ.configure(this.config.authConfig);
        this.authServ.events.subscribe(e => {
            switch (e.type) {
                case "token_received":
                    this.authServ.loadUserProfile();
                    break;
                case "session_terminated":
                case "session_error":
                    this.login("");
                    break;
                default:
                    break;
            }
        });
        this.authServ.setupAutomaticSilentRefresh();
    }
    get identityClaims() { return this.authServ.getIdentityClaims(); }
    get accessToken() { return this.authServ.getAccessToken(); }
    hasTokenValid() {
        return this.authServ.hasValidAccessToken() &&
            this.authServ.hasValidIdToken();
    }
    get oauth2() { return this.authServ; }
    initOauth() {
        return this.authServ
            .loadDiscoveryDocument()
            .then(() => {
            return this.authServ.tryLogin();
        })
            .then(() => {
            if (this.authServ.hasValidAccessToken()) {
                if (this.authServ.sessionChecksEnabled) {
                    this.authServ.sessionCheckIFrameUrl += `?client_id=${this.authServ.clientId}&redirect_uri=${this.authServ.redirectUri}`;
                    this.authServ.restartSessionChecksIfStillLoggedIn();
                }
                return Promise.resolve(true);
            }
            if (this.config.authConfig.autoLogin) {
                this.login();
            }
            return Promise.resolve(false);
            // return this.refresh().then(() => Promise.resolve())
            //     .catch(err => {
            //         if (this.checkUserInteractionRequiredOnRefreshFailure(err)) {
            //             if (this.config.authConfig.autoLogin) {
            //                 this.login();
            //             }
            //         }
            //         return Promise.reject(err);
            //     });
        })
            .catch((err) => {
            console.error(err);
            return Promise.resolve(false);
        });
    }
    refresh() {
        return this.authServ.responseType === "code" ?
            this.authServ.refreshToken() :
            this.authServ.silentRefresh();
    }
    login(targetUrl) {
        this.authServ.initLoginFlow(targetUrl);
    }
    logout() {
        if (this.config.authConfig.revokeTokenOnLogout) {
            this.authServ.revokeTokenAndLogout();
        }
        else {
            this.authServ.logOut();
        }
    }
    checkUserInteractionRequiredOnRefreshFailure(errorObj) {
        const errorCodes = [
            'invalid_grant',
            'interaction_required',
            'login_required',
            'account_selection_required',
            'consent_required'
        ];
        const k = this.authServ.responseType === 'code' ? 'error' : 'reason';
        return errorObj
            && errorObj[k]
            && errorCodes.indexOf(errorObj[k].error) >= 0;
    }
}
BetimesOauthService.ɵprov = i0.ɵɵdefineInjectable({ factory: function BetimesOauthService_Factory() { return new BetimesOauthService(i0.ɵɵinject(SHARE_UI_CONFIG), i0.ɵɵinject(i1.OAuthService)); }, token: BetimesOauthService, providedIn: "root" });
BetimesOauthService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
BetimesOauthService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [SHARE_UI_CONFIG,] }] },
    { type: OAuthService }
];

class InternalCache {
    static Set(key, value) {
        localStorage.setItem(key, value);
    }
    static Get(key) {
        const cache = localStorage.getItem(key);
        if (!cache) {
            return undefined;
        }
        let parse = cache;
        try {
            parse = JSON.parse(cache);
        }
        catch (error) {
        }
        return parse;
    }
    static Delete(key) {
        localStorage.removeItem(key);
    }
    static DeleteAll() {
        localStorage.clear();
    }
}

function IsHttpResultValue(obj) {
    return obj && IsHttpResult(obj) && "Value" in obj;
}
function IsHttpResult(obj) {
    return obj && "IsSuccess" in obj;
}
function IsHttpProgressEvent(obj) {
    return obj && "loaded" in obj && "total" in obj;
}

class BetimesHttpInterceptor {
    constructor(_dialog) {
        this._dialog = _dialog;
    }
    intercept(req, next) {
        if (!(req instanceof BetimesRequest)) {
            return next.handle(req);
        }
        const cacheName = "req:" + req.urlWithParams;
        if (req.useCacheInvalidate) {
            InternalCache.Delete(cacheName);
        }
        else if (req.useCache) {
            const cache = InternalCache.Get(cacheName);
            if (cache) {
                return of(cache);
            }
        }
        return next.handle(req).pipe(filter((event) => event.type === 1 || event.type === 4), map(_ => {
            if (_.type === 1) {
                return _;
            }
            const respone = _;
            switch (req.responseType) {
                case "blob":
                    if (respone.body !== null && !(respone.body instanceof Blob)) {
                        if (req.displayCriticalError) {
                            this._dialog.error("เกิดข้อผิดพลาด", "ผลลัพธ์ไม่ได้อยู่ในรูปแบบ Blob");
                        }
                        throw new Error('ผลลัพธ์ไม่ได้อยู่ในรูปแบบ Blob');
                    }
                    /*
                        กรณีนี้จะเกิดขึ้นเมื่อ api ได้การตรวจสอบแล้วพบว่ามีข้อผิดพลาดเกิดขึ้น
                        จึงได้ส่งค่ากลับมาเป็นในรูปแบบ StatusResult
                    */
                    if (respone.body.type === "application/json") {
                        this.readJsonAsync(respone.body).then(r => {
                            if (IsHttpResult(r) && req.displayError) {
                                this._dialog.error("เกิดข้อผิดพลาด", r.Message);
                            }
                        });
                        throw new Error('ผลลัพธ์ไม่ได้อยู่ในรูปแบบที่ประมวลผลเป็น binary');
                    }
                    return respone.body;
                case "json":
                    this.checkError(respone.body, req);
                    const body = respone.body;
                    if (body.IsSuccess && req.useOnlyValue) {
                        if (req.method.toLowerCase() === "get" && req.useCache) {
                            InternalCache.Set(cacheName, JSON.stringify(body.Value));
                        }
                        return body.Value;
                    }
                    return body;
            }
            return respone;
        }), catchError((error) => __awaiter(this, void 0, void 0, function* () {
            if (error instanceof HttpErrorResponse && req.displayCriticalError && error.status !== 401) {
                let errorMessage = "เกิดปัญหาทางเซิฟเวอร์ไม่สามารถดำเนินการต่อได้";
                switch (error.status) {
                    case 400:
                        errorMessage = "การส่งข้อมูลผิดรูปแบบ";
                        break;
                    case 404:
                        errorMessage = "ไม่พบ URL ที่ร้องขอ";
                        break;
                    case 500:
                        if (IsHttpResult(error.error)) {
                            errorMessage = error.error.Message;
                        }
                        else if (error.error instanceof Blob && error.error.type === "application/json") {
                            const readReult = yield this.readJsonAsync(error.error);
                            if (IsHttpResult(readReult)) {
                                errorMessage = readReult.Message;
                            }
                        }
                        break;
                }
                this._dialog.error("เกิดข้อผิดพลาด", errorMessage);
            }
            InternalCache.Delete(cacheName);
            throw error;
        })));
    }
    checkError(httpResult, req) {
        if (req.useOnlyValue) {
            if (!IsHttpResult(httpResult)) {
                if (req.displayCriticalError) {
                    this._dialog.error("เกิดข้อผิดพลาด", "ผลลัพธ์ไม่ได้อยู่ในรูปแบบ StatusResult");
                }
                throw new Error("ผลลัพธ์ไม่ได้อยู่ในรูปแบบ StatusResult");
            }
            if (!httpResult.IsSuccess) {
                if (req.displayError) {
                    this._dialog.error(`เกิดข้อผิดพลาด: ${httpResult.StatusCode}`, httpResult.Message);
                }
                throw new BetimesHttpResultError(httpResult);
            }
        }
    }
    readJsonAsync(blob) {
        return Observable.create(obs => {
            const blobReader = new FileReader();
            blobReader.readAsText(blob);
            blobReader.onload = () => {
                obs.next(JSON.parse(blobReader.result));
                obs.complete();
            };
        }).toPromise();
    }
}
BetimesHttpInterceptor.decorators = [
    { type: Injectable }
];
BetimesHttpInterceptor.ctorParameters = () => [
    { type: Dialog }
];

class AuthGuard {
    constructor(oauthServ) {
        this.oauthServ = oauthServ;
    }
    canActivate(route, state) {
        if (this.oauthServ.hasTokenValid()) {
            return true;
        }
        // this.oauthServ.login("");
        return false;
    }
}
AuthGuard.ɵprov = i0.ɵɵdefineInjectable({ factory: function AuthGuard_Factory() { return new AuthGuard(i0.ɵɵinject(BetimesOauthService)); }, token: AuthGuard, providedIn: "root" });
AuthGuard.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
AuthGuard.ctorParameters = () => [
    { type: BetimesOauthService }
];

class FileServer {
    constructor(_http, _baseApiUrl) {
        this._http = _http;
        this._baseApiUrl = _baseApiUrl;
        this._skipProgressing = true;
        this._uploadParamName = "file";
    }
    static connect(host) {
        if (!host) {
            host = StaticBag.InjectorInstance.get(SHARE_UI_CONFIG).apiUrl;
        }
        return new FileServer(StaticBag.InjectorInstance.get(HttpClient), host);
    }
    file(endpoint = "file") {
        this._endpoint = endpoint;
        return this;
    }
    identity(id) {
        this._fileId = id;
        return this;
    }
    withVerb(httpVerb) {
        this._fileActionVerb = httpVerb;
        return undefined;
    }
    view() {
        const url = `${this._baseApiUrl}/${this._endpoint}`;
        const request = req(url)
            .useSystemResult()
            .responseType("blob");
        switch (this._fileActionVerb) {
            case "POST":
                return request.body(this._param).post();
            default:
                return request.queryString(this._param).get();
        }
    }
    delete() {
        const verb = this._fileActionVerb || "DELETE";
        return undefined;
    }
    upload(endpoint = "file/upload") {
        this._endpoint = endpoint;
        return this;
    }
    isReportProgressing() {
        this._skipProgressing = false;
        return this;
    }
    withUploadParamName(uploadName) {
        this._uploadParamName = uploadName;
        return this;
    }
    withParam(p) {
        this._param = p;
        return this;
    }
    fromFile(files) {
        const uploadObser = new UploadObserver();
        if (!files) {
            throw new Error("not found file upload");
        }
        files.forEach(file => {
            const formData = new FormData();
            formData.append(this._uploadParamName, file);
            for (const param in this._param) {
                formData.append(param, this._param[param]);
            }
            this._startUpload(formData, uploadObser);
        });
        return uploadObser;
    }
    fromFormData(formData) {
        if (!formData) {
            throw new Error("not found file upload");
        }
        const uploadObser = new UploadObserver();
        this._startUpload(formData, uploadObser);
        return uploadObser;
    }
    _startUpload(formData, observ) {
        const url = `${this._baseApiUrl}/${this._endpoint}`;
        const httpReq = new HttpRequest("POST", url, formData, { reportProgress: !this._skipProgressing });
        const progress = new Subject();
        const progressObj = {
            FileName: undefined, FileSize: undefined,
            PercentToComplete: 0, Status: UploadStatus.Ready, ErrorMessage: undefined
        };
        const fileInfo = formData.get(this._uploadParamName);
        if (fileInfo instanceof File) {
            progressObj.FileName = fileInfo.name;
            progressObj.FileSize = fileInfo.size;
        }
        this._http.request(httpReq).subscribe(event => {
            if (event.type === HttpEventType.UploadProgress) {
                const percentDone = Math.round(100 * event.loaded / event.total);
                progressObj.PercentToComplete = percentDone;
                progressObj.Status = UploadStatus.Uploading;
                progress.next(progressObj);
            }
            else if (event.type === HttpEventType.Response) {
                progressObj.Status = UploadStatus.Success;
                progress.complete();
            }
        }, _ => {
            if (_ instanceof HttpErrorResponse) {
                progressObj.ErrorMessage = _.error.Message || _.message;
            }
            else {
                progressObj.ErrorMessage = _;
            }
            progressObj.Status = UploadStatus.Failure;
            progress.next(progressObj);
        });
        observ.AddObserver(progress.asObservable());
    }
}
class UploadObserver {
    constructor() {
        this._observer = [];
    }
    AddObserver(obser) {
        this._observer.push(obser);
    }
    Subscribe(next, complete) {
        const subscribe = from(this._observer).pipe(mergeAll())
            .subscribe({
            next,
            complete: () => {
                subscribe.unsubscribe();
                complete();
            }
        });
    }
}
var UploadStatus;
(function (UploadStatus) {
    UploadStatus[UploadStatus["Ready"] = 0] = "Ready";
    UploadStatus[UploadStatus["Uploading"] = 1] = "Uploading";
    UploadStatus[UploadStatus["Failure"] = 2] = "Failure";
    UploadStatus[UploadStatus["Success"] = 3] = "Success";
})(UploadStatus || (UploadStatus = {}));

/*
 * Public API Surface of share-ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthGuard, BetimesHttpInterceptor, BetimesHttpRequest, BetimesHttpResultError, BetimesOauthService, BetimesRequest, ControlModule, DevExtreamDialog, Dialog, DxButtonImproveComponent, DxDatePipe, FileServer, FileSizePipe, InternalCache, SHARE_UI_CONFIG, ShareUiComponent, ShareUiModule, TabItemComponent, TabPanelComponent, UploadStatus, req, storageFactory, SidebarComponent as ɵa, ConfigulationService as ɵb, OrganizeInfoService as ɵc, StaticBag as ɵd };
//# sourceMappingURL=share-ui.js.map
