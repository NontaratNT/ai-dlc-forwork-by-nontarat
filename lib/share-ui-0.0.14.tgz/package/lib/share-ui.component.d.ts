import { OnInit } from '@angular/core';
export declare class ShareUiComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
