import { OAuthService } from 'angular-oauth2-oidc';
import { Config } from '../common/config';
export declare class BetimesOauthService {
    private config;
    private authServ;
    constructor(config: Config, authServ: OAuthService);
    get identityClaims(): object;
    get accessToken(): string;
    hasTokenValid(): boolean;
    get oauth2(): OAuthService;
    initOauth(): Promise<boolean>;
    refresh(): Promise<object>;
    login(targetUrl?: string): void;
    logout(): void;
    private checkUserInteractionRequiredOnRefreshFailure;
}
