import { ModuleWithProviders, Injector } from '@angular/core';
import { OAuthStorage } from 'angular-oauth2-oidc';
import './common/betimes-intl-date';
import { Config } from './common/config';
export declare function storageFactory(): OAuthStorage;
export declare class ShareUiModule {
    private injecttor;
    constructor(injecttor: Injector);
    static forRoot(config?: Config): ModuleWithProviders<ShareUiModule>;
}
