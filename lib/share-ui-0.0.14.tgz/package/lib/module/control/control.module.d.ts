export declare class ControlModule {
}
