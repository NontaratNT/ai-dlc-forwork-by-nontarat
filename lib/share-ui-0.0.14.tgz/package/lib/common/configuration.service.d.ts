import { OAuthModuleConfig } from 'angular-oauth2-oidc';
export declare class ConfigulationService {
    private environment;
    private oAuthModuleConfig;
    private _config;
    constructor(environment: any, oAuthModuleConfig: OAuthModuleConfig);
    private InitAuth;
    private Init;
    get Config(): IConfig;
}
interface IConfig {
    originUrl: string;
    apiUrl: string;
    resourceUrl: string;
    reportUrl: string;
    authConfig: Partial<IAuthConfig>;
}
interface IAuthConfig {
    authUrl: string;
    autoLogin: boolean;
    revokeTokenOnLogout: boolean;
    issuer: string;
    clientId: string;
    redirectUri: string;
    silentRefreshRedirectUri: string;
    postLogoutRedirectUri: string;
    skipIssuerCheck: boolean;
    strictDiscoveryDocumentValidation: boolean;
    responseType: string;
    disablePKCE: boolean;
    scope: string;
    silentRefreshTimeout: number;
    timeoutFactor: number;
    sessionChecksEnabled: boolean;
    showDebugInformation: boolean;
    clearHashAfterLogin: boolean;
}
export {};
