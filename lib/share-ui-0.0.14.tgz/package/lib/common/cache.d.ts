export declare class InternalCache {
    static Set(key: string, value: string): void;
    static Get(key: string): any;
    static Delete(key: string): void;
    static DeleteAll(): void;
}
