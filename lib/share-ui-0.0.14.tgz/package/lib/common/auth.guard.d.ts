import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { BetimesOauthService } from '../models/betimes-oauth.service';
export declare class AuthGuard implements CanActivate {
    private oauthServ;
    constructor(oauthServ: BetimesOauthService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
}
