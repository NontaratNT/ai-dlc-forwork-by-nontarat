import { PipeTransform } from '@angular/core';
export declare class DxDatePipe implements PipeTransform {
    transform(date: Date | string, format?: string): string;
}
