import { Dialog } from './dialog';
export declare class DevExtreamDialog extends Dialog {
    private _dialogQueue;
    private _isCreateStack;
    constructor();
    info(title: string, message: string, btnText?: string): Promise<void>;
    error(title: string, message: string, btnText?: string): Promise<void>;
    warning(title: string, message: string, btnText?: string): Promise<void>;
    confirm(title: string, message: string, okText?: string, cancelText?: string): Promise<boolean>;
    private _runDialog;
    private _createDialog;
    private _stackDialog;
    private _updateStack;
    private _unstackDialog;
}
