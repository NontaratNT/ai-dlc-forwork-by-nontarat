export declare abstract class Dialog {
    abstract info(title: string, message: string, btnText?: string): Promise<void>;
    abstract error(title: string, message: string, btnText?: string): Promise<void>;
    abstract warning(title: string, message: string, btnText?: string): Promise<void>;
    abstract confirm(title: string, message: string, okText?: string, cancelText?: string): Promise<boolean>;
}
