import { HttpInterceptor, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BetimesRequest } from './betimes-http-request';
import { HttpStatusResult } from './common-type';
import { Dialog } from './dialog-box/dialog';
export declare class BetimesHttpInterceptor implements HttpInterceptor {
    private _dialog;
    constructor(_dialog: Dialog);
    intercept(req: BetimesRequest, next: HttpHandler): Observable<HttpEvent<any>>;
    checkError(httpResult: HttpStatusResult | any, req: BetimesRequest): void;
    readJsonAsync(blob: Blob): Promise<any>;
}
