import { Role, UserProfile } from './common-type';
export declare class User {
    private static _userInfo;
    static get Current(): UserProfile;
    static SetUser(userinfo: UserProfile): void;
    static Save(): void;
    static SwitchRole(role: Role): void;
    static Clear(): void;
}
