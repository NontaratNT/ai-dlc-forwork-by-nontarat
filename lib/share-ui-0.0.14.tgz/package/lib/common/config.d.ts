import { InjectionToken } from '@angular/core';
export declare const SHARE_UI_CONFIG: InjectionToken<Config>;
export interface Config {
    apiUrl: string;
    resourceUrl: string;
    reportUrl: string;
    authConfig: Partial<AuthConfig>;
}
export interface AuthConfig {
    authUrl: string;
    autoLogin: boolean;
    revokeTokenOnLogout: boolean;
    issuer: string;
    clientId: string;
    redirectUri: string;
    silentRefreshRedirectUri: string;
    postLogoutRedirectUri: string;
    skipIssuerCheck: boolean;
    strictDiscoveryDocumentValidation: boolean;
    responseType: string;
    disablePKCE: boolean;
    scope: string;
    silentRefreshTimeout: number;
    timeoutFactor: number;
    sessionChecksEnabled: boolean;
    showDebugInformation: boolean;
    clearHashAfterLogin: boolean;
}
