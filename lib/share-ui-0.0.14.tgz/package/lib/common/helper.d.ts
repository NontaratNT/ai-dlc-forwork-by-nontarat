import { HttpStatusResultValue, HttpStatusResult } from './common-type';
import { HttpProgressEvent } from '@angular/common/http';
export declare function IsHttpResultValue(obj: any): obj is HttpStatusResult;
export declare function IsHttpResult(obj: any): obj is HttpStatusResultValue<any>;
export declare function IsHttpProgressEvent(obj: any): obj is HttpProgressEvent;
