export interface IPagingResult<T> {
    TotalCount: number;
    Data: T[];
}
export interface HttpStatusResult {
    Message: string;
    StatusCode: number;
    IsSuccess: boolean;
}
export interface HttpStatusResultValue<T> extends HttpStatusResult {
    Value: T;
}
export interface IAppearanceForm {
    AfterSubmitLink?: string;
    BackUrl?: string;
}
export interface IEcmsErrorMessage {
    ErrorDetail: {
        ErrorCode: string;
        ErrorDescription: string;
    }[];
}
export interface ISendRegister extends IAppearanceForm {
    ShowOnlyAbove?: boolean;
}
export interface IMenu {
    MODULE_ID: number;
    MODULE_SEQ: string;
    MODULE_CODE: string;
    MODULE_NAME: string;
    MODULE_URL: string;
    MODULE_ICON: string;
    MODULE_NEW_WINDOW_FLAG: string;
    MODULE_PARENT_ID: number;
    MODULE_LEVEL: number;
    PERMISSION: IMenuPermission;
}
export interface IMenuPermission {
    ADD: boolean;
    EDIT: boolean;
    DELETE: boolean;
    VIEW: boolean;
    UPLOAD: boolean;
    DOWNLOAD: boolean;
}
export interface Setting {
    RememberLogin?: boolean;
}
export interface FilterParam {
    recordStatus?: boolean;
    deleteFlag?: boolean;
    roleId?: number;
}
export interface IProfile {
    isView?: boolean;
}
export interface IReport {
    ReportAllTime?: boolean;
    ReportProject?: boolean;
    ReportUser?: boolean;
    ReportTaskType?: boolean;
    ReportDelay?: boolean;
}
export interface UserProfile {
    TennantId: string;
    UserId: number;
    UserName: string;
    PersonalId: number;
    FullNameTH: string;
    FirstNameTH: string;
    LastNameTH: string;
    PositionId: number;
    PositionNameTH: string;
    OrganizeId: number;
    OrganizeLevel: number;
    OrganizeRootId: number;
    OrganizeNameTH: string;
    ImageUrl: string;
    LastAccessDateTime: Date;
    UserType: number;
    Role: Role;
    Roles: Role[];
}
export interface Role {
    AppCode: string;
    RoleId: number;
    RoleCode: string;
    RoleName: string;
    OrgRefId: number;
    OrgLevel: number;
}
