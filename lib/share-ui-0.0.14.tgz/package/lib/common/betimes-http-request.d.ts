import { HttpClient, HttpHeaders, HttpRequest, HttpParams, HttpProgressEvent } from '@angular/common/http';
import { HttpStatusResult, HttpStatusResultValue } from './common-type';
import { Observable } from 'rxjs';
export declare class BetimesHttpRequest<T> implements IRequestBuilder<T> {
    private http;
    _url: string;
    _param: {
        [p: string]: string | number;
    };
    _header: HttpHeaders;
    _responseType: string;
    _reportProgress: boolean;
    _useSystemReulst: boolean;
    _criticalErrorDialog: boolean;
    _errorDialog: boolean;
    _useCache: boolean;
    _useCacheInvalidate: boolean;
    _host: string;
    _body: {
        [b: string]: any;
    };
    _raw: boolean;
    constructor(http: HttpClient);
    host(h: string): IRequestBuilder<T>;
    raw(): IRequestBuilder<T>;
    api(url: string): IRequestBuilder<T>;
    body(body: {
        [b: string]: any;
    }): IRequestBuilder<T>;
    queryString(param: {
        [p: string]: string | number;
    }): IRequestBuilder<T>;
    header(head: HttpHeaders | {
        [header: string]: string | string[];
    }): IRequestBuilder<T>;
    responseType(r: "arraybuffer" | "blob" | "json"): IRequestBuilder<T>;
    result<TResult>(): IRequestBuilder<TResult>;
    useSystemResult<T extends HttpStatusResult>(): IRequestBuilder<T>;
    reportProgress(): IRequestBuilder<HttpProgressEvent | HttpStatusResult>;
    disableCriticalDialogError(): IRequestBuilder<T>;
    disableDialogError(): IRequestBuilder<T>;
    cache(): IRequestBuilder<T>;
    invalidate(): IRequestBuilder<T>;
    post(): Observable<T>;
    get(): Observable<T>;
    patch(): Observable<T>;
    put(): Observable<T>;
    delete(): Observable<T>;
    private send;
}
export declare class BetimesRequest extends HttpRequest<HttpStatusResult> {
    displayError: boolean;
    displayCriticalError: boolean;
    useOnlyValue: boolean;
    useCache: boolean;
    useCacheInvalidate: boolean;
    raw: boolean;
    clone(update?: {
        headers?: HttpHeaders;
        reportProgress?: boolean;
        params?: HttpParams;
        responseType?: 'arraybuffer' | 'blob' | 'json';
        withCredentials?: boolean;
        body?: any;
        method?: string;
        url?: string;
        setHeaders?: {
            [name: string]: string | string[];
        };
        setParams?: {
            [param: string]: string;
        };
    }): BetimesRequest;
}
export declare class BetimesHttpResultError extends Error {
    private err;
    constructor(err: HttpStatusResult);
    get HttpResult(): HttpStatusResult;
}
export declare type ResponseStatusValue<T> = IRequestBuilder<HttpStatusResultValue<T>>;
export declare type ResponseStatus = IRequestBuilder<HttpStatusResult>;
export interface IRequestBuilder<T> {
    api(url: string): IRequestBuilder<T>;
    host(h: string): IRequestBuilder<T>;
    body(body: {
        [b: string]: any;
    }): IRequestBuilder<T>;
    queryString(param: {
        [p: string]: string | number;
    }): IRequestBuilder<T>;
    header(head: HttpHeaders | {
        [header: string]: string | string[];
    }): IRequestBuilder<T>;
    raw(): IRequestBuilder<T>;
    responseType(r: "arraybuffer" | "blob" | "json"): IRequestBuilder<T>;
    reportProgress(): IRequestBuilder<HttpProgressEvent | HttpStatusResult>;
    result<TResult>(): IRequestBuilder<TResult>;
    useSystemResult<T extends HttpStatusResult>(): IRequestBuilder<T>;
    disableCriticalDialogError(): IRequestBuilder<T>;
    disableDialogError(): IRequestBuilder<T>;
    invalidate(): IRequestBuilder<T>;
    cache(): IRequestBuilder<T>;
    post(): Observable<T>;
    get(): Observable<T>;
    patch(): Observable<T>;
    put(): Observable<T>;
    delete(): Observable<T>;
}
export declare function req<T>(api?: string): IRequestBuilder<T>;
