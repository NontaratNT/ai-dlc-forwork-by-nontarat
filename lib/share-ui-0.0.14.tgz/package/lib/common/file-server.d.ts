import { Observable } from 'rxjs';
import { HttpStatusResult, HttpStatusResultValue } from './common-type';
export declare class FileServer implements IFileServer, IUploadServer {
    private _http;
    private _baseApiUrl;
    private _endpoint;
    private _skipProgressing;
    private _param;
    private _uploadParamName;
    private _fileId;
    private _fileActionVerb;
    private constructor();
    static connect(host?: string): IFileServer;
    file(endpoint?: string): IFileServerAction;
    identity(id: number | string): IFileServerAction;
    withVerb(httpVerb: "GET" | "POST" | "DELETE"): IFileServerAction;
    view(): Observable<HttpStatusResultValue<Blob>>;
    delete(): HttpStatusResult;
    upload(endpoint?: string): IUploadServer;
    isReportProgressing(): IUploadServer;
    withUploadParamName(uploadName: string): IUploadServer;
    withParam(p: {
        [key: string]: any;
    }): IUploadServer;
    fromFile(files: File[]): IUploadSubscribe;
    fromFormData(formData: FormData): IUploadSubscribe;
    private _startUpload;
}
export interface IFileServer {
    upload(endpoint?: string): IUploadServer;
    file(endpoint?: string): IFileServerAction;
}
export interface IUploadSubscribe {
    Subscribe(next?: (value: IProgressing) => void, complete?: () => void): void;
}
export interface IProgressing {
    FileName: string;
    FileSize: number;
    PercentToComplete: number;
    ErrorMessage: string;
    Status: UploadStatus;
}
export declare enum UploadStatus {
    Ready = 0,
    Uploading = 1,
    Failure = 2,
    Success = 3
}
export interface IUploadServer {
    isReportProgressing(): IUploadServer;
    fromFile(files: File[]): IUploadSubscribe;
    fromFormData(formData: FormData): IUploadSubscribe;
    withParam(p: {
        [key: string]: any;
    }): IUploadServer;
    withUploadParamName(uploadName: string): IUploadServer;
}
export interface IFileServerAction {
    identity(id: number | string): IFileServerAction;
    withVerb(httpVerb: string): IFileServerAction;
    withParam(p: {
        [key: string]: any;
    }): IUploadServer;
    view(): Observable<HttpStatusResultValue<Blob>>;
    delete(): Observable<HttpStatusResult>;
}
