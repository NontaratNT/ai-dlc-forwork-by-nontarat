export declare const StaticBag: {
    InjectorInstance: any;
};
