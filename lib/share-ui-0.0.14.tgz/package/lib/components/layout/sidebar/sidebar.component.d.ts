import { Router } from '@angular/router';
import { ConfigulationService } from '../../../common/configuration.service';
import { OrganizeInfoService } from '../../../models/organize-info.service';
declare global {
    interface HTMLElement {
        setAllStyle(element: any, value: any, content: any): any;
    }
}
export declare class SidebarComponent {
    private router;
    private config;
    private orgService;
    constructor(router: Router, config: ConfigulationService, orgService: OrganizeInfoService);
}
