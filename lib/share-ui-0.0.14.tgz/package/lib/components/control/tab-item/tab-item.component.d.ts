import { OnInit, TemplateRef, ViewRef } from '@angular/core';
export declare class TabItemComponent implements OnInit {
    _state: {
        visible: boolean;
        init: boolean;
    };
    recreateOnActive: boolean;
    _template: TemplateRef<any>;
    childViewRef: ViewRef;
    set visible(v: boolean);
    get visible(): boolean;
    constructor();
    activate(): void;
    ngOnInit(): void;
}
