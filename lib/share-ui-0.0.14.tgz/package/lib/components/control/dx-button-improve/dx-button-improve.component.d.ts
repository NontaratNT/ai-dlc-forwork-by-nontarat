import { EventEmitter, ChangeDetectorRef } from '@angular/core';
export declare class DxButtonImproveComponent {
    private cd;
    widgetClass: string;
    text: string;
    type: string;
    icon: string;
    height: number | string;
    hint: string;
    width: number | string;
    disabled: boolean;
    visible: boolean;
    waitIcon: string;
    waitText: string;
    disableOnWait: boolean;
    onClick: EventEmitter<DxButtonImproveEvent>;
    private _oldIcon;
    private _oldText;
    private _isWait;
    private _widget;
    constructor(cd: ChangeDetectorRef);
    OnInitialized(e: any): void;
    OnClicked(e: any): void;
    Click(): void;
    StartWait(): void;
    StopWait(): void;
}
export interface DxButtonImproveEvent {
    event: any;
    startWait: () => void;
    stopWait: () => void;
}
