import { OnInit, AfterContentInit, QueryList, ElementRef, AfterViewInit, EventEmitter } from '@angular/core';
import { TabItemComponent } from '../tab-item/tab-item.component';
export declare class TabPanelComponent implements OnInit, AfterContentInit, AfterViewInit {
    _queryTapItems: QueryList<TabItemComponent>;
    tabPanel: ElementRef<Element>;
    _tabItems: TabItemComponent[];
    _lastLinkSelect: HTMLElement;
    tabsTitle: string[];
    selectIndex: number;
    onTabSelectChanged: EventEmitter<number>;
    constructor();
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    _onSelectIndexChanged(e: any): void;
    _selectTab(element: HTMLElement): void;
}
