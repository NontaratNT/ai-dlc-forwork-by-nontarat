(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('formiojs'), require('formiojs/components/day/Day'), require('formiojs/components/day/Day.form'), require('@formio/angular'), require('formiojs/Formio'), require('formiojs/components/datetime/DateTime.form'), require('moment'), require('moment-timezone'), require('i18next'), require('lodash'), require('native-promise-only'), require('formiojs/components/select/Select.form.js'), require('formiojs/components/select/editForm/Select.edit.display'), require('formiojs/components/editgrid/EditGrid.form.js'), require('formiojs/components/editgrid/editForm/EditGrid.edit.display'), require('formiojs/utils/utils'), require('formiojs/components/editgrid/templates'), require('formiojs/components/file/File.form.js'), require('formiojs/components/file/editForm/File.edit.file'), require('formiojs/components/_classes/field/Field'), require('downloadjs'), require('@angular/core'), require('devextreme-angular'), require('share-ui'), require('@angular/common/http'), require('formiojs/components/recaptcha/ReCaptcha.form.js'), require('formiojs/components/recaptcha/editForm/ReCaptcha.edit.display'), require('lodash/get'), require('rxjs/operators'), require('formiojs/components/textfield/TextField.form'), require('formiojs/components/password/editForm/Password.edit.display'), require('formiojs/components/password/editForm/Password.edit.data'), require('formiojs/components/password/editForm/Password.edit.validation'), require('crypto-js/sha256')) :
    typeof define === 'function' && define.amd ? define('eform-share', ['exports', 'formiojs', 'formiojs/components/day/Day', 'formiojs/components/day/Day.form', '@formio/angular', 'formiojs/Formio', 'formiojs/components/datetime/DateTime.form', 'moment', 'moment-timezone', 'i18next', 'lodash', 'native-promise-only', 'formiojs/components/select/Select.form.js', 'formiojs/components/select/editForm/Select.edit.display', 'formiojs/components/editgrid/EditGrid.form.js', 'formiojs/components/editgrid/editForm/EditGrid.edit.display', 'formiojs/utils/utils', 'formiojs/components/editgrid/templates', 'formiojs/components/file/File.form.js', 'formiojs/components/file/editForm/File.edit.file', 'formiojs/components/_classes/field/Field', 'downloadjs', '@angular/core', 'devextreme-angular', 'share-ui', '@angular/common/http', 'formiojs/components/recaptcha/ReCaptcha.form.js', 'formiojs/components/recaptcha/editForm/ReCaptcha.edit.display', 'lodash/get', 'rxjs/operators', 'formiojs/components/textfield/TextField.form', 'formiojs/components/password/editForm/Password.edit.display', 'formiojs/components/password/editForm/Password.edit.data', 'formiojs/components/password/editForm/Password.edit.validation', 'crypto-js/sha256'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["eform-share"] = {}, global.formiojs, global.DayComponent, global.DayEditForm, global.angular, global.Formio, global.DateTimeEditForm, global.moment, global.momentTimezone, global.i18next, global._, global.NativePromise, global.baseEditForm, global.SelectEditDisplay, global.baseEditForm$1, global.EditGridEditDisplay, global.utils, global.templates, global.baseEditForm$2, global.FileEditDisplay, global.Field, global.download, global.ng.core, global.devextremeAngular, global.shareUi, global.ng.common.http, global.baseEditForm$3, global.ReCaptchaEditDisplay, global._get, global.rxjs.operators, global.textEditForm, global.PasswordEditDisplay, global.PasswordEditData, global.PasswordEditValidation, global.sha256));
})(this, (function (exports, formiojs, DayComponent, DayEditForm, angular, Formio, DateTimeEditForm, moment, momentTimezone, i18next, _, NativePromise, baseEditForm, SelectEditDisplay, baseEditForm$1, EditGridEditDisplay, utils, templates, baseEditForm$2, FileEditDisplay, Field, download, i0, devextremeAngular, shareUi, http, baseEditForm$3, ReCaptchaEditDisplay, _get, operators, textEditForm, PasswordEditDisplay, PasswordEditData, PasswordEditValidation, sha256) { 'use strict';

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var DayComponent__default = /*#__PURE__*/_interopDefaultLegacy(DayComponent);
    var DayEditForm__default = /*#__PURE__*/_interopDefaultLegacy(DayEditForm);
    var Formio__default = /*#__PURE__*/_interopDefaultLegacy(Formio);
    var DateTimeEditForm__default = /*#__PURE__*/_interopDefaultLegacy(DateTimeEditForm);
    var moment__namespace = /*#__PURE__*/_interopNamespace(moment);
    var momentTimezone__namespace = /*#__PURE__*/_interopNamespace(momentTimezone);
    var i18next__default = /*#__PURE__*/_interopDefaultLegacy(i18next);
    var ___default = /*#__PURE__*/_interopDefaultLegacy(_);
    var NativePromise__default = /*#__PURE__*/_interopDefaultLegacy(NativePromise);
    var baseEditForm__default = /*#__PURE__*/_interopDefaultLegacy(baseEditForm);
    var SelectEditDisplay__default = /*#__PURE__*/_interopDefaultLegacy(SelectEditDisplay);
    var baseEditForm__default$1 = /*#__PURE__*/_interopDefaultLegacy(baseEditForm$1);
    var EditGridEditDisplay__default = /*#__PURE__*/_interopDefaultLegacy(EditGridEditDisplay);
    var templates__default = /*#__PURE__*/_interopDefaultLegacy(templates);
    var baseEditForm__default$2 = /*#__PURE__*/_interopDefaultLegacy(baseEditForm$2);
    var FileEditDisplay__default = /*#__PURE__*/_interopDefaultLegacy(FileEditDisplay);
    var Field__default = /*#__PURE__*/_interopDefaultLegacy(Field);
    var download__default = /*#__PURE__*/_interopDefaultLegacy(download);
    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var baseEditForm__default$3 = /*#__PURE__*/_interopDefaultLegacy(baseEditForm$3);
    var ReCaptchaEditDisplay__default = /*#__PURE__*/_interopDefaultLegacy(ReCaptchaEditDisplay);
    var _get__default = /*#__PURE__*/_interopDefaultLegacy(_get);
    var textEditForm__default = /*#__PURE__*/_interopDefaultLegacy(textEditForm);
    var PasswordEditDisplay__default = /*#__PURE__*/_interopDefaultLegacy(PasswordEditDisplay);
    var PasswordEditData__default = /*#__PURE__*/_interopDefaultLegacy(PasswordEditData);
    var PasswordEditValidation__default = /*#__PURE__*/_interopDefaultLegacy(PasswordEditValidation);
    var sha256__default = /*#__PURE__*/_interopDefaultLegacy(sha256);

    /******************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
            desc = { enumerable: true, get: function () { return m[k]; } };
        }
        Object.defineProperty(o, k2, desc);
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2)
            for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                    if (!ar)
                        ar = Array.prototype.slice.call(from, 0, i);
                    ar[i] = from[i];
                }
            }
        return to.concat(ar || Array.prototype.slice.call(from));
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }
    function __classPrivateFieldIn(state, receiver) {
        if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function"))
            throw new TypeError("Cannot use 'in' operator on non-object");
        return typeof state === "function" ? receiver === state : state.has(receiver);
    }

    // @dynamic
    var BetimesDay = /** @class */ (function (_super) {
        __extends(BetimesDay, _super);
        function BetimesDay(component, options, data) {
            var _this = _super.call(this, component, options, data) || this;
            _super.prototype.init.call(_this);
            return _this;
        }
        Object.defineProperty(BetimesDay, "builderInfo", {
            get: function () {
                return {
                    title: "Day Thai",
                    group: "advanced",
                    icon: "calendar",
                    documentation: "/userguide/#day",
                    weight: 50,
                    schema: BetimesDay.schema()
                };
            },
            enumerable: false,
            configurable: true
        });
        BetimesDay.schema = function () {
            return DayComponent__default["default"].schema({
                type: "dayThai",
            });
        };
        Object.defineProperty(BetimesDay.prototype, "months", {
            get: function () {
                if (this._months) {
                    return this._months;
                }
                this._months = [
                    { value: 1, label: "มกราคม" },
                    { value: 2, label: "กุมภาพันธ์" },
                    { value: 3, label: "มีนาคม" },
                    { value: 4, label: "เมษายน" },
                    { value: 5, label: "พฤษภาคม" },
                    { value: 6, label: "มิถุนายน" },
                    { value: 7, label: "กรกฎาคม" },
                    { value: 8, label: "สิงหาคม" },
                    { value: 9, label: "กันยายน" },
                    { value: 10, label: "ตุลาคม" },
                    { value: 11, label: "พฤศจิกายน" },
                    { value: 12, label: "ธันวาคม" }
                ];
                return this._months;
            },
            enumerable: false,
            configurable: true
        });
        return BetimesDay;
    }(DayComponent__default["default"]));
    BetimesDay.editForm = DayEditForm__default["default"];
    formiojs.Components.addComponent("dayThai", BetimesDay);

    var DateTimeComponent = Formio__default["default"].Components.components.datetime;
    // @dynamic
    var BetimesDateTime = /** @class */ (function (_super) {
        __extends(BetimesDateTime, _super);
        function BetimesDateTime(component, options, data) {
            var _this = _super.call(this, component, options, data) || this;
            component.widget.locale = "th";
            component.widget.language = "th-TH";
            component.widget.timezone = "Asia/Bangkok";
            component.widget.plugins = [_this.convertToBuddhistPlugin(component, _this)];
            return _this;
            // this.dataValue =
        }
        Object.defineProperty(BetimesDateTime, "builderInfo", {
            get: function () {
                return {
                    title: "Date/Time Thai",
                    group: "advanced",
                    icon: "calendar",
                    documentation: "/userguide/#datetime",
                    weight: 40,
                    schema: BetimesDateTime.schema()
                };
            },
            enumerable: false,
            configurable: true
        });
        BetimesDateTime.schema = function () {
            return DateTimeComponent.schema({
                type: "dateTimeThai",
            });
        };
        BetimesDateTime.prototype.attachElement = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            this.component.widget.locale = i18next__default["default"].language;
            return _super.prototype.attachElement.call(this, args);
        };
        BetimesDateTime.prototype.createWidget = function (index) {
            var _this = this;
            var widget = _super.prototype.createWidget.call(this, index);
            if (widget && widget.settings.disableFunction) {
                Object.defineProperty(widget, "disableFunction", {
                    get: function () { return function (date) { return _this.evaluate("return " + widget.settings.disableFunction, {
                        date: date,
                        row: _this.data,
                        data: _this.root._submission.data,
                        moment: moment__namespace
                    }); }; }
                });
            }
            return widget;
        };
        BetimesDateTime.prototype.setValue = function (value, flags) {
            if (flags === void 0) { flags = {}; }
            if (value && this.component.enableTime) {
                value = momentTimezone__namespace(value).tz("Asia/Bangkok").format();
            }
            _super.prototype.setValue.call(this, value, flags);
        };
        BetimesDateTime.prototype.getValueAsString = function (value) {
            var format = angular.FormioUtils.convertFormatToMoment(this.component.format);
            if (i18next__default["default"].language === "en") {
                return (value ? moment__namespace(value).format(format) : value) || '';
            }
            return (value ? moment__namespace(value).add(543, "year").format(format) : value) || '';
        };
        BetimesDateTime.prototype.convertToBuddhistPlugin = function (component, root) {
            var currentDate;
            return function (fp) {
                currentDate = root.getValue();
                if (i18next__default["default"].language === "en") {
                    return {
                        onChange: function (d) {
                            currentDate = d;
                        }
                    };
                }
                return {
                    onChange: function (d) {
                        currentDate = d;
                        updateYear();
                    },
                    onYearChange: updateYear,
                    onOpen: [
                        updateYear,
                        reloadDisableDate
                    ],
                    onMonthChange: updateYear,
                    onReady: [
                        addListeners,
                        updateYear,
                        function () {
                            // แก้บัค lib ตอนโหลดข้อมูลเข้าแล้วแสดง text ใน textBox ไม่ถูกต้อง ไม่ยอมเอาค่าจาก formatDate
                            setTimeout(function () {
                                // const startDate = (this as any).getValue();
                                if (currentDate) {
                                    fp.setDate(currentDate, true);
                                }
                                // else if (startDate) {
                                //     let format = component.widget.format;
                                //     // INFO: เนื่องจากข้อมูลที่ได้จากฐานข้อมูลจะอยู่ในรูปแบบ yyyy-MM-DD เราจึงต้องแปลง date ให้ตรง format
                                //     if (format.startsWith("dd-MMM-yyyy") || format.startsWith("dd MMM yyyy")
                                //     || format.startsWith("dd/MMM/yyyy")) {
                                //         format = format.replace("yyyy", "DD")
                                //             .replace("dd", "yyyy")
                                //             .replace("MMM", "MM");
                                //     }
                                //     else if (format.startsWith("dd-MM-yyyy") || format.startsWith("dd MM yyyy")
                                //     || format.startsWith("dd/MM/yyyy")) {
                                //         format = format.replace("yyyy", "DD")
                                //             .replace("dd", "yyyy");
                                //     }
                                //     const md = moment(startDate, format);
                                //     console.log(md.toDate(), format);
                                //     fp.setDate(md.toDate(), true);
                                // }
                            });
                            fp.loadedPlugins.push("convertToBuddhist");
                        }
                    ]
                };
                function reloadDisableDate() {
                    if (component.widget.disableFunction) {
                        fp.jumpToDate(undefined, false);
                        fp.currentYearElement.value = fp.currentYear + 543;
                    }
                }
                function updateYear() {
                    fp.currentYearElement.value = fp.currentYear + 543;
                }
                function addListeners() {
                    fp.formatDate = function (date) {
                        var format = formiojs.Utils.convertFormatToMoment(component.widget.format);
                        var md = moment__namespace(date, format);
                        var christianYear = md.format("YYYY");
                        var buddhishYear = (parseInt(christianYear, 0) + 543).toString();
                        return md
                            .format(format.replace("YYYY", buddhishYear).replace("YY", buddhishYear.substring(2, 4)))
                            .replace(christianYear, buddhishYear);
                    };
                    fp.parseDate = function (date) {
                        var format = formiojs.Utils.convertFormatToMoment(component.widget.format);
                        var md = moment__namespace(date, format);
                        if (md.year() >= 2400) {
                            md.subtract(543, "year");
                        }
                        else if (!md.year()) {
                            return currentDate[0];
                        }
                        return md.toDate();
                    };
                    fp._bind(fp.currentYearElement, "keyup", function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (fp.currentYearElement.value.length === 4) {
                            var year = parseInt(fp.currentYearElement.value, 0);
                            if (year) {
                                fp.changeYear(year - 543);
                            }
                        }
                    });
                    fp._bind(fp.prevMonthNav, "click", function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        fp.changeMonth(-1);
                        updateYear();
                    });
                    fp._bind(fp.nextMonthNav, "click", function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        fp.changeMonth(1);
                        updateYear();
                    });
                }
            };
        };
        return BetimesDateTime;
    }(DateTimeComponent));
    BetimesDateTime.editForm = DateTimeEditForm__default["default"];
    formiojs.Components.addComponent("dateTimeThai", BetimesDateTime);

    function SelectEditForm () {
        return baseEditForm__default["default"]([
            {
                key: 'select',
                components: SelectEditDisplay__default["default"].unshift({
                    key: 'tableViewAsync',
                    label: 'Table View Async',
                    tooltip: 'แสดงค่านี้ใน Table View แบบ Async',
                    type: 'checkbox',
                    weight: 1501,
                    input: true,
                    defaultValue: false
                }, {
                    weight: 1500,
                    type: 'checkbox',
                    label: 'Table View',
                    tooltip: 'Shows this value within the table view of the submissions.',
                    key: 'tableView',
                    input: true,
                    calculateValue: function (c) { return c.data.tableViewAsync ? false : c.data.tableView; }
                })
            }
        ]);
    }

    var SelectComponent = angular.Formio.Components.components.select;
    // @dynamic
    var BetimesSelectComponent = /** @class */ (function (_super) {
        __extends(BetimesSelectComponent, _super);
        function BetimesSelectComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BetimesSelectComponent.prototype.setChoicesValue = function (value, hasPreviousValue, flags) {
            if (flags === void 0) { flags = {}; }
            var hasValue = !this.isEmpty(value);
            hasPreviousValue = (hasPreviousValue === undefined) ? true : hasPreviousValue;
            if (this.choices) {
                // Now set the value.
                if (hasValue) {
                    this.choices.removeActiveItems();
                    // Add the currently selected choices if they don't already exist.
                    var currentChoices = Array.isArray(value) ? value : [value];
                    if (!this.addCurrentChoices(currentChoices, this.selectOptions, true)) {
                        this.choices.setChoices(this.selectOptions, 'value', 'label', true);
                    }
                    if (typeof value === "number") {
                        value = value.toString();
                    }
                    this.choices.setChoiceByValue(value);
                }
                else if (hasPreviousValue || flags.resetValue) {
                    this.choices.removeActiveItems();
                }
            }
            else {
                if (hasValue) {
                    var values_1 = Array.isArray(value) ? value : [value];
                    ___default["default"].each(this.selectOptions, function (selectOption) {
                        ___default["default"].each(values_1, function (val) {
                            if (___default["default"].isEqual(val, selectOption.value) && selectOption.element) {
                                selectOption.element.selected = true;
                                selectOption.element.setAttribute('selected', 'selected');
                                return false;
                            }
                            return true;
                        });
                    });
                }
                else {
                    ___default["default"].each(this.selectOptions, function (selectOption) {
                        if (selectOption.element) {
                            selectOption.element.selected = false;
                            selectOption.element.removeAttribute('selected');
                        }
                    });
                }
            }
        };
        BetimesSelectComponent.prototype.getViewAsync = function (value, options) {
            var _this = this;
            var valueView = _super.prototype.getView.call(this, value, options);
            var resolver;
            var awaiter = new NativePromise__default["default"](function (resolve) {
                resolver = resolve;
            });
            if (this.component.dataSrc === "url") {
                var resolveDataView = function () {
                    var opv = _this.selectOptions.find(function (_) { return _.value === valueView; });
                    opv = opv ? opv.label : valueView;
                    resolver(opv);
                };
                if (this.selectOptions.length) {
                    resolveDataView();
                }
                else {
                    this.updateItems(null, true);
                    this.itemsLoaded.then(resolveDataView);
                }
            }
            else {
                resolver(valueView);
            }
            return awaiter;
        };
        return BetimesSelectComponent;
    }(SelectComponent));
    BetimesSelectComponent.editForm = SelectEditForm;
    BetimesSelectComponent.editForm = SelectEditForm;
    formiojs.Components.setComponent('select', BetimesSelectComponent);

    function EditGridForm () {
        return baseEditForm__default$1["default"]([
            {
                key: 'display',
                components: EditGridEditDisplay__default["default"].unshift({
                    key: 'viewMode',
                    label: 'ดูได้แม้ ReadOnly',
                    tooltip: 'เมื่อ ReadOnly สามารถกดดูรายการได้',
                    type: 'checkbox',
                    weight: 1000,
                    input: true,
                    defaultValue: true
                })
            }
        ]);
    }

    var template$1 = "\n<ul class=\"editgrid-listgroup list-group\n    {{ ctx.component.striped ? 'table-striped' : ''}}\n    {{ ctx.component.bordered ? 'table-bordered' : ''}}\n    {{ ctx.component.hover ? 'table-hover' : ''}}\n    {{ ctx.component.condensed ? 'table-sm' : ''}}\n    \">\n    {% if (ctx.header) { %}\n    <li class=\"list-group-item list-group-header\">\n        {{ctx.header}}\n    </li>\n    {% } %}\n    {% ctx.rows.forEach(function(row, rowIndex) { %}\n    <li class=\"list-group-item\" ref=\"{{ctx.ref.row}}\">\n        {{row}}\n        {% if (ctx.openRows[rowIndex] && !ctx.readOnly) { %}\n        <div class=\"editgrid-actions\">\n            <button class=\"btn btn-primary\" ref=\"{{ctx.ref.saveRow}}\">{{ctx.t(ctx.component.saveRow || 'Save', {\n                _userInput: true })}}</button>\n            {% if (ctx.component.removeRow) { %}\n            <button class=\"btn btn-danger\" ref=\"{{ctx.ref.cancelRow}}\">{{ctx.t(ctx.component.removeRow || 'Cancel', {\n                _userInput: true })}}</button>\n            {% } %}\n        </div>\n        {% } else if (ctx.openRows[rowIndex] && ctx.readOnly && ctx.viewMode) { %}\n            <button class=\"btn btn-danger\" ref=\"{{ctx.ref.closeRow}}\">{{ctx.t('\u0E1B\u0E34\u0E14', {\n            _userInput: true })}}</button>\n        {% } %}\n        <div class=\"has-error\">\n            <div class=\"editgrid-row-error help-block\">\n                {{ctx.errors[rowIndex]}}\n            </div>\n        </div>\n    </li>\n    {% }) %}\n    {% if (ctx.footer) { %}\n    <li class=\"list-group-item list-group-footer\">\n        {{ctx.footer}}\n    </li>\n    {% } %}\n</ul>\n{% if (!ctx.readOnly && ctx.hasAddButton) { %}\n<button class=\"btn btn-primary\" ref=\"{{ctx.ref.addRow}}\">\n    <i class=\"{{ctx.iconClass('plus')}}\"></i> {{ctx.t(ctx.component.addAnother || 'Add Another', { _userInput: true })}}\n</button>\n{% } %}";

    var EditGridComponent = Formio__default["default"].Components.components.editgrid;
    // @dynamic
    var EditGridCustom = /** @class */ (function (_super) {
        __extends(EditGridCustom, _super);
        function EditGridCustom() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.closeRowRef = _this.editgridKey + "-closeRow";
            return _this;
        }
        Object.defineProperty(EditGridCustom.prototype, "CloseRowElements", {
            get: function () {
                return this.refs[this.closeRowRef];
            },
            enumerable: false,
            configurable: true
        });
        EditGridCustom.prototype.render = function (children) {
            var _this = this;
            if (this.builderMode) {
                return _super.prototype.render.call(this);
            }
            var dataValue = this.dataValue || [];
            var headerTemplate = utils.Evaluator.noeval ? templates__default["default"].header : ___default["default"].get(this.component, 'templates.header');
            var t = this.t.bind(this);
            return _super.prototype.render.call(this, children || this.customRender(template$1, {
                ref: {
                    row: this.rowRef,
                    addRow: this.addRowRef,
                    saveRow: this.saveRowRef,
                    cancelRow: this.cancelRowRef,
                    closeRow: this.closeRowRef
                },
                header: this.renderString(headerTemplate, {
                    displayValue: function (component) { return _this.displayComponentValue(component); },
                    components: this.component.components,
                    value: dataValue,
                    t: t
                }),
                footer: this.renderString(___default["default"].get(this.component, 'templates.footer'), {
                    components: this.component.components,
                    value: dataValue,
                    t: t
                }),
                rows: this.editRows.map(this.renderRow.bind(this)),
                openRows: this.editRows.map(function (row) { return _this.isOpen(row); }),
                errors: this.editRows.map(function (row) { return row.error; }),
                hasAddButton: this.hasAddButton(),
                hasRemoveButtons: this.hasRemoveButtons()
            }));
        };
        EditGridCustom.prototype.attach = function (element) {
            var _b;
            var _this = this;
            if (this.builderMode) {
                return _super.prototype.attach.call(this, element);
            }
            var w = _super.prototype.attach.call(this, element);
            this.loadRefs(element, (_b = {},
                _b[this.closeRowRef] = 'multiple',
                _b));
            var openRowCount = 0;
            this.rowElements.forEach(function (row, rowIndex) {
                var editRow = _this.editRows[rowIndex];
                if (_this.isOpen(editRow)) {
                    _this.addEventListener(_this.CloseRowElements[openRowCount], 'click', function () { return _this.closeRow(rowIndex); });
                    openRowCount++;
                }
                var elements = row.getElementsByClassName("viewRow");
                Array.prototype.forEach.call(elements, function (ele) {
                    _this.addEventListener(ele, "click", function () { return _this.viewRow(rowIndex); });
                });
            });
            return w;
        };
        EditGridCustom.prototype.viewRow = function (rowIndex) {
            var editRow = this.editRows[rowIndex];
            editRow.prevState = editRow.state;
            editRow.state = "viewing";
            return this.redraw();
        };
        EditGridCustom.prototype.closeRow = function (rowIndex) {
            var editRow = this.editRows[rowIndex];
            editRow.state = "draft";
            this.redraw();
        };
        EditGridCustom.prototype.customRender = function (template, data) {
            if (data === void 0) { data = {}; }
            data.component = this.component;
            data.self = this;
            data.options = this.options;
            data.readOnly = this.disabled;
            data.iconClass = this.iconClass.bind(this);
            data.size = this.size.bind(this);
            data.t = this.t.bind(this);
            data.transform = this.transform;
            data.id = data.id || this.id;
            data.key = data.key || this.key;
            data.value = data.value || this.dataValue;
            data.disabled = this.disabled;
            data.builder = this.builderMode;
            data.label = this.labelInfo;
            data.tooltip = this.getFormattedTooltip(this.component.tooltip);
            data.viewMode = this.component.viewMode;
            return this.renderString(template, data);
        };
        EditGridCustom.prototype.renderRow = function (row, rowIndex) {
            var _this = this;
            var dataValue = this.dataValue || [];
            if (this.isOpen(row)) {
                return this.renderComponents(row.components);
            }
            else {
                var flattenedComponents_1 = this.flattenComponents(rowIndex);
                var rowTemplate = utils.Evaluator.noeval ? templates__default["default"].row :
                    ___default["default"].get(this.component, 'templates.row', EditGridComponent.defaultRowTemplate);
                return this.renderString(rowTemplate, {
                    row: dataValue[rowIndex] || {},
                    data: this.data,
                    rowIndex: rowIndex,
                    components: this.component.components,
                    flattenedComponents: flattenedComponents_1,
                    displayValue: function (component) { return _this.displayComponentValue(component); },
                    isVisibleInRow: function (component) { return _this.isComponentVisibleInRow(component, flattenedComponents_1); },
                    getView: function (component, data) {
                        var _a;
                        var instance = flattenedComponents_1[component.key];
                        if (instance && instance.component.tableViewAsync) {
                            if (_this.editRows[rowIndex].dataAsync) {
                                return _this.editRows[rowIndex].dataAsync[component.key];
                            }
                            else {
                                instance.getViewAsync(data || instance.dataValue).then(function (d) {
                                    if (!_this.editRows[rowIndex].dataAsync) {
                                        _this.editRows[rowIndex].dataAsync = {};
                                    }
                                    _this.editRows[rowIndex].dataAsync[component.key] = d;
                                    _this.redraw();
                                });
                            }
                        }
                        else {
                            var view = instance ? instance.getView(data || instance.dataValue) : '';
                            var htmlTagRegExp = new RegExp('<(.*?)>');
                            return typeof view === 'string' && view.length && !((_a = instance.component) === null || _a === void 0 ? void 0 : _a.template) && htmlTagRegExp.test(view)
                                ? "<input type=\"text\" value=\"" + view.replace(/"/g, '&quot;') + "\" readonly/>"
                                : view;
                        }
                    },
                    state: this.editRows[rowIndex].state,
                    t: this.t.bind(this)
                });
            }
        };
        EditGridCustom.prototype.saveRow = function (rowIndex, modified) {
            if (this.editRows[rowIndex].dataAsync) {
                delete this.editRows[rowIndex].dataAsync;
            }
            _super.prototype.saveRow.call(this, rowIndex, modified);
        };
        return EditGridCustom;
    }(EditGridComponent));
    EditGridCustom.editForm = EditGridForm;
    formiojs.Components.setComponent('editgrid', EditGridCustom);

    function FileForm () {
        return baseEditForm__default$2["default"]([
            {
                key: 'file',
                components: FileEditDisplay__default["default"].unshift({
                    key: 'preview',
                    label: 'Preview File',
                    tooltip: 'เมื่อกดปุ่มดูไฟล์จะเป็นการ Preview ไฟล์แทนที่จะดาวน์โหลด',
                    type: 'checkbox',
                    weight: 33,
                    input: true,
                    defaultValue: false
                })
            }
        ]);
    }

    var template = "\n{% if (!ctx.self.imageUpload) { %}\n  <ul class=\"list-group list-group-striped\">\n    <li class=\"list-group-item list-group-header hidden-xs hidden-sm\">\n      <div class=\"row\">\n        <div class=\"col-md-1\"></div>\n        <div class=\"col-md-{% if (ctx.self.hasTypes) { %}7{% } else { %}9{% } %}\"><strong>{{ctx.t('File Name')}}</strong></div>\n        <div class=\"col-md-2\"><strong>{{ctx.t('Size')}}</strong></div>\n        {% if (ctx.self.hasTypes) { %}\n          <div class=\"col-md-2\"><strong>{{ctx.t('Type')}}</strong></div>\n        {% } %}\n      </div>\n    </li>\n    {% ctx.files.forEach(function(file) { %}\n      <li class=\"list-group-item\">\n        <div class=\"row\">\n          <div class=\"col-md-1\">\n            <i role=\"button\" href=\"{{file.url || '#'}}\" class=\"{{ctx.iconClass('eye')}}\" ref=\"fileLink\"></i>\n          </div>\n          <div class=\"col-md-{% if (ctx.self.hasTypes) { %}7{% } else { %}9{% } %}\">\n            {% if (ctx.component.uploadOnly) { %}\n              {{file.originalName || file.name}}\n            {% } else { %}\n              <a target=\"_blank\" >{{file.originalName || file.name}}</a>\n            {% } %}\n          </div>\n          <div class=\"col-md-2\">\n            <span class=\"mr-3\">{{ctx.fileSize(file.size)}}</span>\n            {% if (!ctx.disabled) { %}\n                <i role=\"button\" class=\"{{ctx.iconClass('remove')}}\" ref=\"removeLink\"></i>\n            {% } %}\n          </div>\n          {% if (ctx.self.hasTypes && !ctx.disabled) { %}\n            <div class=\"col-md-2\">\n              <select class=\"file-type\" ref=\"fileType\">\n                {% ctx.component.fileTypes.map(function(type) { %}\n                  <option class=\"test\" value=\"{{ type.value }}\" {% if (type.label === file.fileType) { %}selected=\"selected\"{% } %}>{{ type.label }}</option>\n                {% }); %}\n              </select>\n            </div>\n          {% } %}\n          {% if (ctx.self.hasTypes && ctx.disabled) { %}\n          <div class=\"col-md-2\"><span>{{file.fileType}}<span></div>\n          {% } %}\n        </div>\n      </li>\n    {% }) %}\n  </ul>\n{% } else { %}\n  <div>\n    {% ctx.files.forEach(function(file) { %}\n      <div>\n        <span>\n          <img ref=\"fileImage\" src=\"\" alt=\"{{file.originalName || file.name}}\" style=\"width:{{ctx.component.imageSize}}px\">\n          {% if (!ctx.disabled) { %}\n            <i class=\"{{ctx.iconClass('remove')}}\" ref=\"removeLink\"></i>\n          {% } %}\n        </span>\n      </div>\n    {% }) %}\n  </div>\n{% } %}\n{% if (!ctx.disabled && (ctx.component.multiple || !ctx.files.length)) { %}\n  {% if (ctx.self.useWebViewCamera) { %}\n    <div class=\"fileSelector\">\n      <button class=\"btn btn-primary\" ref=\"galleryButton\"><i class=\"fa fa-book\"></i> {{ctx.t('Gallery')}}</button>\n      <button class=\"btn btn-primary\" ref=\"cameraButton\"><i class=\"fa fa-camera\"></i> {{ctx.t('Camera')}}</button>\n    </div>\n  {% } else if (!ctx.self.cameraMode) { %}\n    <div class=\"fileSelector\" ref=\"fileDrop\" {{ctx.fileDropHidden ? 'hidden' : ''}}>\n      <i class=\"{{ctx.iconClass('cloud-upload')}}\"></i> {{ctx.t('Drop files to attach,')}}\n        {% if (ctx.self.imageUpload && ctx.component.webcam) { %}\n          <a href=\"#\" ref=\"toggleCameraMode\"><i class=\"fa fa-camera\"></i> {{ctx.t('Use Camera,')}}</a>\n        {% } %}\n        {{ctx.t('or')}} <a href=\"#\" ref=\"fileBrowse\" class=\"browse\">{{ctx.t('browse')}}</a>\n      <div ref=\"fileProcessingLoader\" class=\"loader-wrapper\">\n        <div class=\"loader text-center\"></div>\n      </div>\n    </div>\n  {% } else { %}\n    <div class=\"video-container\">\n      <video class=\"video\" autoplay=\"true\" ref=\"videoPlayer\"></video>\n    </div>\n    <button class=\"btn btn-primary\" ref=\"takePictureButton\"><i class=\"fa fa-camera\"></i> {{ctx.t('Take Picture')}}</button>\n    <button class=\"btn btn-primary\" ref=\"toggleCameraMode\">{{ctx.t('Switch to file upload')}}</button>\n  {% } %}\n{% } %}\n{% ctx.statuses.forEach(function(status) { %}\n  <div class=\"file {{ctx.statuses.status === 'error' ? ' has-error' : ''}}\">\n    <div class=\"row\">\n      <div class=\"fileName col-form-label col-sm-10\">{{status.originalName}} <i class=\"{{ctx.iconClass('remove')}}\" ref=\"fileStatusRemove\"></i></div>\n      <div class=\"fileSize col-form-label col-sm-2 text-right\">{{ctx.fileSize(status.size)}}</div>\n    </div>\n    <div class=\"row\">\n      <div class=\"col-sm-12\">\n        {% if (status.status === 'progress') { %}\n          <div class=\"progress\">\n            <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"{{status.progress}}\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: {{status.progress}}%\">\n              <span class=\"sr-only\">{{status.progress}}% {{ctx.t('Complete')}}</span>\n            </div>\n          </div>\n        {% } else if (status.status === 'error') { %}\n          <div class=\"alert alert-danger bg-{{status.status}}\">{{ctx.t(status.message)}}</div>\n        {% } else { %}\n          <div class=\"bg-{{status.status}}\">{{ctx.t(status.message)}}</div>\n        {% } %}\n      </div>\n    </div>\n  </div>\n{% }) %}\n{% if (!ctx.component.storage || ctx.support.hasWarning) { %}\n  <div class=\"alert alert-warning\">\n    {% if (!ctx.component.storage) { %}\n      <p>{{ctx.t('No storage has been set for this field. File uploads are disabled until storage is set up.')}}</p>\n    {% } %}\n    {% if (!ctx.support.filereader) { %}\n      <p>{{ctx.t('File API & FileReader API not supported.')}}</p>\n    {% } %}\n    {% if (!ctx.support.formdata) { %}\n      <p>{{ctx.t(\"XHR2's FormData is not supported.\")}}</p>\n    {% } %}\n    {% if (!ctx.support.progress) { %}\n      <p>{{ctx.t(\"XHR2's upload progress isn't supported.\")}}</p>\n    {% } %}\n  </div>\n{% } %}";

    var FileComponent = Formio__default["default"].Components.components.file;
    // @dynamic
    var FileCustom = /** @class */ (function (_super) {
        __extends(FileCustom, _super);
        function FileCustom() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FileCustom.prototype.render = function () {
            return Field__default["default"].prototype.render.call(this, this.customRender(template, {
                fileSize: this.fileSize,
                files: this.dataValue || [],
                statuses: this.statuses,
                disabled: this.disabled,
                support: this.support,
                fileDropHidden: this.fileDropHidden
            }));
        };
        FileCustom.prototype.customRender = function (template, data) {
            if (data === void 0) { data = {}; }
            data.component = this.component;
            data.self = this;
            data.options = this.options;
            data.readOnly = this.options.readOnly;
            data.iconClass = this.iconClass.bind(this);
            data.size = this.size.bind(this);
            data.t = this.t.bind(this);
            data.transform = this.transform;
            data.id = data.id || this.id;
            data.key = data.key || this.key;
            data.value = data.value || this.dataValue;
            data.disabled = this.disabled;
            data.builder = this.builderMode;
            data.label = this.labelInfo;
            data.tooltip = this.getFormattedTooltip(this.component.tooltip);
            return this.renderString(template, data);
        };
        FileCustom.prototype.getFile = function (fileInfo) {
            var _this = this;
            var _a = this.component.options, options = _a === void 0 ? {} : _a;
            var fileService = this.fileService;
            if (!fileService) {
                return alert('File Service not provided');
            }
            if (this.component.privateDownload) {
                fileInfo.private = true;
            }
            fileService.downloadFile(fileInfo, options).then(function (file) {
                if (file) {
                    if (['base64', 'indexeddb'].includes(file.storage) && !_this.component.preview) {
                        download__default["default"](file.url, file.originalName || file.name, file.type);
                    }
                    else {
                        window.open(file.url, '_blank');
                    }
                }
            })
                .catch(function (response) {
                alert(response);
            });
        };
        return FileCustom;
    }(FileComponent));
    FileCustom.editForm = FileForm;
    formiojs.Components.setComponent('file', FileCustom);

    var EformShareComponent = /** @class */ (function () {
        function EformShareComponent() {
        }
        EformShareComponent.prototype.ngOnInit = function () {
        };
        return EformShareComponent;
    }());
    EformShareComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'efs-eform-share',
                    template: ""
                },] }
    ];
    EformShareComponent.ctorParameters = function () { return []; };

    var FormCommandInvoker = /** @class */ (function () {
        function FormCommandInvoker() {
            this.onLoadCommandList = new Set();
            this.onSubmitCommandList = new Set();
            this.onDestroyCommandList = new Set();
        }
        FormCommandInvoker.prototype.executeOnLoad = function (context) {
            return __awaiter(this, void 0, void 0, function () {
                var _a, _b, command, result, e_1_1;
                var e_1, _c;
                return __generator(this, function (_d) {
                    switch (_d.label) {
                        case 0:
                            _d.trys.push([0, 5, 6, 7]);
                            _a = __values(this.onLoadCommandList), _b = _a.next();
                            _d.label = 1;
                        case 1:
                            if (!!_b.done) return [3 /*break*/, 4];
                            command = _b.value;
                            result = command.onLoad(context);
                            if (!(result !== undefined)) return [3 /*break*/, 3];
                            return [4 /*yield*/, result];
                        case 2:
                            _d.sent();
                            _d.label = 3;
                        case 3:
                            _b = _a.next();
                            return [3 /*break*/, 1];
                        case 4: return [3 /*break*/, 7];
                        case 5:
                            e_1_1 = _d.sent();
                            e_1 = { error: e_1_1 };
                            return [3 /*break*/, 7];
                        case 6:
                            try {
                                if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                            }
                            finally { if (e_1) throw e_1.error; }
                            return [7 /*endfinally*/];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        FormCommandInvoker.prototype.executeOnSubmit = function (context) {
            return __awaiter(this, void 0, void 0, function () {
                var _a, _b, command, result, e_2_1;
                var e_2, _c;
                return __generator(this, function (_d) {
                    switch (_d.label) {
                        case 0:
                            _d.trys.push([0, 5, 6, 7]);
                            _a = __values(this.onSubmitCommandList), _b = _a.next();
                            _d.label = 1;
                        case 1:
                            if (!!_b.done) return [3 /*break*/, 4];
                            command = _b.value;
                            result = command.onSubmit(context);
                            if (!(result !== undefined)) return [3 /*break*/, 3];
                            return [4 /*yield*/, result];
                        case 2:
                            _d.sent();
                            _d.label = 3;
                        case 3:
                            _b = _a.next();
                            return [3 /*break*/, 1];
                        case 4: return [3 /*break*/, 7];
                        case 5:
                            e_2_1 = _d.sent();
                            e_2 = { error: e_2_1 };
                            return [3 /*break*/, 7];
                        case 6:
                            try {
                                if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                            }
                            finally { if (e_2) throw e_2.error; }
                            return [7 /*endfinally*/];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        FormCommandInvoker.prototype.executeOnDestroy = function (context) {
            return __awaiter(this, void 0, void 0, function () {
                var _a, _b, command, result, e_3_1;
                var e_3, _c;
                return __generator(this, function (_d) {
                    switch (_d.label) {
                        case 0:
                            _d.trys.push([0, 5, 6, 7]);
                            _a = __values(this.onDestroyCommandList), _b = _a.next();
                            _d.label = 1;
                        case 1:
                            if (!!_b.done) return [3 /*break*/, 4];
                            command = _b.value;
                            result = command.onDestroy(context);
                            if (!(result !== undefined)) return [3 /*break*/, 3];
                            return [4 /*yield*/, result];
                        case 2:
                            _d.sent();
                            _d.label = 3;
                        case 3:
                            _b = _a.next();
                            return [3 /*break*/, 1];
                        case 4: return [3 /*break*/, 7];
                        case 5:
                            e_3_1 = _d.sent();
                            e_3 = { error: e_3_1 };
                            return [3 /*break*/, 7];
                        case 6:
                            try {
                                if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                            }
                            finally { if (e_3) throw e_3.error; }
                            return [7 /*endfinally*/];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        return FormCommandInvoker;
    }());
    FormCommandInvoker.decorators = [
        { type: i0.Injectable }
    ];
    FormCommandInvoker.ctorParameters = function () { return []; };

    var EmptyDefaultValueCommand = /** @class */ (function () {
        function EmptyDefaultValueCommand() {
        }
        EmptyDefaultValueCommand.prototype.onSubmit = function (context) {
            var newData = {};
            for (var key in context.submission) {
                var value = context.submission[key];
                if (value === "" || value === undefined) {
                    newData[key] = null;
                    continue;
                }
                newData[key] = value;
            }
            context.submission = newData;
        };
        return EmptyDefaultValueCommand;
    }());

    var ReCaptchaCommand = /** @class */ (function () {
        function ReCaptchaCommand() {
        }
        ReCaptchaCommand.prototype.onLoad = function (context) {
            this._reCaptchaComponent = context.formio.formio.getComponent("recaptcha");
            if (this._reCaptchaComponent) {
                document.body.classList.add("recaptcha");
            }
        };
        ReCaptchaCommand.prototype.onSubmit = function (context) {
            if (this._reCaptchaComponent) {
                var resultCaptcha = context.submission[this._reCaptchaComponent.key];
                if (resultCaptcha.success && resultCaptcha.score >= 0.5) {
                    delete context.submission[this._reCaptchaComponent.key];
                }
                else {
                    throw new Error("ระบบตรวจได้ว่าคุณคือ 'บอท (BOT)' คุณไม่สามารถดำเนินการต่อได้");
                }
            }
        };
        ReCaptchaCommand.prototype.onDestroy = function () {
            if (this._reCaptchaComponent) {
                document.body.classList.remove("recaptcha");
            }
        };
        return ReCaptchaCommand;
    }());

    var SubmissionCommnad = /** @class */ (function () {
        function SubmissionCommnad(_renderComponent) {
            this._renderComponent = _renderComponent;
        }
        SubmissionCommnad.prototype.onSubmit = function (context) {
            return __awaiter(this, void 0, void 0, function () {
                var formRender, eventBeforeSubmit, beforeSubmitEvent, resultAfterSubmit;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            formRender = this._renderComponent;
                            if (!formRender._formConfig.formType) {
                                throw new Error("การทำงานถูกยกเลิก เนื่องจากไม่พบประเภทฟอร์ม");
                            }
                            eventBeforeSubmit = { component: formRender, data: context.submission };
                            beforeSubmitEvent = formRender.beforeSubmit(eventBeforeSubmit);
                            if (!(beforeSubmitEvent !== undefined)) return [3 /*break*/, 2];
                            return [4 /*yield*/, beforeSubmitEvent];
                        case 1:
                            resultAfterSubmit = _a.sent();
                            if (!resultAfterSubmit.isSuccess) {
                                throw new Error(resultAfterSubmit.message);
                            }
                            _a.label = 2;
                        case 2: return [2 /*return*/];
                    }
                });
            });
        };
        return SubmissionCommnad;
    }());

    function trimObject(obj) {
        if (obj) {
            Object.keys(obj).forEach(function (k) { return (obj[k] == null || obj[k] === undefined) && delete obj[k]; });
        }
    }

    var FormConfigService = /** @class */ (function () {
        function FormConfigService(_req) {
            this._req = _req;
        }
        FormConfigService.prototype.gets = function () {
            return this._req("form-config").get();
        };
        FormConfigService.prototype.get = function (id) {
            return this._req("form-config/" + id).get();
        };
        FormConfigService.prototype.create = function (config) {
            return this._req("form-config")
                .useSystemResult()
                .body(config)
                .post();
        };
        FormConfigService.prototype.find = function (filter) {
            trimObject(filter);
            return this._req("form-config/find").queryString(filter).get();
        };
        FormConfigService.prototype.validate = function (config) {
            return this._req("form-config/validate").body(config).post();
        };
        FormConfigService.prototype.update = function (id, config) {
            return this._req("form-config/" + id)
                .useSystemResult()
                .body(config)
                .put();
        };
        FormConfigService.prototype.delete = function (id) {
            return this._req("form-config/" + id)
                .useSystemResult()
                .delete();
        };
        FormConfigService.prototype.deleteByFormCode = function (formCode) {
            return this._req("form-config")
                .body({ formCode: formCode })
                .useSystemResult()
                .delete();
        };
        return FormConfigService;
    }());
    FormConfigService.decorators = [
        { type: i0.Injectable }
    ];
    FormConfigService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [EFORM_REQUEST,] }] }
    ]; };

    var Submission = /** @class */ (function () {
        function Submission(request) {
            this.request = request;
        }
        Submission.prototype.get = function (formId, submitId) {
            return this.request.api("form-submit/form/" + formId + "/doc/" + submitId)
                .get();
        };
        Submission.prototype.create = function (formId, data) {
            return this.request.api("form-submit/form/" + formId)
                .disableCriticalDialogError()
                .useSystemResult()
                .body(data)
                .post();
        };
        Submission.prototype.update = function (formId, submitId, data) {
            return this.request.api("form-submit/form/" + formId + "/doc/" + submitId)
                .disableCriticalDialogError()
                .useSystemResult()
                .body(data)
                .patch();
        };
        return Submission;
    }());

    var TaskSubmission = /** @class */ (function (_super) {
        __extends(TaskSubmission, _super);
        function TaskSubmission(request) {
            return _super.call(this, request) || this;
        }
        TaskSubmission.prototype.get = function (formId, submitId) {
            return this.request.api("task/form/" + formId + "/doc/" + submitId)
                .get();
        };
        TaskSubmission.prototype.create = function (formId, data) {
            return this.request.api("task/form/" + formId)
                .disableCriticalDialogError()
                .useSystemResult()
                .body(data)
                .post();
        };
        TaskSubmission.prototype.update = function (formId, submitId, data) {
            return this.request.api("task/form/" + formId + "/submit/" + submitId)
                .disableCriticalDialogError()
                .useSystemResult()
                .body(data)
                .patch();
        };
        return TaskSubmission;
    }(Submission));

    var FormSubmitService = /** @class */ (function () {
        function FormSubmitService(_req) {
            this._req = _req;
        }
        FormSubmitService.prototype.getSubmission = function (fromType) {
            var request = this._req();
            if (fromType === "T") {
                return new TaskSubmission(request);
            }
            return new Submission(request);
        };
        return FormSubmitService;
    }());
    FormSubmitService.decorators = [
        { type: i0.Injectable }
    ];
    FormSubmitService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [EFORM_REQUEST,] }] }
    ]; };

    // @dynamic
    var EFormDefaulti18n = /** @class */ (function () {
        function EFormDefaulti18n() {
        }
        return EFormDefaulti18n;
    }());

    var FormioRenderComponent = /** @class */ (function () {
        function FormioRenderComponent(_formConfigService, _dialog, _formSubmitService, _formInvoker) {
            var _this = this;
            this._formConfigService = _formConfigService;
            this._dialog = _dialog;
            this._formSubmitService = _formSubmitService;
            this._formInvoker = _formInvoker;
            this.readOnly = false;
            this.loadingPanelPosition = "#formContainer";
            this.onFormReady = new i0.EventEmitter();
            this.onInitialized = new i0.EventEmitter();
            this._refreshForm = new i0.EventEmitter();
            this.loadingVisible = false;
            this._formioOption = {
                hooks: {
                    beforeSubmit: undefined
                }
            };
            this._isFirstReady = false;
            this.isSubmission = false;
            this._language = EFormDefaulti18n.language;
            this._formioOption.hooks.beforeSubmit = function (s, c) {
                _this._submitForm(s.data, c);
            };
            this.renderOptions = { validateOnInit: false };
            if (EFormDefaulti18n.language) {
                this.renderOptions.language = EFormDefaulti18n.language;
            }
            if (EFormDefaulti18n.i18n) {
                this.renderOptions.i18n = EFormDefaulti18n.i18n;
            }
        }
        Object.defineProperty(FormioRenderComponent.prototype, "language", {
            get: function () {
                return this._language;
            },
            set: function (v) {
                if (this.formio) {
                    this.formio.formio.language = v;
                }
                this._language = v;
            },
            enumerable: false,
            configurable: true
        });
        FormioRenderComponent.prototype.ngOnChanges = function (changes) {
            var e_1, _a;
            if (changes.readOnly && this.formio) {
                try {
                    for (var _b = __values(this.formio.formio.getComponents()), _c = _b.next(); !_c.done; _c = _b.next()) {
                        var component = _c.value;
                        component.disabled = changes.readOnly.currentValue;
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                this.formio.formio.redraw();
            }
            if (changes.renderOptions) {
                changes.renderOptions.currentValue.language = this.language;
                if (EFormDefaulti18n.i18n) {
                    changes.renderOptions.currentValue.i18n = EFormDefaulti18n.i18n;
                }
            }
        };
        FormioRenderComponent.prototype.ngOnInit = function () {
            var _this = this;
            var recaptchaCommand = new ReCaptchaCommand();
            this._formInvoker.onLoadCommandList.add(recaptchaCommand);
            this._formInvoker.onSubmitCommandList.add(recaptchaCommand);
            this._formInvoker.onSubmitCommandList.add(new EmptyDefaultValueCommand());
            this._formInvoker.onDestroyCommandList.add(recaptchaCommand);
            if (this.formId) {
                this._formConfigService.get(this.formId).subscribe(function (f) {
                    _this.setFormConfig(f);
                });
            }
        };
        FormioRenderComponent.prototype.ngOnDestroy = function () {
            this._formInvoker.executeOnDestroy({ formio: this.formio });
        };
        FormioRenderComponent.prototype.formReady = function () {
            if (!this._isFirstReady) {
                this.onInitialized.emit(this);
                this._isFirstReady = true;
            }
            this.onFormReady.emit(this);
        };
        FormioRenderComponent.prototype.setFormConfig = function (config, submission) {
            var _this = this;
            var resolver;
            var p = new Promise(function (_) { return resolver = _; });
            this._formConfig = config;
            var form = JSON.parse(config.formJson);
            var getSubmitData;
            if (!submission && this.submissionId) {
                getSubmitData = this._formSubmitService.getSubmission(config.formType).get(config.id, this.submissionId);
            }
            if (getSubmitData) {
                getSubmitData.subscribe(function (s) {
                    _this._setForm(form, s).then(function () {
                        _this._formInvoker.executeOnLoad({
                            formio: _this.formio,
                            submission: s
                        }).then(function () {
                            resolver();
                        });
                    });
                });
            }
            else {
                this._setForm(form, submission).then(function () {
                    _this._formInvoker.executeOnLoad({
                        formio: _this.formio
                    }).then(function () {
                        resolver();
                    });
                });
            }
            return p;
        };
        FormioRenderComponent.prototype.setDataSubmission = function (submission) {
            if (this._formConfig == null) {
                throw new Error("ไม่พบข้อมูล FormConfig");
            }
            this.submissionId = submission._id;
            this._refreshForm.emit({
                submission: {
                    data: submission
                }
            });
        };
        FormioRenderComponent.prototype.reset = function () {
            this.submissionId = undefined;
            this.isSubmission = false;
            this.formio.alerts.setAlerts([]);
            this._refreshForm.emit({
                submission: {
                    data: {}
                }
            });
        };
        FormioRenderComponent.prototype._setForm = function (form, submission) {
            var _this = this;
            if (form.display === "wizard" && this.readOnly) {
                form.components.forEach(function (_) {
                    if (_.buttonSettings) {
                        _.buttonSettings.cancel = false;
                    }
                });
            }
            var formReady = this.formio.setForm(form);
            // แก้ไขไม่ให้มัน validation ตอน init form
            if (form.display === "wizard" && !this.readOnly) {
                this.formio.formio.setSubmission({}, { noValidate: !this.renderOptions.validateOnInit });
            }
            return formReady.then(function () {
                if (submission) {
                    var data_1 = _this.formio.formio.data;
                    if (data_1) {
                        _this.submissionId = submission._id;
                        Object.keys(submission).forEach(function (k) { return data_1[k] = submission[k]; });
                    }
                    else {
                        data_1 = submission;
                    }
                    _this.formio.formio.setSubmission({ data: data_1 }, { noValidate: true });
                }
            });
        };
        FormioRenderComponent.prototype._submitForm = function (data, formioCallback) {
            return __awaiter(this, void 0, void 0, function () {
                var submissionCommnad, error_1;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!this.submissionId && this.isSubmission) {
                                this.formio.onSubmit(data, true);
                                return [2 /*return*/];
                            }
                            submissionCommnad = new SubmissionCommnad(this);
                            this._formInvoker.onSubmitCommandList.add(submissionCommnad);
                            _a.label = 1;
                        case 1:
                            _a.trys.push([1, 3, , 4]);
                            return [4 /*yield*/, this._formInvoker.executeOnSubmit({ formio: this.formio, submission: data })];
                        case 2:
                            _a.sent();
                            this.isSubmission = true;
                            this.formio.onSubmit(data, true);
                            return [3 /*break*/, 4];
                        case 3:
                            error_1 = _a.sent();
                            if (error_1.message) {
                                this._dialog.error("ผิดพลาด", error_1.message);
                                formioCallback({ message: error_1.message }, null);
                            }
                            return [3 /*break*/, 4];
                        case 4:
                            this._formInvoker.onSubmitCommandList.delete(submissionCommnad);
                            return [2 /*return*/];
                    }
                });
            });
        };
        return FormioRenderComponent;
    }());
    FormioRenderComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'efs-formio-render',
                    template: "<div id=\"formContainer\">\r\n    <formio #internalForm [renderOptions]=\"renderOptions\" [readOnly]=\"readOnly\" [refresh]=\"_refreshForm\" [options]=\"_formioOption\"\r\n    (ready)=\"formReady()\"\r\n    ></formio>\r\n    <dx-load-panel\r\n        #loadPanel\r\n        shadingColor=\"rgba(0,0,0,0.4)\"\r\n        [position]=\"{ of: loadingPanelPosition }\"\r\n        [visible]=\"loadingVisible\"\r\n        [showIndicator]=\"true\"\r\n        [shading]=\"false\"\r\n        [closeOnOutsideClick]=\"false\">\r\n    </dx-load-panel>\r\n</div>\r\n",
                    providers: [FormCommandInvoker],
                    styles: [""]
                },] }
    ];
    FormioRenderComponent.ctorParameters = function () { return [
        { type: FormConfigService },
        { type: shareUi.Dialog },
        { type: FormSubmitService },
        { type: FormCommandInvoker }
    ]; };
    FormioRenderComponent.propDecorators = {
        formId: [{ type: i0.Input }],
        submissionId: [{ type: i0.Input }],
        readOnly: [{ type: i0.Input }],
        loadingPanelPosition: [{ type: i0.Input }],
        renderOptions: [{ type: i0.Input }],
        beforeSubmit: [{ type: i0.Input }],
        language: [{ type: i0.Input }],
        formio: [{ type: i0.ViewChild, args: ["internalForm",] }],
        onFormReady: [{ type: i0.Output }],
        onInitialized: [{ type: i0.Output }]
    };

    function editForm$1 () {
        return baseEditForm__default$3["default"]([
            {
                key: 'display',
                components: ReCaptchaEditDisplay__default["default"].unshift({
                    type: 'checkbox',
                    key: 'siteKeyOnSetting',
                    label: 'Use SiteKey Form Project Setting',
                    tooltip: 'ใช้ siteKey ที่จาก project',
                    weight: 655
                })
            },
            {
                key: 'display',
                components: ReCaptchaEditDisplay__default["default"].unshift({
                    key: 'siteKey',
                    label: 'Site Key',
                    tooltip: 'ระบุ Site Key ที่ได้จาก google',
                    type: 'textfield',
                    weight: 660,
                    customConditional: function (context) {
                        return !context.data.siteKeyOnSetting;
                    }
                })
            },
            {
                key: 'data',
                ignore: true
            },
            {
                key: 'validation',
                ignore: true
            },
            {
                key: 'conditional',
                ignore: true
            },
            {
                key: 'logic',
                ignore: true
            }
        ]);
    }

    var ReCaptchaComponent = angular.Formio.Components.components.recaptcha;
    // @dynamic
    var BetimesReCaptchaComponent = /** @class */ (function (_super) {
        __extends(BetimesReCaptchaComponent, _super);
        function BetimesReCaptchaComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BetimesReCaptchaComponent.prototype.verify = function (actionName) {
            var key = this.component.siteKeyOnSetting ?
                (_get__default["default"](this.root.form, 'settings.recaptcha.siteKey') || BetimesReCaptchaComponent.siteKey) :
                this.component.siteKey;
            this.root.form.settings = {
                recaptcha: {
                    siteKey: key
                }
            };
            _super.prototype.verify.call(this, actionName);
        };
        BetimesReCaptchaComponent.prototype.createInput = function () {
            var key = this.component.siteKeyOnSetting ?
                (_get__default["default"](this.root.form, 'settings.recaptcha.siteKey') || BetimesReCaptchaComponent.siteKey) :
                this.component.siteKey;
            this.root.form.settings = {
                recaptcha: {
                    siteKey: key
                }
            };
            _super.prototype.createInput.call(this);
        };
        BetimesReCaptchaComponent.prototype.sendVerificationRequest = function (token) {
            return angular.Formio.makeStaticRequest(BetimesReCaptchaComponent.projectUrl + "/recaptcha?recaptchaToken=" + token)
                .then(function (r) { return ({ verificationResult: r.Value, token: token }); });
        };
        return BetimesReCaptchaComponent;
    }(ReCaptchaComponent));
    BetimesReCaptchaComponent.editForm = editForm$1;
    BetimesReCaptchaComponent.editForm = editForm$1;
    formiojs.Components.setComponent('recaptcha', BetimesReCaptchaComponent);

    var LOCAl_CONFIG = new i0.InjectionToken("EformShareModule.LocalConfig");
    var EFORM_REQUEST = new i0.InjectionToken("EformShareModule.EformRequest");
    function httpRequestFactory(http, config) {
        var c = function createHttpRequest(endpoint) {
            var _a;
            return new shareUi.BetimesHttpRequest(http).host((_a = config.eFormHost) !== null && _a !== void 0 ? _a : config.baseConfig.apiUrl).api(endpoint);
        };
        return c;
    }
    var EformShareModule = /** @class */ (function () {
        function EformShareModule(config) {
            var _a;
            moment__namespace.locale("th");
            BetimesReCaptchaComponent.projectUrl = (_a = config.eFormHost) !== null && _a !== void 0 ? _a : config.baseConfig.apiUrl;
            BetimesReCaptchaComponent.siteKey = config.recaptcha ? config.recaptcha.siteKey : undefined;
        }
        EformShareModule.forRoot = function (config) {
            return {
                ngModule: EformShareModule,
                providers: [
                    { provide: shareUi.SHARE_UI_CONFIG, useValue: config.baseConfig },
                    { provide: LOCAl_CONFIG, useValue: config }
                ]
            };
        };
        return EformShareModule;
    }());
    EformShareModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [FormioRenderComponent, EformShareComponent],
                    imports: [
                        devextremeAngular.DxLoadPanelModule,
                        angular.FormioModule,
                        shareUi.ShareUiModule
                    ],
                    exports: [FormioRenderComponent],
                    schemas: [i0.CUSTOM_ELEMENTS_SCHEMA],
                    providers: [
                        FormSubmitService,
                        FormConfigService,
                        { provide: shareUi.Dialog, useExisting: shareUi.DevExtreamDialog },
                        { provide: EFORM_REQUEST, useFactory: httpRequestFactory, deps: [http.HttpClient, LOCAl_CONFIG] }
                    ]
                },] }
    ];
    EformShareModule.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [LOCAl_CONFIG,] }] }
    ]; };

    exports.SortOrder = void 0;
    (function (SortOrder) {
        SortOrder["Ascending"] = "Ascending";
        SortOrder["Descending"] = "Descending";
    })(exports.SortOrder || (exports.SortOrder = {}));

    var FormPublishingService = /** @class */ (function () {
        function FormPublishingService(_req) {
            this._req = _req;
        }
        FormPublishingService.prototype.find = function (filter) {
            trimObject(filter);
            return this._req("form-pub/find").queryString(filter).get();
        };
        FormPublishingService.prototype.create = function (pub) {
            return this._req("form-pub")
                .useSystemResult()
                .body(pub)
                .post();
        };
        FormPublishingService.prototype.update = function (id, pub) {
            return this._req("form-pub/" + id)
                .useSystemResult()
                .body(pub)
                .put();
        };
        return FormPublishingService;
    }());
    FormPublishingService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function FormPublishingService_Factory() { return new FormPublishingService(i0__namespace.ɵɵinject(EFORM_REQUEST)); }, token: FormPublishingService, providedIn: "root" });
    FormPublishingService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    FormPublishingService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [EFORM_REQUEST,] }] }
    ]; };

    var ApiStockService = /** @class */ (function () {
        function ApiStockService(_req) {
            this._req = _req;
        }
        ApiStockService.prototype.find = function (filter) {
            trimObject(filter);
            return this._req("api-stock/find").queryString(filter).get();
        };
        ApiStockService.prototype.create = function (stock) {
            return this._req("api-stock")
                .useSystemResult()
                .body(stock)
                .post();
        };
        ApiStockService.prototype.update = function (id, stock) {
            return this._req("api-stock/" + id)
                .useSystemResult()
                .body(stock)
                .put();
        };
        return ApiStockService;
    }());
    ApiStockService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ApiStockService_Factory() { return new ApiStockService(i0__namespace.ɵɵinject(EFORM_REQUEST)); }, token: ApiStockService, providedIn: "root" });
    ApiStockService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    ApiStockService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [EFORM_REQUEST,] }] }
    ]; };

    var WorkflowVariable = /** @class */ (function () {
        function WorkflowVariable(_processVariables) {
            this._processVariables = _processVariables;
        }
        WorkflowVariable.prototype.getValue = function (varName) {
            var v = this._processVariables[varName];
            if (!v) {
                return undefined;
            }
            return this._convertValue(v.Type.toLocaleLowerCase(), v.value, v.ValueInfo);
        };
        WorkflowVariable.prototype.getVariableValue = function (varName) {
            var v = this._processVariables[varName];
            if (!v) {
                return undefined;
            }
            return v;
        };
        WorkflowVariable.prototype.values = function () {
            var convertObj = {};
            for (var key in this._processVariables) {
                convertObj[key] = this.getValue(key);
            }
            return convertObj;
        };
        WorkflowVariable.prototype._convertValue = function (typeName, value, valueInfo) {
            var convertedValue;
            switch (typeName) {
                case "boolean":
                    convertedValue = Boolean(value);
                    break;
                case "date":
                    convertedValue = new Date(value);
                    break;
                case "short":
                case "integer":
                case "long":
                case "double":
                    convertedValue = Number(value);
                    break;
                case "object":
                    if (value && valueInfo.serializationDataFormat === "application/json") {
                        convertedValue = JSON.parse(value);
                    }
                    else {
                        convertedValue = value;
                    }
                    break;
                case "null":
                    convertedValue = undefined;
                    break;
                default:
                    convertedValue = value;
                    break;
            }
            return convertedValue;
        };
        return WorkflowVariable;
    }());

    var WorkflowService = /** @class */ (function () {
        function WorkflowService(_req) {
            this._req = _req;
        }
        // #region Process Definition
        WorkflowService.prototype.getProcessDefinitions = function (filter) {
            return this._req().api("Workflow/process-definition")
                .queryString(filter)
                .get();
        };
        WorkflowService.prototype.getProcessDefinitionXml = function (defId) {
            return this._req().api("Workflow/process-definition/xml")
                .body({ ProcessDefinitionId: defId })
                .post();
        };
        WorkflowService.prototype.getProcessInstanceStatistics = function (filter) {
            return this._req().api("Workflow/process-definition/statistics")
                .queryString(filter)
                .get();
        };
        // #endregion
        WorkflowService.prototype.getProcessInstance = function (id) {
            return this._req().api("Workflow/process-instance/" + id)
                .get();
        };
        WorkflowService.prototype.getProcessInstanceVariable = function (id) {
            return this._req().api("Workflow/process-instance/" + id + "/variables")
                .get()
                .pipe(operators.map(function (v) { return new WorkflowVariable(v); }));
        };
        WorkflowService.prototype.getDecisionDefinition = function (filter) {
            return this._req().api("Workflow/decision-definition")
                .queryString(filter)
                .get();
        };
        WorkflowService.prototype.getDecisionDefinitionXml = function (defId) {
            return this._req().api("Workflow/decision-definition/xml")
                .body({ DecisionDefinitionId: defId })
                .post();
        };
        WorkflowService.prototype.getCaseDefinition = function (filter) {
            return this._req().api("Workflow/case-definition")
                .queryString(filter)
                .get();
        };
        WorkflowService.prototype.getCaseDefinitionXml = function (defId) {
            return this._req().api("Workflow/case-definition/xml")
                .body({ CaseDefinitionId: defId })
                .post();
        };
        // #region Task
        WorkflowService.prototype.getTask = function (id) {
            return this._req().api("Workflow/task/" + id)
                .get();
        };
        WorkflowService.prototype.getTasks = function (filter) {
            return this._req().api("Workflow/task")
                .queryString(filter)
                .get();
        };
        WorkflowService.prototype.getTaskUserCount = function (username, groupName) {
            return this._req().api("Workflow/task/user/count")
                .queryString({ Assignee: username, CandidateGroup: groupName })
                .get();
        };
        WorkflowService.prototype.claimTask = function (param) {
            return this._req().api("Workflow/task/" + param.TaskId + "/claim")
                .body({ UserId: param.UserId })
                .useSystemResult()
                .post();
        };
        WorkflowService.prototype.unclaimTask = function (param) {
            return this._req().api("Workflow/task/" + param.TaskId + "/unclaim")
                .body({ UserId: param.UserId })
                .useSystemResult()
                .post();
        };
        // #endregion
        WorkflowService.prototype.getHistoryTasks = function (searchObj) {
            return this._req("Workflow/history/task")
                .body(searchObj)
                .post();
        };
        WorkflowService.prototype.deploy = function (file) {
            var f = new FormData();
            f.append("upload", file);
            return this._req("Workflow/deployment/create")
                .useSystemResult()
                .body(f)
                .post();
        };
        WorkflowService.prototype.updateProcessDefinitionSuspend = function (procId, param) {
            return this._req("Workflow/process-definition/" + procId + "/suspended")
                .useSystemResult()
                .body(param)
                .post();
        };
        return WorkflowService;
    }());
    WorkflowService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function WorkflowService_Factory() { return new WorkflowService(i0__namespace.ɵɵinject(EFORM_REQUEST)); }, token: WorkflowService, providedIn: "root" });
    WorkflowService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    WorkflowService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [EFORM_REQUEST,] }] }
    ]; };
    exports.HistoricTaskSorting = void 0;
    (function (HistoricTaskSorting) {
        HistoricTaskSorting["TaskId"] = "taskId";
        HistoricTaskSorting["Priority"] = "priority";
        HistoricTaskSorting["EndTime"] = "endTime";
        HistoricTaskSorting["StartTime"] = "startTime";
    })(exports.HistoricTaskSorting || (exports.HistoricTaskSorting = {}));
    exports.TaskSorting = void 0;
    (function (TaskSorting) {
        TaskSorting["Id"] = "id";
        TaskSorting["Created"] = "created";
        TaskSorting["Assignee"] = "assignee";
        TaskSorting["DueDate"] = "dueDate";
        TaskSorting["ProcessInstanceId"] = "instanceId";
    })(exports.TaskSorting || (exports.TaskSorting = {}));
    exports.DecisionDefinitionSorting = void 0;
    (function (DecisionDefinitionSorting) {
        DecisionDefinitionSorting["Category"] = "Category";
        DecisionDefinitionSorting["Key"] = "Key";
        DecisionDefinitionSorting["Id"] = "Id";
        DecisionDefinitionSorting["Name"] = "Name";
        DecisionDefinitionSorting["Version"] = "Version";
        DecisionDefinitionSorting["DeploymentId"] = "DeploymentId";
        DecisionDefinitionSorting["TenantId"] = "TenantId";
    })(exports.DecisionDefinitionSorting || (exports.DecisionDefinitionSorting = {}));

    function editForm () {
        var extend = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            extend[_i] = arguments[_i];
        }
        PasswordEditData__default["default"].push({
            type: 'select',
            key: 'encryptMethod',
            label: 'Encrypt Method',
            data: {
                values: [
                    { label: 'SHA-256', value: 'sha265' }
                ],
            },
        });
        return textEditForm__default["default"].apply(void 0, __spread([[
                {
                    key: 'data',
                    components: PasswordEditData__default["default"]
                },
                {
                    key: 'display',
                    components: PasswordEditDisplay__default["default"]
                },
                {
                    key: 'validation',
                    components: PasswordEditValidation__default["default"]
                }
            ]], extend));
    }

    var PasswordComponent = angular.Formio.Components.components.password;
    // @dynamic
    var BetimesPasswordComponent = /** @class */ (function (_super) {
        __extends(BetimesPasswordComponent, _super);
        function BetimesPasswordComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BetimesPasswordComponent.register = function () {
            BetimesPasswordComponent.editForm = editForm;
            formiojs.Components.setComponent('password', BetimesPasswordComponent);
        };
        BetimesPasswordComponent.prototype.updateComponentValue = function (value, flags) {
            if (flags === void 0) { flags = {}; }
            if (this.oldData) {
                value = this.oldData;
                this.oldData = undefined;
            }
            return _super.prototype.updateComponentValue.call(this, value, flags);
        };
        BetimesPasswordComponent.prototype.beforeSubmit = function () {
            if (this.component.encryptMethod === "sha265") {
                this.oldData = this.dataValue;
                this.dataValue = sha256__default["default"](this.dataValue).toString();
            }
            return _super.prototype.beforeSubmit.call(this);
        };
        return BetimesPasswordComponent;
    }(PasswordComponent));
    BetimesPasswordComponent.editForm = editForm;

    var ExecuteContext = /** @class */ (function () {
        function ExecuteContext() {
        }
        return ExecuteContext;
    }());

    /*
     * Public API Surface of eform-share
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.ApiStockService = ApiStockService;
    exports.BetimesPasswordComponent = BetimesPasswordComponent;
    exports.EFORM_REQUEST = EFORM_REQUEST;
    exports.EFormDefaulti18n = EFormDefaulti18n;
    exports.EformShareModule = EformShareModule;
    exports.ExecuteContext = ExecuteContext;
    exports.FormConfigService = FormConfigService;
    exports.FormPublishingService = FormPublishingService;
    exports.FormSubmitService = FormSubmitService;
    exports.FormioRenderComponent = FormioRenderComponent;
    exports.WorkflowService = WorkflowService;
    exports.httpRequestFactory = httpRequestFactory;
    exports["ɵa"] = FormCommandInvoker;
    exports["ɵb"] = EformShareComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=eform-share.umd.js.map
