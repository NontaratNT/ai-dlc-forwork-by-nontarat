import { Components, Utils } from 'formiojs';
import DayComponent from 'formiojs/components/day/Day';
import DayEditForm from 'formiojs/components/day/Day.form';
import { FormioUtils, Formio as Formio$1, FormioModule } from '@formio/angular';
import Formio from 'formiojs/Formio';
import DateTimeEditForm from 'formiojs/components/datetime/DateTime.form';
import * as moment from 'moment';
import * as momentTimezone from 'moment-timezone';
import i18next from 'i18next';
import _ from 'lodash';
import NativePromise from 'native-promise-only';
import baseEditForm from 'formiojs/components/select/Select.form.js';
import SelectEditDisplay from 'formiojs/components/select/editForm/Select.edit.display';
import baseEditForm$1 from 'formiojs/components/editgrid/EditGrid.form.js';
import EditGridEditDisplay from 'formiojs/components/editgrid/editForm/EditGrid.edit.display';
import { Evaluator } from 'formiojs/utils/utils';
import templates from 'formiojs/components/editgrid/templates';
import baseEditForm$2 from 'formiojs/components/file/File.form.js';
import FileEditDisplay from 'formiojs/components/file/editForm/File.edit.file';
import Field from 'formiojs/components/_classes/field/Field';
import download from 'downloadjs';
import * as i0 from '@angular/core';
import { Component, Injectable, Inject, EventEmitter, Input, ViewChild, Output, InjectionToken, NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DxLoadPanelModule } from 'devextreme-angular';
import { Dialog, BetimesHttpRequest, SHARE_UI_CONFIG, ShareUiModule, DevExtreamDialog } from 'share-ui';
import { __awaiter } from 'tslib';
import { HttpClient } from '@angular/common/http';
import baseEditForm$3 from 'formiojs/components/recaptcha/ReCaptcha.form.js';
import ReCaptchaEditDisplay from 'formiojs/components/recaptcha/editForm/ReCaptcha.edit.display';
import _get from 'lodash/get';
import { map } from 'rxjs/operators';
import textEditForm from 'formiojs/components/textfield/TextField.form';
import PasswordEditDisplay from 'formiojs/components/password/editForm/Password.edit.display';
import PasswordEditData from 'formiojs/components/password/editForm/Password.edit.data';
import PasswordEditValidation from 'formiojs/components/password/editForm/Password.edit.validation';
import sha256 from 'crypto-js/sha256';

// @dynamic
class BetimesDay extends DayComponent {
    constructor(component, options, data) {
        super(component, options, data);
        super.init();
    }
    static get builderInfo() {
        return {
            title: "Day Thai",
            group: "advanced",
            icon: "calendar",
            documentation: "/userguide/#day",
            weight: 50,
            schema: BetimesDay.schema()
        };
    }
    static schema() {
        return DayComponent.schema({
            type: "dayThai",
        });
    }
    get months() {
        if (this._months) {
            return this._months;
        }
        this._months = [
            { value: 1, label: "มกราคม" },
            { value: 2, label: "กุมภาพันธ์" },
            { value: 3, label: "มีนาคม" },
            { value: 4, label: "เมษายน" },
            { value: 5, label: "พฤษภาคม" },
            { value: 6, label: "มิถุนายน" },
            { value: 7, label: "กรกฎาคม" },
            { value: 8, label: "สิงหาคม" },
            { value: 9, label: "กันยายน" },
            { value: 10, label: "ตุลาคม" },
            { value: 11, label: "พฤศจิกายน" },
            { value: 12, label: "ธันวาคม" }
        ];
        return this._months;
    }
}
BetimesDay.editForm = DayEditForm;
Components.addComponent("dayThai", BetimesDay);

/* eslint-disable radix */
const DateTimeComponent = Formio.Components.components.datetime;
// @dynamic
class BetimesDateTime extends DateTimeComponent {
    constructor(component, options, data) {
        super(component, options, data);
        component.widget.locale = "th";
        component.widget.language = "th-TH";
        component.widget.timezone = "Asia/Bangkok";
        component.widget.plugins = [this.convertToBuddhistPlugin(component, this)];
        // this.dataValue =
    }
    static get builderInfo() {
        return {
            title: "Date/Time Thai",
            group: "advanced",
            icon: "calendar",
            documentation: "/userguide/#datetime",
            weight: 40,
            schema: BetimesDateTime.schema()
        };
    }
    static schema() {
        return DateTimeComponent.schema({
            type: "dateTimeThai",
        });
    }
    attachElement(...args) {
        this.component.widget.locale = i18next.language;
        return super.attachElement(args);
    }
    createWidget(index) {
        const widget = super.createWidget(index);
        if (widget && widget.settings.disableFunction) {
            Object.defineProperty(widget, "disableFunction", {
                get: () => (date) => this.evaluate(`return ${widget.settings.disableFunction}`, {
                    date,
                    row: this.data,
                    data: this.root._submission.data,
                    moment
                })
            });
        }
        return widget;
    }
    setValue(value, flags = {}) {
        if (value && this.component.enableTime) {
            value = momentTimezone(value).tz("Asia/Bangkok").format();
        }
        super.setValue(value, flags);
    }
    getValueAsString(value) {
        const format = FormioUtils.convertFormatToMoment(this.component.format);
        if (i18next.language === "en") {
            return (value ? moment(value).format(format) : value) || '';
        }
        return (value ? moment(value).add(543, "year").format(format) : value) || '';
    }
    convertToBuddhistPlugin(component, root) {
        let currentDate;
        return (fp) => {
            currentDate = root.getValue();
            if (i18next.language === "en") {
                return {
                    onChange: (d) => {
                        currentDate = d;
                    }
                };
            }
            return {
                onChange: (d) => {
                    currentDate = d;
                    updateYear();
                },
                onYearChange: updateYear,
                onOpen: [
                    updateYear,
                    reloadDisableDate
                ],
                onMonthChange: updateYear,
                onReady: [
                    addListeners,
                    updateYear,
                    () => {
                        // แก้บัค lib ตอนโหลดข้อมูลเข้าแล้วแสดง text ใน textBox ไม่ถูกต้อง ไม่ยอมเอาค่าจาก formatDate
                        setTimeout(() => {
                            // const startDate = (this as any).getValue();
                            if (currentDate) {
                                fp.setDate(currentDate, true);
                            }
                            // else if (startDate) {
                            //     let format = component.widget.format;
                            //     // INFO: เนื่องจากข้อมูลที่ได้จากฐานข้อมูลจะอยู่ในรูปแบบ yyyy-MM-DD เราจึงต้องแปลง date ให้ตรง format
                            //     if (format.startsWith("dd-MMM-yyyy") || format.startsWith("dd MMM yyyy")
                            //     || format.startsWith("dd/MMM/yyyy")) {
                            //         format = format.replace("yyyy", "DD")
                            //             .replace("dd", "yyyy")
                            //             .replace("MMM", "MM");
                            //     }
                            //     else if (format.startsWith("dd-MM-yyyy") || format.startsWith("dd MM yyyy")
                            //     || format.startsWith("dd/MM/yyyy")) {
                            //         format = format.replace("yyyy", "DD")
                            //             .replace("dd", "yyyy");
                            //     }
                            //     const md = moment(startDate, format);
                            //     console.log(md.toDate(), format);
                            //     fp.setDate(md.toDate(), true);
                            // }
                        });
                        fp.loadedPlugins.push("convertToBuddhist");
                    }
                ]
            };
            function reloadDisableDate() {
                if (component.widget.disableFunction) {
                    fp.jumpToDate(undefined, false);
                    fp.currentYearElement.value = fp.currentYear + 543;
                }
            }
            function updateYear() {
                fp.currentYearElement.value = fp.currentYear + 543;
            }
            function addListeners() {
                fp.formatDate = (date) => {
                    const format = Utils.convertFormatToMoment(component.widget.format);
                    const md = moment(date, format);
                    const christianYear = md.format("YYYY");
                    const buddhishYear = (parseInt(christianYear, 0) + 543).toString();
                    return md
                        .format(format.replace("YYYY", buddhishYear).replace("YY", buddhishYear.substring(2, 4)))
                        .replace(christianYear, buddhishYear);
                };
                fp.parseDate = (date) => {
                    const format = Utils.convertFormatToMoment(component.widget.format);
                    const md = moment(date, format);
                    if (md.year() >= 2400) {
                        md.subtract(543, "year");
                    }
                    else if (!md.year()) {
                        return currentDate[0];
                    }
                    return md.toDate();
                };
                fp._bind(fp.currentYearElement, "keyup", (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (fp.currentYearElement.value.length === 4) {
                        const year = parseInt(fp.currentYearElement.value, 0);
                        if (year) {
                            fp.changeYear(year - 543);
                        }
                    }
                });
                fp._bind(fp.prevMonthNav, "click", (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    fp.changeMonth(-1);
                    updateYear();
                });
                fp._bind(fp.nextMonthNav, "click", (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    fp.changeMonth(1);
                    updateYear();
                });
            }
        };
    }
}
BetimesDateTime.editForm = DateTimeEditForm;
Components.addComponent("dateTimeThai", BetimesDateTime);

function SelectEditForm () {
    return baseEditForm([
        {
            key: 'select',
            components: SelectEditDisplay.unshift({
                key: 'tableViewAsync',
                label: 'Table View Async',
                tooltip: 'แสดงค่านี้ใน Table View แบบ Async',
                type: 'checkbox',
                weight: 1501,
                input: true,
                defaultValue: false
            }, {
                weight: 1500,
                type: 'checkbox',
                label: 'Table View',
                tooltip: 'Shows this value within the table view of the submissions.',
                key: 'tableView',
                input: true,
                calculateValue: c => c.data.tableViewAsync ? false : c.data.tableView
            })
        }
    ]);
}

const SelectComponent = Formio$1.Components.components.select;
// @dynamic
class BetimesSelectComponent extends SelectComponent {
    setChoicesValue(value, hasPreviousValue, flags = {}) {
        const hasValue = !this.isEmpty(value);
        hasPreviousValue = (hasPreviousValue === undefined) ? true : hasPreviousValue;
        if (this.choices) {
            // Now set the value.
            if (hasValue) {
                this.choices.removeActiveItems();
                // Add the currently selected choices if they don't already exist.
                const currentChoices = Array.isArray(value) ? value : [value];
                if (!this.addCurrentChoices(currentChoices, this.selectOptions, true)) {
                    this.choices.setChoices(this.selectOptions, 'value', 'label', true);
                }
                if (typeof value === "number") {
                    value = value.toString();
                }
                this.choices.setChoiceByValue(value);
            }
            else if (hasPreviousValue || flags.resetValue) {
                this.choices.removeActiveItems();
            }
        }
        else {
            if (hasValue) {
                const values = Array.isArray(value) ? value : [value];
                _.each(this.selectOptions, (selectOption) => {
                    _.each(values, (val) => {
                        if (_.isEqual(val, selectOption.value) && selectOption.element) {
                            selectOption.element.selected = true;
                            selectOption.element.setAttribute('selected', 'selected');
                            return false;
                        }
                        return true;
                    });
                });
            }
            else {
                _.each(this.selectOptions, (selectOption) => {
                    if (selectOption.element) {
                        selectOption.element.selected = false;
                        selectOption.element.removeAttribute('selected');
                    }
                });
            }
        }
    }
    getViewAsync(value, options) {
        const valueView = super.getView(value, options);
        let resolver;
        const awaiter = new NativePromise((resolve) => {
            resolver = resolve;
        });
        if (this.component.dataSrc === "url") {
            const resolveDataView = () => {
                let opv = this.selectOptions.find(_ => _.value === valueView);
                opv = opv ? opv.label : valueView;
                resolver(opv);
            };
            if (this.selectOptions.length) {
                resolveDataView();
            }
            else {
                this.updateItems(null, true);
                this.itemsLoaded.then(resolveDataView);
            }
        }
        else {
            resolver(valueView);
        }
        return awaiter;
    }
}
BetimesSelectComponent.editForm = SelectEditForm;
BetimesSelectComponent.editForm = SelectEditForm;
Components.setComponent('select', BetimesSelectComponent);

function EditGridForm () {
    return baseEditForm$1([
        {
            key: 'display',
            components: EditGridEditDisplay.unshift({
                key: 'viewMode',
                label: 'ดูได้แม้ ReadOnly',
                tooltip: 'เมื่อ ReadOnly สามารถกดดูรายการได้',
                type: 'checkbox',
                weight: 1000,
                input: true,
                defaultValue: true
            })
        }
    ]);
}

const template$1 = `
<ul class="editgrid-listgroup list-group
    {{ ctx.component.striped ? 'table-striped' : ''}}
    {{ ctx.component.bordered ? 'table-bordered' : ''}}
    {{ ctx.component.hover ? 'table-hover' : ''}}
    {{ ctx.component.condensed ? 'table-sm' : ''}}
    ">
    {% if (ctx.header) { %}
    <li class="list-group-item list-group-header">
        {{ctx.header}}
    </li>
    {% } %}
    {% ctx.rows.forEach(function(row, rowIndex) { %}
    <li class="list-group-item" ref="{{ctx.ref.row}}">
        {{row}}
        {% if (ctx.openRows[rowIndex] && !ctx.readOnly) { %}
        <div class="editgrid-actions">
            <button class="btn btn-primary" ref="{{ctx.ref.saveRow}}">{{ctx.t(ctx.component.saveRow || 'Save', {
                _userInput: true })}}</button>
            {% if (ctx.component.removeRow) { %}
            <button class="btn btn-danger" ref="{{ctx.ref.cancelRow}}">{{ctx.t(ctx.component.removeRow || 'Cancel', {
                _userInput: true })}}</button>
            {% } %}
        </div>
        {% } else if (ctx.openRows[rowIndex] && ctx.readOnly && ctx.viewMode) { %}
            <button class="btn btn-danger" ref="{{ctx.ref.closeRow}}">{{ctx.t('ปิด', {
            _userInput: true })}}</button>
        {% } %}
        <div class="has-error">
            <div class="editgrid-row-error help-block">
                {{ctx.errors[rowIndex]}}
            </div>
        </div>
    </li>
    {% }) %}
    {% if (ctx.footer) { %}
    <li class="list-group-item list-group-footer">
        {{ctx.footer}}
    </li>
    {% } %}
</ul>
{% if (!ctx.readOnly && ctx.hasAddButton) { %}
<button class="btn btn-primary" ref="{{ctx.ref.addRow}}">
    <i class="{{ctx.iconClass('plus')}}"></i> {{ctx.t(ctx.component.addAnother || 'Add Another', { _userInput: true })}}
</button>
{% } %}`;

const EditGridComponent = Formio.Components.components.editgrid;
// @dynamic
class EditGridCustom extends EditGridComponent {
    constructor() {
        super(...arguments);
        this.closeRowRef = `${this.editgridKey}-closeRow`;
    }
    get CloseRowElements() {
        return this.refs[this.closeRowRef];
    }
    render(children) {
        if (this.builderMode) {
            return super.render();
        }
        const dataValue = this.dataValue || [];
        const headerTemplate = Evaluator.noeval ? templates.header : _.get(this.component, 'templates.header');
        const t = this.t.bind(this);
        return super.render(children || this.customRender(template$1, {
            ref: {
                row: this.rowRef,
                addRow: this.addRowRef,
                saveRow: this.saveRowRef,
                cancelRow: this.cancelRowRef,
                closeRow: this.closeRowRef
            },
            header: this.renderString(headerTemplate, {
                displayValue: (component) => this.displayComponentValue(component),
                components: this.component.components,
                value: dataValue,
                t
            }),
            footer: this.renderString(_.get(this.component, 'templates.footer'), {
                components: this.component.components,
                value: dataValue,
                t
            }),
            rows: this.editRows.map(this.renderRow.bind(this)),
            openRows: this.editRows.map((row) => this.isOpen(row)),
            errors: this.editRows.map((row) => row.error),
            hasAddButton: this.hasAddButton(),
            hasRemoveButtons: this.hasRemoveButtons()
        }));
    }
    attach(element) {
        if (this.builderMode) {
            return super.attach(element);
        }
        const w = super.attach(element);
        this.loadRefs(element, {
            [this.closeRowRef]: 'multiple',
        });
        let openRowCount = 0;
        this.rowElements.forEach((row, rowIndex) => {
            const editRow = this.editRows[rowIndex];
            if (this.isOpen(editRow)) {
                this.addEventListener(this.CloseRowElements[openRowCount], 'click', () => this.closeRow(rowIndex));
                openRowCount++;
            }
            const elements = row.getElementsByClassName("viewRow");
            Array.prototype.forEach.call(elements, (ele) => {
                this.addEventListener(ele, "click", () => this.viewRow(rowIndex));
            });
        });
        return w;
    }
    viewRow(rowIndex) {
        const editRow = this.editRows[rowIndex];
        editRow.prevState = editRow.state;
        editRow.state = "viewing";
        return this.redraw();
    }
    closeRow(rowIndex) {
        const editRow = this.editRows[rowIndex];
        editRow.state = "draft";
        this.redraw();
    }
    customRender(template, data = {}) {
        data.component = this.component;
        data.self = this;
        data.options = this.options;
        data.readOnly = this.disabled;
        data.iconClass = this.iconClass.bind(this);
        data.size = this.size.bind(this);
        data.t = this.t.bind(this);
        data.transform = this.transform;
        data.id = data.id || this.id;
        data.key = data.key || this.key;
        data.value = data.value || this.dataValue;
        data.disabled = this.disabled;
        data.builder = this.builderMode;
        data.label = this.labelInfo;
        data.tooltip = this.getFormattedTooltip(this.component.tooltip);
        data.viewMode = this.component.viewMode;
        return this.renderString(template, data);
    }
    renderRow(row, rowIndex) {
        const dataValue = this.dataValue || [];
        if (this.isOpen(row)) {
            return this.renderComponents(row.components);
        }
        else {
            const flattenedComponents = this.flattenComponents(rowIndex);
            const rowTemplate = Evaluator.noeval ? templates.row :
                _.get(this.component, 'templates.row', EditGridComponent.defaultRowTemplate);
            return this.renderString(rowTemplate, {
                row: dataValue[rowIndex] || {},
                data: this.data,
                rowIndex,
                components: this.component.components,
                flattenedComponents,
                displayValue: (component) => this.displayComponentValue(component),
                isVisibleInRow: (component) => this.isComponentVisibleInRow(component, flattenedComponents),
                getView: (component, data) => {
                    var _a;
                    const instance = flattenedComponents[component.key];
                    if (instance && instance.component.tableViewAsync) {
                        if (this.editRows[rowIndex].dataAsync) {
                            return this.editRows[rowIndex].dataAsync[component.key];
                        }
                        else {
                            instance.getViewAsync(data || instance.dataValue).then(d => {
                                if (!this.editRows[rowIndex].dataAsync) {
                                    this.editRows[rowIndex].dataAsync = {};
                                }
                                this.editRows[rowIndex].dataAsync[component.key] = d;
                                this.redraw();
                            });
                        }
                    }
                    else {
                        const view = instance ? instance.getView(data || instance.dataValue) : '';
                        const htmlTagRegExp = new RegExp('<(.*?)>');
                        return typeof view === 'string' && view.length && !((_a = instance.component) === null || _a === void 0 ? void 0 : _a.template) && htmlTagRegExp.test(view)
                            ? `<input type="text" value="${view.replace(/"/g, '&quot;')}" readonly/>`
                            : view;
                    }
                },
                state: this.editRows[rowIndex].state,
                t: this.t.bind(this)
            });
        }
    }
    saveRow(rowIndex, modified) {
        if (this.editRows[rowIndex].dataAsync) {
            delete this.editRows[rowIndex].dataAsync;
        }
        super.saveRow(rowIndex, modified);
    }
}
EditGridCustom.editForm = EditGridForm;
Components.setComponent('editgrid', EditGridCustom);

function FileForm () {
    return baseEditForm$2([
        {
            key: 'file',
            components: FileEditDisplay.unshift({
                key: 'preview',
                label: 'Preview File',
                tooltip: 'เมื่อกดปุ่มดูไฟล์จะเป็นการ Preview ไฟล์แทนที่จะดาวน์โหลด',
                type: 'checkbox',
                weight: 33,
                input: true,
                defaultValue: false
            })
        }
    ]);
}

const template = `
{% if (!ctx.self.imageUpload) { %}
  <ul class="list-group list-group-striped">
    <li class="list-group-item list-group-header hidden-xs hidden-sm">
      <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-{% if (ctx.self.hasTypes) { %}7{% } else { %}9{% } %}"><strong>{{ctx.t('File Name')}}</strong></div>
        <div class="col-md-2"><strong>{{ctx.t('Size')}}</strong></div>
        {% if (ctx.self.hasTypes) { %}
          <div class="col-md-2"><strong>{{ctx.t('Type')}}</strong></div>
        {% } %}
      </div>
    </li>
    {% ctx.files.forEach(function(file) { %}
      <li class="list-group-item">
        <div class="row">
          <div class="col-md-1">
            <i role="button" href="{{file.url || '#'}}" class="{{ctx.iconClass('eye')}}" ref="fileLink"></i>
          </div>
          <div class="col-md-{% if (ctx.self.hasTypes) { %}7{% } else { %}9{% } %}">
            {% if (ctx.component.uploadOnly) { %}
              {{file.originalName || file.name}}
            {% } else { %}
              <a target="_blank" >{{file.originalName || file.name}}</a>
            {% } %}
          </div>
          <div class="col-md-2">
            <span class="mr-3">{{ctx.fileSize(file.size)}}</span>
            {% if (!ctx.disabled) { %}
                <i role="button" class="{{ctx.iconClass('remove')}}" ref="removeLink"></i>
            {% } %}
          </div>
          {% if (ctx.self.hasTypes && !ctx.disabled) { %}
            <div class="col-md-2">
              <select class="file-type" ref="fileType">
                {% ctx.component.fileTypes.map(function(type) { %}
                  <option class="test" value="{{ type.value }}" {% if (type.label === file.fileType) { %}selected="selected"{% } %}>{{ type.label }}</option>
                {% }); %}
              </select>
            </div>
          {% } %}
          {% if (ctx.self.hasTypes && ctx.disabled) { %}
          <div class="col-md-2"><span>{{file.fileType}}<span></div>
          {% } %}
        </div>
      </li>
    {% }) %}
  </ul>
{% } else { %}
  <div>
    {% ctx.files.forEach(function(file) { %}
      <div>
        <span>
          <img ref="fileImage" src="" alt="{{file.originalName || file.name}}" style="width:{{ctx.component.imageSize}}px">
          {% if (!ctx.disabled) { %}
            <i class="{{ctx.iconClass('remove')}}" ref="removeLink"></i>
          {% } %}
        </span>
      </div>
    {% }) %}
  </div>
{% } %}
{% if (!ctx.disabled && (ctx.component.multiple || !ctx.files.length)) { %}
  {% if (ctx.self.useWebViewCamera) { %}
    <div class="fileSelector">
      <button class="btn btn-primary" ref="galleryButton"><i class="fa fa-book"></i> {{ctx.t('Gallery')}}</button>
      <button class="btn btn-primary" ref="cameraButton"><i class="fa fa-camera"></i> {{ctx.t('Camera')}}</button>
    </div>
  {% } else if (!ctx.self.cameraMode) { %}
    <div class="fileSelector" ref="fileDrop" {{ctx.fileDropHidden ? 'hidden' : ''}}>
      <i class="{{ctx.iconClass('cloud-upload')}}"></i> {{ctx.t('Drop files to attach,')}}
        {% if (ctx.self.imageUpload && ctx.component.webcam) { %}
          <a href="#" ref="toggleCameraMode"><i class="fa fa-camera"></i> {{ctx.t('Use Camera,')}}</a>
        {% } %}
        {{ctx.t('or')}} <a href="#" ref="fileBrowse" class="browse">{{ctx.t('browse')}}</a>
      <div ref="fileProcessingLoader" class="loader-wrapper">
        <div class="loader text-center"></div>
      </div>
    </div>
  {% } else { %}
    <div class="video-container">
      <video class="video" autoplay="true" ref="videoPlayer"></video>
    </div>
    <button class="btn btn-primary" ref="takePictureButton"><i class="fa fa-camera"></i> {{ctx.t('Take Picture')}}</button>
    <button class="btn btn-primary" ref="toggleCameraMode">{{ctx.t('Switch to file upload')}}</button>
  {% } %}
{% } %}
{% ctx.statuses.forEach(function(status) { %}
  <div class="file {{ctx.statuses.status === 'error' ? ' has-error' : ''}}">
    <div class="row">
      <div class="fileName col-form-label col-sm-10">{{status.originalName}} <i class="{{ctx.iconClass('remove')}}" ref="fileStatusRemove"></i></div>
      <div class="fileSize col-form-label col-sm-2 text-right">{{ctx.fileSize(status.size)}}</div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        {% if (status.status === 'progress') { %}
          <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="{{status.progress}}" aria-valuemin="0" aria-valuemax="100" style="width: {{status.progress}}%">
              <span class="sr-only">{{status.progress}}% {{ctx.t('Complete')}}</span>
            </div>
          </div>
        {% } else if (status.status === 'error') { %}
          <div class="alert alert-danger bg-{{status.status}}">{{ctx.t(status.message)}}</div>
        {% } else { %}
          <div class="bg-{{status.status}}">{{ctx.t(status.message)}}</div>
        {% } %}
      </div>
    </div>
  </div>
{% }) %}
{% if (!ctx.component.storage || ctx.support.hasWarning) { %}
  <div class="alert alert-warning">
    {% if (!ctx.component.storage) { %}
      <p>{{ctx.t('No storage has been set for this field. File uploads are disabled until storage is set up.')}}</p>
    {% } %}
    {% if (!ctx.support.filereader) { %}
      <p>{{ctx.t('File API & FileReader API not supported.')}}</p>
    {% } %}
    {% if (!ctx.support.formdata) { %}
      <p>{{ctx.t("XHR2's FormData is not supported.")}}</p>
    {% } %}
    {% if (!ctx.support.progress) { %}
      <p>{{ctx.t("XHR2's upload progress isn't supported.")}}</p>
    {% } %}
  </div>
{% } %}`;

const FileComponent = Formio.Components.components.file;
// @dynamic
class FileCustom extends FileComponent {
    render() {
        return Field.prototype.render.call(this, this.customRender(template, {
            fileSize: this.fileSize,
            files: this.dataValue || [],
            statuses: this.statuses,
            disabled: this.disabled,
            support: this.support,
            fileDropHidden: this.fileDropHidden
        }));
    }
    customRender(template, data = {}) {
        data.component = this.component;
        data.self = this;
        data.options = this.options;
        data.readOnly = this.options.readOnly;
        data.iconClass = this.iconClass.bind(this);
        data.size = this.size.bind(this);
        data.t = this.t.bind(this);
        data.transform = this.transform;
        data.id = data.id || this.id;
        data.key = data.key || this.key;
        data.value = data.value || this.dataValue;
        data.disabled = this.disabled;
        data.builder = this.builderMode;
        data.label = this.labelInfo;
        data.tooltip = this.getFormattedTooltip(this.component.tooltip);
        return this.renderString(template, data);
    }
    getFile(fileInfo) {
        const { options = {} } = this.component;
        const { fileService } = this;
        if (!fileService) {
            return alert('File Service not provided');
        }
        if (this.component.privateDownload) {
            fileInfo.private = true;
        }
        fileService.downloadFile(fileInfo, options).then((file) => {
            if (file) {
                if (['base64', 'indexeddb'].includes(file.storage) && !this.component.preview) {
                    download(file.url, file.originalName || file.name, file.type);
                }
                else {
                    window.open(file.url, '_blank');
                }
            }
        })
            .catch((response) => {
            alert(response);
        });
    }
}
FileCustom.editForm = FileForm;
Components.setComponent('file', FileCustom);

class EformShareComponent {
    constructor() { }
    ngOnInit() {
    }
}
EformShareComponent.decorators = [
    { type: Component, args: [{
                selector: 'efs-eform-share',
                template: ``
            },] }
];
EformShareComponent.ctorParameters = () => [];

class FormCommandInvoker {
    constructor() {
        this.onLoadCommandList = new Set();
        this.onSubmitCommandList = new Set();
        this.onDestroyCommandList = new Set();
    }
    executeOnLoad(context) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const command of this.onLoadCommandList) {
                const result = command.onLoad(context);
                if (result !== undefined) {
                    yield result;
                }
            }
        });
    }
    executeOnSubmit(context) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const command of this.onSubmitCommandList) {
                const result = command.onSubmit(context);
                if (result !== undefined) {
                    yield result;
                }
            }
        });
    }
    executeOnDestroy(context) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const command of this.onDestroyCommandList) {
                const result = command.onDestroy(context);
                if (result !== undefined) {
                    yield result;
                }
            }
        });
    }
}
FormCommandInvoker.decorators = [
    { type: Injectable }
];
FormCommandInvoker.ctorParameters = () => [];

class EmptyDefaultValueCommand {
    onSubmit(context) {
        const newData = {};
        for (const key in context.submission) {
            const value = context.submission[key];
            if (value === "" || value === undefined) {
                newData[key] = null;
                continue;
            }
            newData[key] = value;
        }
        context.submission = newData;
    }
}

class ReCaptchaCommand {
    constructor() {
    }
    onLoad(context) {
        this._reCaptchaComponent = context.formio.formio.getComponent("recaptcha");
        if (this._reCaptchaComponent) {
            document.body.classList.add("recaptcha");
        }
    }
    onSubmit(context) {
        if (this._reCaptchaComponent) {
            const resultCaptcha = context.submission[this._reCaptchaComponent.key];
            if (resultCaptcha.success && resultCaptcha.score >= 0.5) {
                delete context.submission[this._reCaptchaComponent.key];
            }
            else {
                throw new Error("ระบบตรวจได้ว่าคุณคือ 'บอท (BOT)' คุณไม่สามารถดำเนินการต่อได้");
            }
        }
    }
    onDestroy() {
        if (this._reCaptchaComponent) {
            document.body.classList.remove("recaptcha");
        }
    }
}

class SubmissionCommnad {
    constructor(_renderComponent) {
        this._renderComponent = _renderComponent;
    }
    onSubmit(context) {
        return __awaiter(this, void 0, void 0, function* () {
            const formRender = this._renderComponent;
            if (!formRender._formConfig.formType) {
                throw new Error("การทำงานถูกยกเลิก เนื่องจากไม่พบประเภทฟอร์ม");
            }
            const eventBeforeSubmit = { component: formRender, data: context.submission };
            const beforeSubmitEvent = formRender.beforeSubmit(eventBeforeSubmit);
            if (beforeSubmitEvent !== undefined) {
                const resultAfterSubmit = yield beforeSubmitEvent;
                if (!resultAfterSubmit.isSuccess) {
                    throw new Error(resultAfterSubmit.message);
                }
            }
        });
    }
}

function trimObject(obj) {
    if (obj) {
        Object.keys(obj).forEach((k) => (obj[k] == null || obj[k] === undefined) && delete obj[k]);
    }
}

class FormConfigService {
    constructor(_req) {
        this._req = _req;
    }
    gets() {
        return this._req("form-config").get();
    }
    get(id) {
        return this._req(`form-config/${id}`).get();
    }
    create(config) {
        return this._req("form-config")
            .useSystemResult()
            .body(config)
            .post();
    }
    find(filter) {
        trimObject(filter);
        return this._req("form-config/find").queryString(filter).get();
    }
    validate(config) {
        return this._req("form-config/validate").body(config).post();
    }
    update(id, config) {
        return this._req("form-config/" + id)
            .useSystemResult()
            .body(config)
            .put();
    }
    delete(id) {
        return this._req("form-config/" + id)
            .useSystemResult()
            .delete();
    }
    deleteByFormCode(formCode) {
        return this._req("form-config")
            .body({ formCode })
            .useSystemResult()
            .delete();
    }
}
FormConfigService.decorators = [
    { type: Injectable }
];
FormConfigService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [EFORM_REQUEST,] }] }
];

class Submission {
    constructor(request) {
        this.request = request;
    }
    get(formId, submitId) {
        return this.request.api(`form-submit/form/${formId}/doc/${submitId}`)
            .get();
    }
    create(formId, data) {
        return this.request.api(`form-submit/form/${formId}`)
            .disableCriticalDialogError()
            .useSystemResult()
            .body(data)
            .post();
    }
    update(formId, submitId, data) {
        return this.request.api(`form-submit/form/${formId}/doc/${submitId}`)
            .disableCriticalDialogError()
            .useSystemResult()
            .body(data)
            .patch();
    }
}

class TaskSubmission extends Submission {
    constructor(request) {
        super(request);
    }
    get(formId, submitId) {
        return this.request.api(`task/form/${formId}/doc/${submitId}`)
            .get();
    }
    create(formId, data) {
        return this.request.api(`task/form/${formId}`)
            .disableCriticalDialogError()
            .useSystemResult()
            .body(data)
            .post();
    }
    update(formId, submitId, data) {
        return this.request.api(`task/form/${formId}/submit/${submitId}`)
            .disableCriticalDialogError()
            .useSystemResult()
            .body(data)
            .patch();
    }
}

class FormSubmitService {
    constructor(_req) {
        this._req = _req;
    }
    getSubmission(fromType) {
        const request = this._req();
        if (fromType === "T") {
            return new TaskSubmission(request);
        }
        return new Submission(request);
    }
}
FormSubmitService.decorators = [
    { type: Injectable }
];
FormSubmitService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [EFORM_REQUEST,] }] }
];

// @dynamic
class EFormDefaulti18n {
}

class FormioRenderComponent {
    constructor(_formConfigService, _dialog, _formSubmitService, _formInvoker) {
        this._formConfigService = _formConfigService;
        this._dialog = _dialog;
        this._formSubmitService = _formSubmitService;
        this._formInvoker = _formInvoker;
        this.readOnly = false;
        this.loadingPanelPosition = "#formContainer";
        this.onFormReady = new EventEmitter();
        this.onInitialized = new EventEmitter();
        this._refreshForm = new EventEmitter();
        this.loadingVisible = false;
        this._formioOption = {
            hooks: {
                beforeSubmit: undefined
            }
        };
        this._isFirstReady = false;
        this.isSubmission = false;
        this._language = EFormDefaulti18n.language;
        this._formioOption.hooks.beforeSubmit = (s, c) => {
            this._submitForm(s.data, c);
        };
        this.renderOptions = { validateOnInit: false };
        if (EFormDefaulti18n.language) {
            this.renderOptions.language = EFormDefaulti18n.language;
        }
        if (EFormDefaulti18n.i18n) {
            this.renderOptions.i18n = EFormDefaulti18n.i18n;
        }
    }
    set language(v) {
        if (this.formio) {
            this.formio.formio.language = v;
        }
        this._language = v;
    }
    get language() {
        return this._language;
    }
    ngOnChanges(changes) {
        if (changes.readOnly && this.formio) {
            for (const component of this.formio.formio.getComponents()) {
                component.disabled = changes.readOnly.currentValue;
            }
            this.formio.formio.redraw();
        }
        if (changes.renderOptions) {
            changes.renderOptions.currentValue.language = this.language;
            if (EFormDefaulti18n.i18n) {
                changes.renderOptions.currentValue.i18n = EFormDefaulti18n.i18n;
            }
        }
    }
    ngOnInit() {
        const recaptchaCommand = new ReCaptchaCommand();
        this._formInvoker.onLoadCommandList.add(recaptchaCommand);
        this._formInvoker.onSubmitCommandList.add(recaptchaCommand);
        this._formInvoker.onSubmitCommandList.add(new EmptyDefaultValueCommand());
        this._formInvoker.onDestroyCommandList.add(recaptchaCommand);
        if (this.formId) {
            this._formConfigService.get(this.formId).subscribe(f => {
                this.setFormConfig(f);
            });
        }
    }
    ngOnDestroy() {
        this._formInvoker.executeOnDestroy({ formio: this.formio });
    }
    formReady() {
        if (!this._isFirstReady) {
            this.onInitialized.emit(this);
            this._isFirstReady = true;
        }
        this.onFormReady.emit(this);
    }
    setFormConfig(config, submission) {
        let resolver;
        const p = new Promise(_ => resolver = _);
        this._formConfig = config;
        const form = JSON.parse(config.formJson);
        let getSubmitData;
        if (!submission && this.submissionId) {
            getSubmitData = this._formSubmitService.getSubmission(config.formType).get(config.id, this.submissionId);
        }
        if (getSubmitData) {
            getSubmitData.subscribe(s => {
                this._setForm(form, s).then(() => {
                    this._formInvoker.executeOnLoad({
                        formio: this.formio,
                        submission: s
                    }).then(() => {
                        resolver();
                    });
                });
            });
        }
        else {
            this._setForm(form, submission).then(() => {
                this._formInvoker.executeOnLoad({
                    formio: this.formio
                }).then(() => {
                    resolver();
                });
            });
        }
        return p;
    }
    setDataSubmission(submission) {
        if (this._formConfig == null) {
            throw new Error("ไม่พบข้อมูล FormConfig");
        }
        this.submissionId = submission._id;
        this._refreshForm.emit({
            submission: {
                data: submission
            }
        });
    }
    reset() {
        this.submissionId = undefined;
        this.isSubmission = false;
        this.formio.alerts.setAlerts([]);
        this._refreshForm.emit({
            submission: {
                data: {}
            }
        });
    }
    _setForm(form, submission) {
        if (form.display === "wizard" && this.readOnly) {
            form.components.forEach(_ => {
                if (_.buttonSettings) {
                    _.buttonSettings.cancel = false;
                }
            });
        }
        const formReady = this.formio.setForm(form);
        // แก้ไขไม่ให้มัน validation ตอน init form
        if (form.display === "wizard" && !this.readOnly) {
            this.formio.formio.setSubmission({}, { noValidate: !this.renderOptions.validateOnInit });
        }
        return formReady.then(() => {
            if (submission) {
                let data = this.formio.formio.data;
                if (data) {
                    this.submissionId = submission._id;
                    Object.keys(submission).forEach((k) => data[k] = submission[k]);
                }
                else {
                    data = submission;
                }
                this.formio.formio.setSubmission({ data }, { noValidate: true });
            }
        });
    }
    _submitForm(data, formioCallback) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.submissionId && this.isSubmission) {
                this.formio.onSubmit(data, true);
                return;
            }
            const submissionCommnad = new SubmissionCommnad(this);
            this._formInvoker.onSubmitCommandList.add(submissionCommnad);
            try {
                yield this._formInvoker.executeOnSubmit({ formio: this.formio, submission: data });
                this.isSubmission = true;
                this.formio.onSubmit(data, true);
            }
            catch (error) {
                if (error.message) {
                    this._dialog.error("ผิดพลาด", error.message);
                    formioCallback({ message: error.message }, null);
                }
            }
            this._formInvoker.onSubmitCommandList.delete(submissionCommnad);
        });
    }
}
FormioRenderComponent.decorators = [
    { type: Component, args: [{
                selector: 'efs-formio-render',
                template: "<div id=\"formContainer\">\r\n    <formio #internalForm [renderOptions]=\"renderOptions\" [readOnly]=\"readOnly\" [refresh]=\"_refreshForm\" [options]=\"_formioOption\"\r\n    (ready)=\"formReady()\"\r\n    ></formio>\r\n    <dx-load-panel\r\n        #loadPanel\r\n        shadingColor=\"rgba(0,0,0,0.4)\"\r\n        [position]=\"{ of: loadingPanelPosition }\"\r\n        [visible]=\"loadingVisible\"\r\n        [showIndicator]=\"true\"\r\n        [shading]=\"false\"\r\n        [closeOnOutsideClick]=\"false\">\r\n    </dx-load-panel>\r\n</div>\r\n",
                providers: [FormCommandInvoker],
                styles: [""]
            },] }
];
FormioRenderComponent.ctorParameters = () => [
    { type: FormConfigService },
    { type: Dialog },
    { type: FormSubmitService },
    { type: FormCommandInvoker }
];
FormioRenderComponent.propDecorators = {
    formId: [{ type: Input }],
    submissionId: [{ type: Input }],
    readOnly: [{ type: Input }],
    loadingPanelPosition: [{ type: Input }],
    renderOptions: [{ type: Input }],
    beforeSubmit: [{ type: Input }],
    language: [{ type: Input }],
    formio: [{ type: ViewChild, args: ["internalForm",] }],
    onFormReady: [{ type: Output }],
    onInitialized: [{ type: Output }]
};

function editForm$1 () {
    return baseEditForm$3([
        {
            key: 'display',
            components: ReCaptchaEditDisplay.unshift({
                type: 'checkbox',
                key: 'siteKeyOnSetting',
                label: 'Use SiteKey Form Project Setting',
                tooltip: 'ใช้ siteKey ที่จาก project',
                weight: 655
            })
        },
        {
            key: 'display',
            components: ReCaptchaEditDisplay.unshift({
                key: 'siteKey',
                label: 'Site Key',
                tooltip: 'ระบุ Site Key ที่ได้จาก google',
                type: 'textfield',
                weight: 660,
                customConditional(context) {
                    return !context.data.siteKeyOnSetting;
                }
            })
        },
        {
            key: 'data',
            ignore: true
        },
        {
            key: 'validation',
            ignore: true
        },
        {
            key: 'conditional',
            ignore: true
        },
        {
            key: 'logic',
            ignore: true
        }
    ]);
}

const ReCaptchaComponent = Formio$1.Components.components.recaptcha;
// @dynamic
class BetimesReCaptchaComponent extends ReCaptchaComponent {
    verify(actionName) {
        const key = this.component.siteKeyOnSetting ?
            (_get(this.root.form, 'settings.recaptcha.siteKey') || BetimesReCaptchaComponent.siteKey) :
            this.component.siteKey;
        this.root.form.settings = {
            recaptcha: {
                siteKey: key
            }
        };
        super.verify(actionName);
    }
    createInput() {
        const key = this.component.siteKeyOnSetting ?
            (_get(this.root.form, 'settings.recaptcha.siteKey') || BetimesReCaptchaComponent.siteKey) :
            this.component.siteKey;
        this.root.form.settings = {
            recaptcha: {
                siteKey: key
            }
        };
        super.createInput();
    }
    sendVerificationRequest(token) {
        return Formio$1.makeStaticRequest(`${BetimesReCaptchaComponent.projectUrl}/recaptcha?recaptchaToken=${token}`)
            .then((r) => ({ verificationResult: r.Value, token }));
    }
}
BetimesReCaptchaComponent.editForm = editForm$1;
BetimesReCaptchaComponent.editForm = editForm$1;
Components.setComponent('recaptcha', BetimesReCaptchaComponent);

const LOCAl_CONFIG = new InjectionToken("EformShareModule.LocalConfig");
const EFORM_REQUEST = new InjectionToken("EformShareModule.EformRequest");
function httpRequestFactory(http, config) {
    const c = function createHttpRequest(endpoint) {
        var _a;
        return new BetimesHttpRequest(http).host((_a = config.eFormHost) !== null && _a !== void 0 ? _a : config.baseConfig.apiUrl).api(endpoint);
    };
    return c;
}
class EformShareModule {
    constructor(config) {
        var _a;
        moment.locale("th");
        BetimesReCaptchaComponent.projectUrl = (_a = config.eFormHost) !== null && _a !== void 0 ? _a : config.baseConfig.apiUrl;
        BetimesReCaptchaComponent.siteKey = config.recaptcha ? config.recaptcha.siteKey : undefined;
    }
    static forRoot(config) {
        return {
            ngModule: EformShareModule,
            providers: [
                { provide: SHARE_UI_CONFIG, useValue: config.baseConfig },
                { provide: LOCAl_CONFIG, useValue: config }
            ]
        };
    }
}
EformShareModule.decorators = [
    { type: NgModule, args: [{
                declarations: [FormioRenderComponent, EformShareComponent],
                imports: [
                    DxLoadPanelModule,
                    FormioModule,
                    ShareUiModule
                ],
                exports: [FormioRenderComponent],
                schemas: [CUSTOM_ELEMENTS_SCHEMA],
                providers: [
                    FormSubmitService,
                    FormConfigService,
                    { provide: Dialog, useExisting: DevExtreamDialog },
                    { provide: EFORM_REQUEST, useFactory: httpRequestFactory, deps: [HttpClient, LOCAl_CONFIG] }
                ]
            },] }
];
EformShareModule.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [LOCAl_CONFIG,] }] }
];

var SortOrder;
(function (SortOrder) {
    SortOrder["Ascending"] = "Ascending";
    SortOrder["Descending"] = "Descending";
})(SortOrder || (SortOrder = {}));

class FormPublishingService {
    constructor(_req) {
        this._req = _req;
    }
    find(filter) {
        trimObject(filter);
        return this._req("form-pub/find").queryString(filter).get();
    }
    create(pub) {
        return this._req("form-pub")
            .useSystemResult()
            .body(pub)
            .post();
    }
    update(id, pub) {
        return this._req("form-pub/" + id)
            .useSystemResult()
            .body(pub)
            .put();
    }
}
FormPublishingService.ɵprov = i0.ɵɵdefineInjectable({ factory: function FormPublishingService_Factory() { return new FormPublishingService(i0.ɵɵinject(EFORM_REQUEST)); }, token: FormPublishingService, providedIn: "root" });
FormPublishingService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
FormPublishingService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [EFORM_REQUEST,] }] }
];

class ApiStockService {
    constructor(_req) {
        this._req = _req;
    }
    find(filter) {
        trimObject(filter);
        return this._req("api-stock/find").queryString(filter).get();
    }
    create(stock) {
        return this._req("api-stock")
            .useSystemResult()
            .body(stock)
            .post();
    }
    update(id, stock) {
        return this._req("api-stock/" + id)
            .useSystemResult()
            .body(stock)
            .put();
    }
}
ApiStockService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ApiStockService_Factory() { return new ApiStockService(i0.ɵɵinject(EFORM_REQUEST)); }, token: ApiStockService, providedIn: "root" });
ApiStockService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ApiStockService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [EFORM_REQUEST,] }] }
];

class WorkflowVariable {
    constructor(_processVariables) {
        this._processVariables = _processVariables;
    }
    getValue(varName) {
        const v = this._processVariables[varName];
        if (!v) {
            return undefined;
        }
        return this._convertValue(v.Type.toLocaleLowerCase(), v.value, v.ValueInfo);
    }
    getVariableValue(varName) {
        const v = this._processVariables[varName];
        if (!v) {
            return undefined;
        }
        return v;
    }
    values() {
        const convertObj = {};
        for (const key in this._processVariables) {
            convertObj[key] = this.getValue(key);
        }
        return convertObj;
    }
    _convertValue(typeName, value, valueInfo) {
        let convertedValue;
        switch (typeName) {
            case "boolean":
                convertedValue = Boolean(value);
                break;
            case "date":
                convertedValue = new Date(value);
                break;
            case "short":
            case "integer":
            case "long":
            case "double":
                convertedValue = Number(value);
                break;
            case "object":
                if (value && valueInfo.serializationDataFormat === "application/json") {
                    convertedValue = JSON.parse(value);
                }
                else {
                    convertedValue = value;
                }
                break;
            case "null":
                convertedValue = undefined;
                break;
            default:
                convertedValue = value;
                break;
        }
        return convertedValue;
    }
}

class WorkflowService {
    constructor(_req) {
        this._req = _req;
    }
    // #region Process Definition
    getProcessDefinitions(filter) {
        return this._req().api(`Workflow/process-definition`)
            .queryString(filter)
            .get();
    }
    getProcessDefinitionXml(defId) {
        return this._req().api(`Workflow/process-definition/xml`)
            .body({ ProcessDefinitionId: defId })
            .post();
    }
    getProcessInstanceStatistics(filter) {
        return this._req().api(`Workflow/process-definition/statistics`)
            .queryString(filter)
            .get();
    }
    // #endregion
    getProcessInstance(id) {
        return this._req().api(`Workflow/process-instance/${id}`)
            .get();
    }
    getProcessInstanceVariable(id) {
        return this._req().api(`Workflow/process-instance/${id}/variables`)
            .get()
            .pipe(map(v => new WorkflowVariable(v)));
    }
    getDecisionDefinition(filter) {
        return this._req().api(`Workflow/decision-definition`)
            .queryString(filter)
            .get();
    }
    getDecisionDefinitionXml(defId) {
        return this._req().api(`Workflow/decision-definition/xml`)
            .body({ DecisionDefinitionId: defId })
            .post();
    }
    getCaseDefinition(filter) {
        return this._req().api(`Workflow/case-definition`)
            .queryString(filter)
            .get();
    }
    getCaseDefinitionXml(defId) {
        return this._req().api(`Workflow/case-definition/xml`)
            .body({ CaseDefinitionId: defId })
            .post();
    }
    // #region Task
    getTask(id) {
        return this._req().api(`Workflow/task/${id}`)
            .get();
    }
    getTasks(filter) {
        return this._req().api("Workflow/task")
            .queryString(filter)
            .get();
    }
    getTaskUserCount(username, groupName) {
        return this._req().api(`Workflow/task/user/count`)
            .queryString({ Assignee: username, CandidateGroup: groupName })
            .get();
    }
    claimTask(param) {
        return this._req().api(`Workflow/task/${param.TaskId}/claim`)
            .body({ UserId: param.UserId })
            .useSystemResult()
            .post();
    }
    unclaimTask(param) {
        return this._req().api(`Workflow/task/${param.TaskId}/unclaim`)
            .body({ UserId: param.UserId })
            .useSystemResult()
            .post();
    }
    // #endregion
    getHistoryTasks(searchObj) {
        return this._req("Workflow/history/task")
            .body(searchObj)
            .post();
    }
    deploy(file) {
        const f = new FormData();
        f.append("upload", file);
        return this._req("Workflow/deployment/create")
            .useSystemResult()
            .body(f)
            .post();
    }
    updateProcessDefinitionSuspend(procId, param) {
        return this._req(`Workflow/process-definition/${procId}/suspended`)
            .useSystemResult()
            .body(param)
            .post();
    }
}
WorkflowService.ɵprov = i0.ɵɵdefineInjectable({ factory: function WorkflowService_Factory() { return new WorkflowService(i0.ɵɵinject(EFORM_REQUEST)); }, token: WorkflowService, providedIn: "root" });
WorkflowService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
WorkflowService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [EFORM_REQUEST,] }] }
];
var HistoricTaskSorting;
(function (HistoricTaskSorting) {
    HistoricTaskSorting["TaskId"] = "taskId";
    HistoricTaskSorting["Priority"] = "priority";
    HistoricTaskSorting["EndTime"] = "endTime";
    HistoricTaskSorting["StartTime"] = "startTime";
})(HistoricTaskSorting || (HistoricTaskSorting = {}));
var TaskSorting;
(function (TaskSorting) {
    TaskSorting["Id"] = "id";
    TaskSorting["Created"] = "created";
    TaskSorting["Assignee"] = "assignee";
    TaskSorting["DueDate"] = "dueDate";
    TaskSorting["ProcessInstanceId"] = "instanceId";
})(TaskSorting || (TaskSorting = {}));
var DecisionDefinitionSorting;
(function (DecisionDefinitionSorting) {
    DecisionDefinitionSorting["Category"] = "Category";
    DecisionDefinitionSorting["Key"] = "Key";
    DecisionDefinitionSorting["Id"] = "Id";
    DecisionDefinitionSorting["Name"] = "Name";
    DecisionDefinitionSorting["Version"] = "Version";
    DecisionDefinitionSorting["DeploymentId"] = "DeploymentId";
    DecisionDefinitionSorting["TenantId"] = "TenantId";
})(DecisionDefinitionSorting || (DecisionDefinitionSorting = {}));

function editForm (...extend) {
    PasswordEditData.push({
        type: 'select',
        key: 'encryptMethod',
        label: 'Encrypt Method',
        data: {
            values: [
                { label: 'SHA-256', value: 'sha265' }
            ],
        },
    });
    return textEditForm([
        {
            key: 'data',
            components: PasswordEditData
        },
        {
            key: 'display',
            components: PasswordEditDisplay
        },
        {
            key: 'validation',
            components: PasswordEditValidation
        }
    ], ...extend);
}

const PasswordComponent = Formio$1.Components.components.password;
// @dynamic
class BetimesPasswordComponent extends PasswordComponent {
    static register() {
        BetimesPasswordComponent.editForm = editForm;
        Components.setComponent('password', BetimesPasswordComponent);
    }
    updateComponentValue(value, flags = {}) {
        if (this.oldData) {
            value = this.oldData;
            this.oldData = undefined;
        }
        return super.updateComponentValue(value, flags);
    }
    beforeSubmit() {
        if (this.component.encryptMethod === "sha265") {
            this.oldData = this.dataValue;
            this.dataValue = sha256(this.dataValue).toString();
        }
        return super.beforeSubmit();
    }
}
BetimesPasswordComponent.editForm = editForm;

class ExecuteContext {
}

/*
 * Public API Surface of eform-share
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiStockService, BetimesPasswordComponent, DecisionDefinitionSorting, EFORM_REQUEST, EFormDefaulti18n, EformShareModule, ExecuteContext, FormConfigService, FormPublishingService, FormSubmitService, FormioRenderComponent, HistoricTaskSorting, SortOrder, TaskSorting, WorkflowService, httpRequestFactory, FormCommandInvoker as ɵa, EformShareComponent as ɵb };
//# sourceMappingURL=eform-share.js.map
