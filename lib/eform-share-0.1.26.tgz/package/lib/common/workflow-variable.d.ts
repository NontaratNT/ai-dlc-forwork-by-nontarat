import { ProcessVariables, VariableValue } from "../services/workflow.service";
export declare class WorkflowVariable {
    private _processVariables;
    constructor(_processVariables: ProcessVariables);
    getValue(varName: string): string | number | Date | boolean | object;
    getVariableValue(varName: string): VariableValue;
    values(): {
        [varName: string]: string | number | Date | boolean | object;
    };
    private _convertValue;
}
