export declare class EFormDefaulti18n {
    static language: string;
    static i18n: any;
}
