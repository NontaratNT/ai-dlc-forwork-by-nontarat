export default function (): any;
