declare const EditGridComponent: any;
import EditGridForm from './edit-grid.form';
export default class EditGridCustom extends EditGridComponent {
    static editForm: typeof EditGridForm;
    closeRowRef: string;
    get CloseRowElements(): any;
    render(children: any): any;
    attach(element: any): any;
    viewRow(rowIndex: any): any;
    closeRow(rowIndex: any): void;
    customRender(template: string, data?: any): string;
    renderRow(row: any, rowIndex: any): any;
    saveRow(rowIndex: any, modified: any): void;
}
export {};
