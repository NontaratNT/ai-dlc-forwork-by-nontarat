import DayComponent from "formiojs/components/day/Day";
export default class BetimesDay extends DayComponent {
    static editForm: any;
    private _months;
    private component;
    constructor(component: any, options: any, data: any);
    static get builderInfo(): {
        title: string;
        group: string;
        icon: string;
        documentation: string;
        weight: number;
        schema: any;
    };
    static schema(): any;
    get months(): any[];
}
