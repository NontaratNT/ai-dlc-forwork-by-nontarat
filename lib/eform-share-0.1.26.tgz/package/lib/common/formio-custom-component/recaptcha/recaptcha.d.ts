import editForm from './recaptcha.form';
declare const ReCaptchaComponent: any;
export default class BetimesReCaptchaComponent extends ReCaptchaComponent {
    static editForm: typeof editForm;
    static projectUrl: string;
    static siteKey: string;
    verify(actionName: any): void;
    createInput(): void;
    sendVerificationRequest(token: any): any;
}
export {};
