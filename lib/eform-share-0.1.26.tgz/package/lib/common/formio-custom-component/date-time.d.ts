declare const DateTimeComponent: any;
export default class BetimesDateTime extends DateTimeComponent {
    static editForm: any;
    constructor(component: any, options: any, data: any);
    static get builderInfo(): {
        title: string;
        group: string;
        icon: string;
        documentation: string;
        weight: number;
        schema: any;
    };
    static schema(): any;
    attachElement(...args: any[]): any;
    createWidget(index: any): any;
    setValue(value: any, flags?: {}): void;
    getValueAsString(value: any): any;
    convertToBuddhistPlugin(component: any, root: any): any;
}
export {};
