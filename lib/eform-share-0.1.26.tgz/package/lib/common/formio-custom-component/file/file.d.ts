declare const FileComponent: any;
import FileForm from './file.form';
export default class FileCustom extends FileComponent {
    static editForm: typeof FileForm;
    render(): any;
    customRender(template: string, data?: any): string;
    getFile(fileInfo: any): void;
}
export {};
