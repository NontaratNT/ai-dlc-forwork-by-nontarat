declare const SelectComponent: any;
import SelectEditForm from "./select.form";
export default class BetimesSelectComponent extends SelectComponent {
    static editForm: typeof SelectEditForm;
    setChoicesValue(value: any, hasPreviousValue: any, flags?: any): void;
    getViewAsync(value: any, options: any): any;
}
export {};
