import editForm from './password.form';
declare const PasswordComponent: any;
export declare class BetimesPasswordComponent extends PasswordComponent {
    static editForm: typeof editForm;
    oldData: any;
    static register(): void;
    updateComponentValue(value: any, flags?: {}): any;
    beforeSubmit(): any;
}
export {};
