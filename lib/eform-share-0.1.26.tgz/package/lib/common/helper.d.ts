export declare function trimObject(obj: any): void;
