import { Config, IRequestBuilder } from "share-ui";
export interface FormValidateResult {
    message: string;
    isStrict: boolean;
    validity: boolean;
}
export interface IFormSubmitInfo {
    [key: string]: any;
    _id?: string;
}
export interface EformModuleConfig {
    baseConfig: Config;
    eFormHost: string;
    recaptcha: {
        siteKey: string;
    };
}
export interface SearchParam<T> {
    condition: Partial<T>;
    offset: number;
    length: number;
}
export interface FormioRenderOptions {
    [key: string]: any;
    breadcrumbSettings?: BreadcrumbSettings;
    buttonSettings?: ButtonSettings;
    allowPrevious?: boolean;
    noAlerts?: boolean;
    validateOnInit?: boolean;
}
export interface ButtonSettings {
    showPrevious?: boolean;
    showCancel?: boolean;
    showSubmit?: boolean;
    showNext?: boolean;
}
export interface BreadcrumbSettings {
    clickable?: boolean;
}
export declare type EformRequestFactory = <T>(endpoint?: string) => IRequestBuilder<T>;
export declare type FormioSubmissionCallback = (param: {
    message: string;
}, opt?: any) => void;
export declare enum SortOrder {
    Ascending = "Ascending",
    Descending = "Descending"
}
