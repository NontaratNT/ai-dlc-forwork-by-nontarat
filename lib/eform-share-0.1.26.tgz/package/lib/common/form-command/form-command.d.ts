import { FormioComponent } from "@formio/angular";
export interface IFormOnload {
    onLoad(context: ExecuteContext): Promise<void> | void;
}
export interface IFormOnSubmit {
    onSubmit(context: ExecuteContext): Promise<void> | void;
}
export interface IFormOnDestroy {
    onDestroy(context: ExecuteContext): Promise<void> | void;
}
export declare class ExecuteContext {
    formio: FormioComponent;
    submission?: {
        [key: string]: any;
    };
}
