import { ExecuteContext, IFormOnSubmit } from "./form-command";
export declare class EmptyDefaultValueCommand implements IFormOnSubmit {
    onSubmit(context: ExecuteContext): void | Promise<void>;
}
