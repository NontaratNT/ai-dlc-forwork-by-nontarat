import { ExecuteContext, IFormOnDestroy, IFormOnload, IFormOnSubmit } from "./form-command";
export declare class ReCaptchaCommand implements IFormOnload, IFormOnSubmit, IFormOnDestroy {
    private _reCaptchaComponent;
    constructor();
    onLoad(context: ExecuteContext): void | Promise<void>;
    onSubmit(context: ExecuteContext): void | Promise<void>;
    onDestroy(): void | Promise<void>;
}
export interface ReCaptchaResponse {
    success: boolean;
    score: number;
    action: string;
    challenge_ts: Date;
    hostname: string;
}
