import { FormioRenderComponent } from "../../components/formio-render/formio-render.component";
import { ExecuteContext, IFormOnSubmit } from "./form-command";
export declare class SubmissionCommnad implements IFormOnSubmit {
    private _renderComponent;
    constructor(_renderComponent: FormioRenderComponent);
    onSubmit(context: ExecuteContext): Promise<void>;
}
