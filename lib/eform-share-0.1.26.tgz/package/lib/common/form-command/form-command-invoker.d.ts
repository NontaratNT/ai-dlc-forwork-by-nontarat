import { ExecuteContext, IFormOnDestroy, IFormOnload, IFormOnSubmit } from "./form-command";
export declare class FormCommandInvoker {
    onLoadCommandList: Set<IFormOnload>;
    onSubmitCommandList: Set<IFormOnSubmit>;
    onDestroyCommandList: Set<IFormOnDestroy>;
    constructor();
    executeOnLoad(context: ExecuteContext): Promise<void>;
    executeOnSubmit(context: ExecuteContext): Promise<void>;
    executeOnDestroy(context: ExecuteContext): Promise<void>;
}
