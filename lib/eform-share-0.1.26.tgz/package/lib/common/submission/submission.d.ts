import { Observable } from "rxjs";
import { HttpStatusResult, HttpStatusResultValue, IRequestBuilder } from "share-ui";
import { IFormSubmit } from "../../services/form-submit.service";
import { IFormSubmitInfo } from "../common-type";
export declare class Submission implements IFormSubmit {
    protected request: IRequestBuilder<IFormSubmitInfo>;
    constructor(request: IRequestBuilder<IFormSubmitInfo>);
    get(formId: string, submitId: string): Observable<IFormSubmitInfo>;
    create(formId: string, data: Record<string, unknown>): Observable<HttpStatusResultValue<number>>;
    update(formId: string, submitId: string, data: Record<string, unknown>): Observable<HttpStatusResult>;
}
