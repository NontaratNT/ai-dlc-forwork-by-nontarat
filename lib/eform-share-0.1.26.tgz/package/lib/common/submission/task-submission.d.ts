import { Observable } from "rxjs";
import { HttpStatusResult, HttpStatusResultValue, IRequestBuilder } from "share-ui";
import { IFormSubmitInfo } from "../common-type";
import { Submission } from "./submission";
export declare class TaskSubmission extends Submission {
    constructor(request: IRequestBuilder<IFormSubmitInfo>);
    get(formId: string, submitId: string): Observable<IFormSubmitInfo>;
    create(formId: string, data: Record<string, unknown>): Observable<HttpStatusResultValue<number>>;
    update(formId: string, submitId: string, data: Record<string, unknown>): Observable<HttpStatusResult>;
}
