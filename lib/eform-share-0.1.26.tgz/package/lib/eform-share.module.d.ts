import './common/formio-custom-component/day';
import './common/formio-custom-component/date-time';
import './common/formio-custom-component/select/select';
import './common/formio-custom-component/edit-grid/edit-grid';
import './common/formio-custom-component/file/file';
import { InjectionToken, ModuleWithProviders } from '@angular/core';
import { IRequestBuilder } from 'share-ui';
import { EformModuleConfig, EformRequestFactory } from './common/common-type';
import { HttpClient } from '@angular/common/http';
export declare const EFORM_REQUEST: InjectionToken<IRequestBuilder<unknown>>;
export declare function httpRequestFactory(http: HttpClient, config: EformModuleConfig): EformRequestFactory;
export declare class EformShareModule {
    constructor(config: EformModuleConfig);
    static forRoot(config: EformModuleConfig): ModuleWithProviders<EformShareModule>;
}
