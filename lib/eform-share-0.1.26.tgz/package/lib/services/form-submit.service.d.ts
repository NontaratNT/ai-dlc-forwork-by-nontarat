import { Observable } from 'rxjs';
import { HttpStatusResult, HttpStatusResultValue } from 'share-ui';
import { EformRequestFactory, IFormSubmitInfo } from '../common/common-type';
export declare class FormSubmitService {
    private _req;
    constructor(_req: EformRequestFactory);
    getSubmission(fromType: string): IFormSubmit;
}
export interface IFormSubmit {
    get(formId: string, submitId: string): Observable<IFormSubmitInfo>;
    create(formId: string, data: Record<string, unknown>): Observable<HttpStatusResultValue<number>>;
    update(formId: string, submitId: string, data: Record<string, unknown>): Observable<HttpStatusResult>;
}
