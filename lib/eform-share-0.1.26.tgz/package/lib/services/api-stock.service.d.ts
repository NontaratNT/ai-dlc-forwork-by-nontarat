import { Observable } from 'rxjs';
import { FilterParam, HttpStatusResult, HttpStatusResultValue } from 'share-ui';
import { EformRequestFactory } from '../common/common-type';
export declare class ApiStockService {
    private _req;
    constructor(_req: EformRequestFactory);
    find(filter: Partial<FilterParam>): Observable<IApiStock>;
    create(stock: IApiStock): Observable<HttpStatusResultValue<IApiStock>>;
    update(id: string, stock: IApiStock): Observable<HttpStatusResult>;
}
export interface IApiStock {
    id?: string;
    apiStockJson: string;
    recordStatus: string;
    delFlag: string;
    createUserId?: number;
    createDate?: Date;
    updateUserId?: number;
    updateDate?: Date;
}
export interface IApiStockJson {
    apiStockId: string;
    apiStockCode: string;
    apiStockName: string;
    apiStockRemark: string;
    apiStockParentId: string;
    apiStockMainFlag: string;
    apiStockUrl: string;
    apiStockIcon: string;
    apiStockParamsIn: string;
    apiStockParamsOut: string;
    recordStatus: string;
}
