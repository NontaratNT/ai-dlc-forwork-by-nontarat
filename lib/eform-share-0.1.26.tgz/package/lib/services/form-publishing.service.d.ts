import { Observable } from 'rxjs';
import { FilterParam, HttpStatusResult, HttpStatusResultValue } from 'share-ui';
import { EformRequestFactory } from '../common/common-type';
export declare class FormPublishingService {
    private _req;
    constructor(_req: EformRequestFactory);
    find(filter: Partial<FilterParam>): Observable<IFormPublishing>;
    create(pub: IFormPublishing): Observable<HttpStatusResultValue<IFormPublishing>>;
    update(id: string, pub: IFormPublishing): Observable<HttpStatusResult>;
}
export interface IFormPublishing {
    id?: string;
    formPublicJson: string;
    recordStatus: string;
    delFlag: string;
    createUserId?: number;
    createDate?: Date;
    updateUserId?: number;
    updateDate?: Date;
}
export interface IFormPublishingJson {
    formPublicId: string;
    formPublicConfigId: string;
    formPublicCode: string;
    formPublicName: string;
    formPublicRemark: string;
    formPublicParentId: string;
    formPublicMainFlag: string;
    formPublicIcon: string;
    formPublicNewWindowFlag: string;
    formPublicTag: string;
    recordStatus: string;
}
