import { Observable } from 'rxjs';
import { HttpStatusResult, HttpStatusResultValue } from 'share-ui';
import { EformRequestFactory, FormValidateResult } from '../common/common-type';
export declare class FormConfigService {
    private _req;
    constructor(_req: EformRequestFactory);
    gets(): Observable<IFormConfig[]>;
    get(id: string): Observable<IFormConfig>;
    create(config: IFormConfig): Observable<HttpStatusResultValue<string>>;
    find(filter?: Partial<IFormConfig>): Observable<IFormConfig[]>;
    validate(config: IFormConfig): Observable<FormValidateResult>;
    update(id: string, config: IFormConfig): Observable<HttpStatusResult>;
    delete(id: string): Observable<HttpStatusResult>;
    deleteByFormCode(formCode: string): Observable<HttpStatusResult>;
}
export interface IFormConfig {
    id?: string;
    formCode: string;
    formVersion: string;
    formName: string;
    formJson: string;
    formType: string;
    workflowProcess?: string;
    backendName?: string;
    actionFormJson?: string;
    apiLoad: string;
    apiSubmit: string;
}
