import { Observable } from 'rxjs';
import { HttpStatusResult, HttpStatusResultValue, IPagingResult } from 'share-ui';
import { EformRequestFactory, SearchParam, SortOrder } from '../common/common-type';
import { WorkflowVariable } from '../common/workflow-variable';
export declare class WorkflowService {
    private _req;
    constructor(_req: EformRequestFactory);
    getProcessDefinitions(filter?: Partial<ProcessDefinitionsFilter>): Observable<ProcessDefinitionsInfo[]>;
    getProcessDefinitionXml(defId: string): Observable<string>;
    getProcessInstanceStatistics(filter?: Partial<ProcessInstanceStatisticFilter>): Observable<ProcessDefinitionStatisticsResult[]>;
    getProcessInstance(id: string): Observable<ProcessInstanceInfo>;
    getProcessInstanceVariable(id: string): Observable<WorkflowVariable>;
    getDecisionDefinition(filter: Partial<DecisionDefinitionFilter>): Observable<DecisionDefinitionInfo[]>;
    getDecisionDefinitionXml(defId: string): Observable<string>;
    getCaseDefinition(filter: Partial<CaseDefinitionFilter>): Observable<CaseDefinitionInfo[]>;
    getCaseDefinitionXml(defId: string): Observable<string>;
    getTask(id: string): Observable<TaskInfo>;
    getTasks(filter?: Partial<TaskFilter>): Observable<TaskInfo[]>;
    getTaskUserCount(username: string, groupName: string): Observable<UserTaskCount>;
    claimTask(param: TaskClaimParam): Observable<HttpStatusResult>;
    unclaimTask(param: TaskClaimParam): Observable<HttpStatusResult>;
    getHistoryTasks(searchObj: SearchParam<HistoricTaskFilter>): Observable<IPagingResult<HistoricTask>>;
    deploy(file: File): Observable<HttpStatusResultValue<DeploymentInfo>>;
    updateProcessDefinitionSuspend(procId: string, param: ProcessDefinitionSuspensionState): Observable<HttpStatusResult>;
}
export interface TaskFilter {
    Assignee: string;
    Assigned: string;
    AssigneeExpression: string;
    AssigneeLike: string;
    AssigneeLikeExpression: string;
    CandidateGroup: string;
    CandidateUser: string;
    CandidateGroupExpression: string;
    Name: string;
    NameLike: string;
    ProcessInstanceId: string;
    ProcessDefinitionId: string;
    ProcessDefinitionName: string;
    ProcessDefinitionNameLike: string;
    ProcessInstanceBusinessKey: string;
    InvolvedUser: string;
    DueDate: Date;
    DueBefore: Date;
    DueAfter: Date;
    SortBy: TaskSorting;
    SortOrder: SortOrder;
    FirstResult: number;
    MaxResults: number;
}
export interface TaskInfo {
    Id: string;
    Name: string;
    Due: Date;
    ProcessDefinitionId: string;
    FormKey: string;
    Assignee: string;
    ProcessInstanceId: string;
}
export interface UserTaskCount {
    MyTask: number;
    GroupTask: number;
}
export declare enum HistoricTaskSorting {
    TaskId = "taskId",
    Priority = "priority",
    EndTime = "endTime",
    StartTime = "startTime"
}
export declare enum TaskSorting {
    Id = "id",
    Created = "created",
    Assignee = "assignee",
    DueDate = "dueDate",
    ProcessInstanceId = "instanceId"
}
export interface HistoricTask extends TaskInfo {
    Id: string;
    Owner: string;
    Description: string;
    Assignee: string;
    ProcessInstanceId: string;
    Name: string;
    TenantId: string;
    Due: Date;
    StartTime: Date;
    EndTime: Date;
    RemovalTime: Date;
    Created: Date;
}
export interface HistoricTaskFilter {
    TaskId: string;
    ProcessInstanceId: string;
    TaskAssignee: string;
    SortBy: HistoricTaskSorting;
    SortOrder: SortOrder;
}
export interface ProcessDefinitionsFilter {
    Active: boolean;
    ProcessDefinitionId: string;
    DeploymentId: string;
    Name: string;
    Key: string;
    Version: string;
    LatestVersion: boolean;
}
export interface ProcessDefinitionSuspensionState {
    IncludeProcessInstances?: boolean;
    Suspended: boolean;
    ExecutionDate?: Date;
}
export interface ProcessInstanceStatisticFilter {
    IncludeFailedJobs: boolean;
    IncludeIncidents: boolean;
}
export interface ProcessDefinitionStatisticsResult {
    Id: string;
    Instances: number;
    FailedJobs: number;
    Incidents: IncidentStatisticsResult[];
    Definition: ProcessDefinitionsInfo;
}
export interface ProcessDefinitionsInfo {
    Id: string;
    TenantId: string;
    Key: string;
    Name: string;
    VersionTag: string;
    Suspended: boolean;
}
export interface ProcessInstanceInfo {
    Id: string;
    DefinitionId: string;
    BusinessKey: string;
    CaseInstanceId: string;
}
export declare enum DecisionDefinitionSorting {
    Category = "Category",
    Key = "Key",
    Id = "Id",
    Name = "Name",
    Version = "Version",
    DeploymentId = "DeploymentId",
    TenantId = "TenantId"
}
export interface DecisionDefinitionFilter {
    LatestVersion: boolean;
    DecisionDefinitionId: string;
    SortBy: DecisionDefinitionSorting;
    SortOrder: SortOrder;
}
export interface CaseDefinitionFilter {
    LatestVersion: boolean;
    DecisionDefinitionId: string;
    SortBy: DecisionDefinitionSorting;
    SortOrder: SortOrder;
}
export interface TaskClaimParam {
    UserId: string;
    TaskId: string;
}
export interface IncidentStatisticsResult {
    IncidentType: string;
    IncidentCount: number;
}
export interface DeploymentInfo {
    Id: string;
    Name: string;
    Source: string;
    DeploymentTime: Date;
    TenantId: string;
}
export interface DecisionDefinitionInfo {
    Id: string;
    Category: string;
    Key: string;
    Name: string;
    Version: number;
    VersionTag: string;
}
export interface CaseDefinitionInfo {
    Id: string;
    Category: string;
    Key: string;
    Name: string;
    Version: number;
    VersionTag: string;
    DeploymentId: string;
}
export interface ProcessVariables {
    [varName: string]: VariableValue;
}
export interface VariableValue {
    Type: string;
    ValueInfo: any;
    value: string;
}
export interface VariableInfo {
    objectTypeName: string;
    serializationDataFormat: string;
}
