import { EventEmitter, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { FormioComponent } from '@formio/angular';
import { Dialog } from 'share-ui';
import { FormioRenderOptions, IFormSubmitInfo } from '../../common/common-type';
import { FormCommandInvoker } from '../../common/form-command/form-command-invoker';
import { FormConfigService, IFormConfig } from '../../services/form-config.service';
import { FormSubmitService } from '../../services/form-submit.service';
export declare class FormioRenderComponent implements OnInit, OnChanges, OnDestroy {
    private _formConfigService;
    private _dialog;
    private _formSubmitService;
    private _formInvoker;
    formId: string;
    submissionId: string;
    readOnly: boolean;
    loadingPanelPosition: string;
    renderOptions: FormioRenderOptions;
    beforeSubmit: (event: BeforeSubmitEvent) => Promise<SubmissionResult> | void;
    set language(v: string);
    get language(): string;
    formio: FormioComponent;
    onFormReady: EventEmitter<FormioRenderComponent>;
    onInitialized: EventEmitter<FormioRenderComponent>;
    _refreshForm: EventEmitter<any>;
    loadingVisible: boolean;
    _formioOption: {
        hooks: {
            beforeSubmit: any;
        };
    };
    _formConfig: IFormConfig;
    _isFirstReady: boolean;
    private isSubmission;
    private _language;
    constructor(_formConfigService: FormConfigService, _dialog: Dialog, _formSubmitService: FormSubmitService, _formInvoker: FormCommandInvoker);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    formReady(): void;
    setFormConfig(config: IFormConfig, submission?: IFormSubmitInfo): Promise<void>;
    setDataSubmission(submission: IFormSubmitInfo): void;
    reset(): void;
    private _setForm;
    private _submitForm;
}
export interface BeforeSubmitEvent {
    component: FormioRenderComponent;
    data: IFormSubmitInfo;
}
export interface SubmissionResult {
    isSuccess: boolean;
    message: string;
}
