import { OnInit } from '@angular/core';
export declare class EformShareComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
